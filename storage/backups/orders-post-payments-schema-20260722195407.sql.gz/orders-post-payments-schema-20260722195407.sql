/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.18-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: qrmenu_app
-- ------------------------------------------------------
-- Server version	10.11.18-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `branch_id` bigint(20) unsigned NOT NULL,
  `table_id` bigint(20) unsigned DEFAULT NULL,
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `channel` varchar(10) NOT NULL DEFAULT 'table',
  `public_token` char(26) DEFAULT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'open',
  `version` int(10) unsigned NOT NULL DEFAULT 0,
  `total_minor` bigint(20) unsigned NOT NULL DEFAULT 0,
  `items_total_minor` bigint(20) unsigned NOT NULL DEFAULT 0,
  `discount_minor` bigint(20) unsigned NOT NULL DEFAULT 0,
  `discount_percent` decimal(5,2) DEFAULT NULL,
  `discount_reason` varchar(255) DEFAULT NULL,
  `discount_by_id` bigint(20) unsigned DEFAULT NULL,
  `discount_approved_by_id` bigint(20) unsigned DEFAULT NULL,
  `comp_total_minor` bigint(20) unsigned NOT NULL DEFAULT 0,
  `vat_total_minor` bigint(20) unsigned NOT NULL DEFAULT 0,
  `service_charge_minor` bigint(20) unsigned NOT NULL DEFAULT 0,
  `service_charge_percent` decimal(5,2) DEFAULT NULL,
  `service_charge_reason` varchar(255) DEFAULT NULL,
  `rounding_minor` bigint(20) NOT NULL DEFAULT 0,
  `paid_minor` bigint(20) unsigned NOT NULL DEFAULT 0,
  `refunded_minor` bigint(20) unsigned NOT NULL DEFAULT 0,
  `guest_count` smallint(5) unsigned DEFAULT NULL,
  `note` varchar(500) DEFAULT NULL,
  `customer_name` varchar(120) DEFAULT NULL,
  `customer_phone` varchar(32) DEFAULT NULL,
  `opened_by_id` bigint(20) unsigned DEFAULT NULL,
  `placed_at` timestamp NULL DEFAULT NULL,
  `closed_at` timestamp NULL DEFAULT NULL,
  `cancelled_at` timestamp NULL DEFAULT NULL,
  `cancel_reason` varchar(255) DEFAULT NULL,
  `cancelled_by_id` bigint(20) unsigned DEFAULT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `orders_public_token_unique` (`public_token`),
  KEY `orders_branch_id_foreign` (`branch_id`),
  KEY `orders_table_id_foreign` (`table_id`),
  KEY `orders_customer_id_foreign` (`customer_id`),
  KEY `orders_tenant_id_branch_id_status_index` (`tenant_id`,`branch_id`,`status`),
  KEY `orders_tenant_id_created_at_index` (`tenant_id`,`created_at`),
  KEY `orders_discount_by_id_foreign` (`discount_by_id`),
  KEY `orders_discount_approved_by_id_foreign` (`discount_approved_by_id`),
  KEY `orders_opened_by_id_foreign` (`opened_by_id`),
  KEY `orders_cancelled_by_id_foreign` (`cancelled_by_id`),
  KEY `orders_tenant_id_table_id_status_index` (`tenant_id`,`table_id`,`status`),
  KEY `orders_tenant_id_channel_status_index` (`tenant_id`,`channel`,`status`),
  CONSTRAINT `orders_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `orders_cancelled_by_id_foreign` FOREIGN KEY (`cancelled_by_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_discount_approved_by_id_foreign` FOREIGN KEY (`discount_approved_by_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_discount_by_id_foreign` FOREIGN KEY (`discount_by_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_opened_by_id_foreign` FOREIGN KEY (`opened_by_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_table_id_foreign` FOREIGN KEY (`table_id`) REFERENCES `tables` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES
(1,1,1,1,NULL,'table',NULL,'cancelled',1,0,0,0,NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,0,0,0,NULL,NULL,NULL,NULL,2,'2026-07-22 13:11:59','2026-07-22 13:21:03','2026-07-22 13:21:03','boş test adisyonu temizliği',2,'TRY','2026-07-22 13:11:59','2026-07-22 13:21:03'),
(2,1,1,2,NULL,'table',NULL,'cancelled',2,32000,32000,0,NULL,NULL,NULL,NULL,0,2909,0,NULL,NULL,0,0,0,NULL,NULL,NULL,NULL,2,'2026-07-22 13:12:26','2026-07-22 13:12:26','2026-07-22 13:12:26','eszamanlilik kaniti - temizlik',2,'TRY','2026-07-22 13:12:26','2026-07-22 13:12:26'),
(3,1,1,1,NULL,'qr','WEMDDCVPD7RMZOFIMTOMCFWA4A','cancelled',6,0,0,0,NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,0,0,0,NULL,NULL,NULL,NULL,NULL,'2026-07-22 13:28:00','2026-07-22 13:29:26','2026-07-22 13:29:26','test',2,'TRY','2026-07-22 13:14:48','2026-07-22 13:29:26'),
(4,1,1,1,NULL,'qr','EQAY7ERTCDJ3SDLFMLCHMTNHXM','cancelled',1,32000,32000,0,NULL,NULL,NULL,NULL,0,2909,0,NULL,NULL,0,0,0,NULL,NULL,'Canlı Kanıt',NULL,NULL,NULL,'2026-07-22 13:20:44','2026-07-22 13:20:44','canlı kanıt temizliği',2,'TRY','2026-07-22 13:20:21','2026-07-22 13:20:44'),
(5,1,1,1,NULL,'table',NULL,'placed',0,0,0,0,NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,0,0,0,4,NULL,NULL,NULL,2,'2026-07-22 13:32:08',NULL,NULL,NULL,NULL,'TRY','2026-07-22 13:32:08','2026-07-22 13:32:08');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-22 19:54:07
