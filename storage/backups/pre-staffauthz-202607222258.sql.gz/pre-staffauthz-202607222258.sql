/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.18-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: qrmenu_app
-- ------------------------------------------------------
-- Server version	10.11.18-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `allergen_product`
--

DROP TABLE IF EXISTS `allergen_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `allergen_product` (
  `allergen_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`allergen_id`,`product_id`),
  KEY `allergen_product_product_id_foreign` (`product_id`),
  CONSTRAINT `allergen_product_allergen_id_foreign` FOREIGN KEY (`allergen_id`) REFERENCES `allergens` (`id`) ON DELETE CASCADE,
  CONSTRAINT `allergen_product_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `allergen_product`
--

LOCK TABLES `allergen_product` WRITE;
/*!40000 ALTER TABLE `allergen_product` DISABLE KEYS */;
INSERT INTO `allergen_product` VALUES
(1,1),
(1,3),
(1,4),
(1,5),
(1,6),
(1,7),
(1,8),
(1,10),
(1,11),
(1,17),
(1,18),
(1,19),
(1,20),
(1,21),
(1,22),
(1,24),
(1,26),
(1,27),
(1,28),
(1,29),
(1,30),
(1,31),
(1,35),
(1,36),
(1,37),
(1,38),
(1,39),
(1,40),
(1,41),
(1,42),
(1,43),
(1,44),
(1,45),
(1,69),
(3,1),
(3,2),
(3,3),
(3,4),
(3,5),
(3,18),
(3,37),
(3,40),
(3,41),
(3,42),
(3,44),
(4,33),
(7,1),
(7,2),
(7,5),
(7,6),
(7,11),
(7,13),
(7,17),
(7,18),
(7,19),
(7,21),
(7,22),
(7,23),
(7,24),
(7,25),
(7,26),
(7,27),
(7,28),
(7,30),
(7,31),
(7,32),
(7,35),
(7,36),
(7,39),
(7,40),
(7,41),
(7,42),
(7,43),
(7,44),
(7,49),
(7,50),
(7,51),
(7,52),
(7,53),
(7,58),
(7,59),
(7,69),
(8,6),
(8,42),
(8,43),
(8,45),
(8,65),
(8,69),
(11,7),
(15,7),
(15,9),
(15,22),
(15,29),
(15,32),
(15,46),
(15,47),
(15,48),
(15,54),
(15,55),
(15,56),
(15,57),
(15,60),
(15,61),
(15,62),
(15,63),
(16,3),
(16,5),
(16,6),
(16,7),
(16,9),
(16,10),
(16,11),
(16,22),
(16,23),
(16,29),
(16,30),
(16,32),
(16,35),
(16,40),
(16,41),
(16,42),
(16,43),
(16,44),
(16,45),
(16,46),
(16,47),
(16,48),
(16,49),
(16,50),
(16,51),
(16,52),
(16,53),
(16,54),
(16,55),
(16,56),
(16,57),
(16,58),
(16,59),
(16,60),
(16,61),
(16,62),
(16,63),
(16,69),
(17,9),
(17,13),
(17,32),
(17,33),
(17,34),
(17,46),
(17,47),
(17,48),
(17,49),
(17,50),
(17,53),
(17,54),
(17,55),
(17,56),
(17,57),
(17,58),
(17,60),
(17,61),
(17,62),
(17,63);
/*!40000 ALTER TABLE `allergen_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `allergens`
--

DROP TABLE IF EXISTS `allergens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `allergens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned DEFAULT NULL,
  `kind` varchar(10) NOT NULL DEFAULT 'allergen',
  `code` varchar(40) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `icon` varchar(60) DEFAULT NULL,
  `color` varchar(20) DEFAULT NULL,
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `allergens_tenant_id_kind_sort_order_index` (`tenant_id`,`kind`,`sort_order`),
  KEY `allergens_code_index` (`code`),
  CONSTRAINT `allergens_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `allergens`
--

LOCK TABLES `allergens` WRITE;
/*!40000 ALTER TABLE `allergens` DISABLE KEYS */;
INSERT INTO `allergens` VALUES
(1,NULL,'allergen','gluten','Gluten','Buğday, arpa, çavdar, yulaf gibi glüten içeren tahıllar ve ürünleri.','wheat','#f59e0b',10,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(2,NULL,'allergen','kabuklular','Kabuklular','Karides, yengeç, ıstakoz gibi kabuklu deniz canlıları.','shrimp','#14b8a6',20,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(3,NULL,'allergen','yumurta','Yumurta','Yumurta ve yumurta içeren ürünler (majonez, bazı hamur işleri).','egg','#eab308',30,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(4,NULL,'allergen','balik','Balık','Balık ve balık içeren ürünler (sos, sardalya, ançüez dahil).','fish','#06b6d4',40,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(5,NULL,'allergen','yer-fistigi','Yer Fıstığı','Yer fıstığı ve yer fıstığı içeren ürünler (fıstık ezmesi, yağı).','peanut','#84cc16',50,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(6,NULL,'allergen','soya','Soya','Soya fasulyesi ve soya ürünleri (soya sosu, tofu, lesitin).','bean','#22c55e',60,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(7,NULL,'allergen','sut','Süt (Laktoz)','Süt ve süt ürünleri; laktoz içerir (peynir, tereyağı, krema).','milk','#3b82f6',70,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(8,NULL,'allergen','sert-kabuklu','Sert Kabuklu Yemişler','Fındık, ceviz, badem, antep fıstığı, kaju gibi yemişler.','nut','#a855f7',80,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(9,NULL,'allergen','kereviz','Kereviz','Kereviz kökü, sapı, yaprağı ve tohumu içeren ürünler.','celery','#65a30d',90,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(10,NULL,'allergen','hardal','Hardal','Hardal ve hardal içeren soslar, marinasyonlar.','mustard','#ca8a04',100,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(11,NULL,'allergen','susam','Susam','Susam tohumu ve ürünleri (tahin, susamlı çıtır, simit).','sesame','#d97706',110,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(12,NULL,'allergen','sulfit','Kükürt Dioksit / Sülfit','Kurutulmuş meyve, şarap ve bazı işlenmiş gıdalardaki koruyucular (>10 mg/kg).','flask','#f43f5e',120,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(13,NULL,'allergen','aci-bakla','Acı Bakla (Lupin)','Lupin unu ve tohumu içeren ürünler (bazı unlu mamuller).','seed','#8b5cf6',130,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(14,NULL,'allergen','yumusakcalar','Yumuşakçalar','Midye, kalamar, ahtapot, salyangoz gibi yumuşakçalar.','shell','#0ea5e9',140,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(15,NULL,'diet','vegan','Vegan','Hiçbir hayvansal ürün içermez.','leaf','#16a34a',150,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(16,NULL,'diet','vejetaryen','Vejetaryen','Et, tavuk ve balık içermez; süt/yumurta içerebilir.','sprout','#22c55e',160,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(17,NULL,'diet','glutensiz','Glutensiz','Glüten içeren tahıl ve türevi içermez.','wheat-off','#f59e0b',170,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(18,NULL,'diet','laktozsuz','Laktozsuz','Laktoz içermez; laktoz intoleransına uygundur.','milk-off','#3b82f6',180,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(19,NULL,'diet','helal','Helal','Helal sertifikalı/uyumlu içerikle hazırlanır.','badge-check','#0d9488',190,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(20,NULL,'diet','sekersiz','Şekersiz','İlave şeker içermez.','candy-off','#ec4899',200,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(21,NULL,'diet','keto','Keto Dostu','Düşük karbonhidratlı, ketojenik beslenmeye uygun.','flame','#f97316',210,'2026-07-22 12:26:16','2026-07-22 12:26:16');
/*!40000 ALTER TABLE `allergens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned DEFAULT NULL,
  `branch_id` bigint(20) unsigned DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `entity_type` varchar(150) DEFAULT NULL,
  `entity_id` bigint(20) unsigned DEFAULT NULL,
  `old_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`old_values`)),
  `new_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_values`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(512) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `audit_logs_branch_id_foreign` (`branch_id`),
  KEY `audit_logs_user_id_foreign` (`user_id`),
  KEY `audit_logs_tenant_id_created_at_index` (`tenant_id`,`created_at`),
  KEY `audit_logs_tenant_id_action_index` (`tenant_id`,`action`),
  KEY `audit_logs_tenant_id_entity_type_entity_id_index` (`tenant_id`,`entity_type`,`entity_id`),
  KEY `audit_logs_tenant_id_user_id_index` (`tenant_id`,`user_id`),
  CONSTRAINT `audit_logs_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `audit_logs_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `audit_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=203 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES
(1,1,NULL,NULL,'roles.created','App\\Modules\\Identity\\Models\\Role',1,NULL,'{\"name\":\"Sahip\",\"slug\":\"sahip\",\"description\":\"Sahip rol\\u00fc\",\"tenant_id\":1,\"is_system\":true,\"updated_at\":\"2026-07-22T14:21:41.000000Z\",\"created_at\":\"2026-07-22T14:21:41.000000Z\",\"id\":1}','127.0.0.1','Symfony','2026-07-22 11:21:41'),
(2,1,NULL,NULL,'roles.created','App\\Modules\\Identity\\Models\\Role',2,NULL,'{\"name\":\"M\\u00fcd\\u00fcr\",\"slug\":\"mudur\",\"description\":\"M\\u00fcd\\u00fcr rol\\u00fc\",\"tenant_id\":1,\"is_system\":false,\"updated_at\":\"2026-07-22T14:21:41.000000Z\",\"created_at\":\"2026-07-22T14:21:41.000000Z\",\"id\":2}','127.0.0.1','Symfony','2026-07-22 11:21:41'),
(3,1,NULL,NULL,'roles.created','App\\Modules\\Identity\\Models\\Role',3,NULL,'{\"name\":\"Garson\",\"slug\":\"garson\",\"description\":\"Garson rol\\u00fc\",\"tenant_id\":1,\"is_system\":false,\"updated_at\":\"2026-07-22T14:21:41.000000Z\",\"created_at\":\"2026-07-22T14:21:41.000000Z\",\"id\":3}','127.0.0.1','Symfony','2026-07-22 11:21:41'),
(4,1,NULL,NULL,'roles.created','App\\Modules\\Identity\\Models\\Role',4,NULL,'{\"name\":\"Kasiyer\",\"slug\":\"kasiyer\",\"description\":\"Kasiyer rol\\u00fc\",\"tenant_id\":1,\"is_system\":false,\"updated_at\":\"2026-07-22T14:21:41.000000Z\",\"created_at\":\"2026-07-22T14:21:41.000000Z\",\"id\":4}','127.0.0.1','Symfony','2026-07-22 11:21:41'),
(5,NULL,NULL,NULL,'auth.login_failed',NULL,NULL,NULL,'{\"email\":\"sahip@demo.qrmenu.local\"}','46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.0.0 Safari/537.36','2026-07-22 11:48:59'),
(6,1,1,1,'auth.login','App\\Modules\\Identity\\Models\\User',1,NULL,NULL,'46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.0.0 Safari/537.36','2026-07-22 11:49:32'),
(7,NULL,NULL,NULL,'auth.login_failed',NULL,NULL,NULL,'{\"email\":\"demo@demo.com\"}','88.235.200.157','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-22 11:49:44'),
(8,1,1,2,'auth.login','App\\Modules\\Identity\\Models\\User',2,NULL,NULL,'46.224.208.126','curl/7.61.1','2026-07-22 11:50:06'),
(9,1,1,2,'auth.login','App\\Modules\\Identity\\Models\\User',2,NULL,NULL,'88.235.200.157','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-22 11:50:13'),
(10,1,1,1,'auth.pin_set','App\\Modules\\Identity\\Models\\User',1,NULL,NULL,'46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.0.0 Safari/537.36','2026-07-22 11:51:47'),
(11,1,1,1,'auth.two_factor_enabled','App\\Modules\\Identity\\Models\\User',1,NULL,NULL,'46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.0.0 Safari/537.36','2026-07-22 11:52:32'),
(12,1,1,1,'auth.two_factor_disabled','App\\Modules\\Identity\\Models\\User',1,NULL,NULL,'46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.0.0 Safari/537.36','2026-07-22 11:53:15'),
(13,1,1,1,'auth.logout','App\\Modules\\Identity\\Models\\User',1,NULL,NULL,'46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.0.0 Safari/537.36','2026-07-22 11:54:27'),
(14,1,1,1,'auth.pin_login','App\\Modules\\Identity\\Models\\User',1,NULL,NULL,'46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.0.0 Safari/537.36','2026-07-22 11:55:41'),
(15,1,1,1,'auth.logout','App\\Modules\\Identity\\Models\\User',1,NULL,NULL,'46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.0.0 Safari/537.36','2026-07-22 11:55:55'),
(16,NULL,NULL,NULL,'auth.login_failed',NULL,NULL,NULL,'{\"email\":\"sahip@demo.qrmenu.local\"}','46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.0.0 Safari/537.36','2026-07-22 11:55:55'),
(17,NULL,NULL,NULL,'auth.login_failed',NULL,NULL,NULL,'{\"email\":\"sahip@demo.qrmenu.local\"}','46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.0.0 Safari/537.36','2026-07-22 11:55:55'),
(18,NULL,NULL,NULL,'auth.login_failed',NULL,NULL,NULL,'{\"email\":\"sahip@demo.qrmenu.local\"}','46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.0.0 Safari/537.36','2026-07-22 11:55:55'),
(19,NULL,NULL,NULL,'auth.login_failed',NULL,NULL,NULL,'{\"email\":\"sahip@demo.qrmenu.local\"}','46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.0.0 Safari/537.36','2026-07-22 11:55:56'),
(20,NULL,NULL,NULL,'auth.login_failed',NULL,NULL,NULL,'{\"email\":\"sahip@demo.qrmenu.local\"}','46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.0.0 Safari/537.36','2026-07-22 11:55:56'),
(21,1,1,1,'auth.password_reset','App\\Modules\\Identity\\Models\\User',1,NULL,NULL,'46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.0.0 Safari/537.36','2026-07-22 11:57:55'),
(22,1,1,1,'auth.login','App\\Modules\\Identity\\Models\\User',1,NULL,NULL,'46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.0.0 Safari/537.36','2026-07-22 11:58:33'),
(23,1,1,2,'auth.login','App\\Modules\\Identity\\Models\\User',2,NULL,NULL,'46.224.208.126','curl/7.61.1','2026-07-22 12:00:49'),
(24,1,1,2,'auth.login','App\\Modules\\Identity\\Models\\User',2,NULL,NULL,'46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 12:12:01'),
(25,1,1,2,'auth.login','App\\Modules\\Identity\\Models\\User',2,NULL,NULL,'46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 12:12:04'),
(26,1,1,2,'auth.login','App\\Modules\\Identity\\Models\\User',2,NULL,NULL,'46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 12:12:06'),
(27,1,1,2,'auth.login','App\\Modules\\Identity\\Models\\User',2,NULL,NULL,'46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 12:12:09'),
(28,1,1,2,'auth.login','App\\Modules\\Identity\\Models\\User',2,NULL,NULL,'46.224.208.126','curl/7.61.1','2026-07-22 12:23:06'),
(29,1,NULL,NULL,'option_groups.created','App\\Modules\\Catalog\\Models\\OptionGroup',1,NULL,'{\"name\":\"Soslar\",\"description\":\"Yan\\u0131nda istedi\\u011finiz soslar (2 adede kadar \\u00fccretsiz olanlar mevcut).\",\"selection_type\":\"multiple\",\"is_required\":false,\"min_select\":0,\"max_select\":null,\"free_limit\":2,\"sort_order\":10,\"is_active\":true,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":1}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(30,1,NULL,NULL,'option_groups.created','App\\Modules\\Catalog\\Models\\OptionGroup',2,NULL,'{\"name\":\"Ekstra Malzemeler\",\"description\":\"\\u00dcr\\u00fcn\\u00fcn\\u00fcze ekleyebilece\\u011finiz ilave malzemeler.\",\"selection_type\":\"multiple\",\"is_required\":false,\"min_select\":0,\"max_select\":null,\"free_limit\":0,\"sort_order\":20,\"is_active\":true,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":2}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(31,1,NULL,NULL,'option_groups.created','App\\Modules\\Catalog\\Models\\OptionGroup',3,NULL,'{\"name\":\"S\\u00fct Tercihi\",\"description\":\"Kahveniz i\\u00e7in alternatif s\\u00fct se\\u00e7imi.\",\"selection_type\":\"single\",\"is_required\":false,\"min_select\":0,\"max_select\":1,\"free_limit\":0,\"sort_order\":30,\"is_active\":true,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":3}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(32,1,NULL,NULL,'option_groups.created','App\\Modules\\Catalog\\Models\\OptionGroup',4,NULL,'{\"name\":\"Kahve Ekstralar\\u0131\",\"description\":\"Kahvenizi zenginle\\u015ftirin.\",\"selection_type\":\"multiple\",\"is_required\":false,\"min_select\":0,\"max_select\":null,\"free_limit\":0,\"sort_order\":40,\"is_active\":true,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":4}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(33,1,NULL,NULL,'option_groups.created','App\\Modules\\Catalog\\Models\\OptionGroup',5,NULL,'{\"name\":\"K\\u00f6z Se\\u00e7imi\",\"description\":\"Nargileniz i\\u00e7in k\\u00f6z tercihi (zorunlu).\",\"selection_type\":\"single\",\"is_required\":true,\"min_select\":1,\"max_select\":1,\"free_limit\":1,\"sort_order\":50,\"is_active\":true,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":5}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(34,1,NULL,NULL,'option_groups.created','App\\Modules\\Catalog\\Models\\OptionGroup',6,NULL,'{\"name\":\"Nargile Ekstralar\\u0131\",\"description\":\"Nargile deneyiminizi ki\\u015fiselle\\u015ftirin.\",\"selection_type\":\"multiple\",\"is_required\":false,\"min_select\":0,\"max_select\":null,\"free_limit\":0,\"sort_order\":60,\"is_active\":true,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":6}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(35,1,NULL,NULL,'option_groups.created','App\\Modules\\Catalog\\Models\\OptionGroup',7,NULL,'{\"name\":\"Tatl\\u0131 Ekstralar\\u0131\",\"description\":\"Tatl\\u0131n\\u0131z\\u0131n yan\\u0131na ilaveler.\",\"selection_type\":\"multiple\",\"is_required\":false,\"min_select\":0,\"max_select\":null,\"free_limit\":0,\"sort_order\":70,\"is_active\":true,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":7}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(36,1,NULL,NULL,'categories.created','App\\Modules\\Catalog\\Models\\Category',1,NULL,'{\"name\":\"Kahvalt\\u0131lar\",\"slug\":\"kahvaltilar\",\"description\":\"G\\u00fcne enerjik ba\\u015flay\\u0131n\",\"available_from\":\"07:00\",\"available_until\":\"13:00\",\"sort_order\":10,\"is_active\":true,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":1}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(37,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',1,NULL,'{\"name\":\"Serpme Kahvalt\\u0131 (2 Ki\\u015filik)\",\"description\":\"Ezine peyniri, eski ka\\u015far, bal-kaymak, tereya\\u011f\\u0131, zeytin, domates, salatal\\u0131k, yumurta ve s\\u0131cak ekmek sepeti.\",\"category_id\":1,\"price_minor\":85000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":true,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":10,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":1}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(38,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',2,NULL,'{\"name\":\"H\\u0131zl\\u0131 Kahvalt\\u0131 Taba\\u011f\\u0131\",\"description\":\"Ha\\u015flanm\\u0131\\u015f yumurta, beyaz peynir, ka\\u015far, domates, salatal\\u0131k, zeytin, bal, tereya\\u011f\\u0131.\",\"category_id\":1,\"price_minor\":32000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":20,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":2}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(39,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',3,NULL,'{\"name\":\"Menemen\",\"description\":\"Geleneksel menemen; taze domates, biber ve yumurta. Yan\\u0131nda ekmek ile.\",\"category_id\":1,\"price_minor\":18000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":30,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":3}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(40,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',4,NULL,'{\"name\":\"Sucuklu Yumurta\",\"description\":\"Kangal sucuk ve \\u00e7iftlik yumurtas\\u0131. Yan\\u0131nda taze ekmek.\",\"category_id\":1,\"price_minor\":20000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":true,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":40,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":4}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(41,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',5,NULL,'{\"name\":\"Pancake Kulesi\",\"description\":\"4 katl\\u0131 pancake; mevsim meyveleri, \\u00e7ikolata ve ak\\u00e7aa\\u011fa\\u00e7 \\u015furubu ile.\",\"category_id\":1,\"price_minor\":24000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":true,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":50,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":5}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(42,1,NULL,NULL,'categories.created','App\\Modules\\Catalog\\Models\\Category',2,NULL,'{\"name\":\"Ba\\u015flang\\u0131\\u00e7lar\",\"slug\":\"baslangiclar\",\"description\":\"Hafif ve lezzetli at\\u0131\\u015ft\\u0131rmal\\u0131klar\",\"available_from\":null,\"available_until\":null,\"sort_order\":20,\"is_active\":true,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":2}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(43,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',6,NULL,'{\"name\":\"Sigara B\\u00f6re\\u011fi (4 Adet)\",\"description\":\"El a\\u00e7mas\\u0131 yufka, beyaz peynir ve maydanoz dolgulu. Ceviz sos ile.\",\"category_id\":2,\"price_minor\":12000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":10,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":6}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(44,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',7,NULL,'{\"name\":\"Humus Taba\\u011f\\u0131\",\"description\":\"Nohut p\\u00fcresi, tahin, zeytinya\\u011f\\u0131, sumak ve pita ekme\\u011fi.\",\"category_id\":2,\"price_minor\":10000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":20,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":7}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(45,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',8,NULL,'{\"name\":\"\\u00c7\\u0131t\\u0131r Tavuk (8 Adet)\",\"description\":\"M\\u0131s\\u0131r gevrekli kaplamayla \\u00e7\\u0131t\\u0131rla\\u015ft\\u0131r\\u0131lm\\u0131\\u015f tavuk par\\u00e7alar\\u0131. Ranch sos ile.\",\"category_id\":2,\"price_minor\":16000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":true,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":30,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":8}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(46,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',9,NULL,'{\"name\":\"Patates K\\u0131zartmas\\u0131\",\"description\":\"\\u00d6zel kesim patates, deniz tuzu ve biberiye. Ket\\u00e7ap ile.\",\"category_id\":2,\"price_minor\":9000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":40,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":9}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(47,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',10,NULL,'{\"name\":\"So\\u011fan Halkas\\u0131\",\"description\":\"\\u00c7\\u0131t\\u0131r kaplamayla k\\u0131zart\\u0131lm\\u0131\\u015f taze so\\u011fan halkalar\\u0131. BBQ sos ile.\",\"category_id\":2,\"price_minor\":11000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":50,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":10}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(48,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',11,NULL,'{\"name\":\"Mozzarella Stick (6 Adet)\",\"description\":\"\\u00c7\\u0131t\\u0131r kaplamayla k\\u0131zart\\u0131lm\\u0131\\u015f mozzarella \\u00e7ubu\\u011fu. Marinara sos ile.\",\"category_id\":2,\"price_minor\":14000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":true,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":60,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":11}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(49,1,NULL,NULL,'categories.created','App\\Modules\\Catalog\\Models\\Category',3,NULL,'{\"name\":\"Ana Yemekler\",\"slug\":\"ana-yemekler\",\"description\":\"Doyurucu ana yemekler\",\"available_from\":null,\"available_until\":null,\"sort_order\":30,\"is_active\":true,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":3}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(50,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',12,NULL,'{\"name\":\"Izgara K\\u00f6fte\",\"description\":\"Kasap k\\u00f6fte; pilav, \\u0131zgara domates, biber ve patates k\\u0131zartmas\\u0131 ile.\",\"category_id\":3,\"price_minor\":38000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":true,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":10,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":12}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(51,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',13,NULL,'{\"name\":\"Bonfile Lokum\",\"description\":\"200 gr dana bonfile; tereya\\u011fl\\u0131 patates p\\u00fcresi ve sote sebzeler ile.\",\"category_id\":3,\"price_minor\":65000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":true,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":20,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":13}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(52,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',14,NULL,'{\"name\":\"Tavuk \\u015ei\\u015f\",\"description\":\"Marine edilmi\\u015f tavuk \\u015fi\\u015f; bulgur pilav\\u0131 ve ye\\u015fil salata ile.\",\"category_id\":3,\"price_minor\":32000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":30,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":14}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(53,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',15,NULL,'{\"name\":\"Pili\\u00e7 Pirzola\",\"description\":\"Izgara pili\\u00e7 but; f\\u0131r\\u0131n patates ve mevsim salata ile.\",\"category_id\":3,\"price_minor\":35000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":true,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":40,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":15}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(54,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',16,NULL,'{\"name\":\"Kar\\u0131\\u015f\\u0131k Izgara\",\"description\":\"K\\u00f6fte, tavuk \\u015fi\\u015f, pirzola, Adana kebap. Pilav ve salata ile.\",\"category_id\":3,\"price_minor\":75000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":true,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":50,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":16}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(55,1,NULL,NULL,'categories.created','App\\Modules\\Catalog\\Models\\Category',4,NULL,'{\"name\":\"Burgerler\",\"slug\":\"burgerler\",\"description\":\"El yap\\u0131m\\u0131 \\u00f6zel burgerler\",\"available_from\":null,\"available_until\":null,\"sort_order\":40,\"is_active\":true,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":4}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(56,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',17,NULL,'{\"name\":\"Classic Cheeseburger\",\"description\":\"160 gr dana burger k\\u00f6ftesi, cheddar peyniri, karamelize so\\u011fan, tur\\u015fu, \\u00f6zel sos.\",\"category_id\":4,\"price_minor\":32000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":true,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":10,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":17}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(57,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',18,NULL,'{\"name\":\"Mushroom Burger\",\"description\":\"160 gr k\\u00f6fte, sote mantar, \\u0130svi\\u00e7re peyniri, tr\\u00fcf mayonez.\",\"category_id\":4,\"price_minor\":34000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":20,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":18}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(58,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',19,NULL,'{\"name\":\"BBQ Bacon Burger\",\"description\":\"160 gr k\\u00f6fte, \\u00e7\\u0131t\\u0131r bacon, cheddar, BBQ sos, so\\u011fan halkas\\u0131.\",\"category_id\":4,\"price_minor\":38000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":true,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":30,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":19}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(59,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',20,NULL,'{\"name\":\"Chicken Burger\",\"description\":\"\\u00c7\\u0131t\\u0131r tavuk file, marul, domates, ranch sos.\",\"category_id\":4,\"price_minor\":29000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":40,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":20}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(60,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',21,NULL,'{\"name\":\"Double Smash Burger\",\"description\":\"2\\u00d7120 gr smash k\\u00f6fte, double cheddar, karamelize so\\u011fan, \\u00f6zel smash sos.\",\"category_id\":4,\"price_minor\":42000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":true,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":50,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":21}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(61,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',22,NULL,'{\"name\":\"Vegan Burger\",\"description\":\"Mercimek ve sebze k\\u00f6ftesi, vegan peynir, avokado, \\u00f6zel vegan sos.\",\"category_id\":4,\"price_minor\":35000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":60,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":22}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(62,1,NULL,NULL,'categories.created','App\\Modules\\Catalog\\Models\\Category',5,NULL,'{\"name\":\"Pizzalar\",\"slug\":\"pizzalar\",\"description\":\"\\u0130talyan usul\\u00fc pizzalar\",\"available_from\":null,\"available_until\":null,\"sort_order\":50,\"is_active\":true,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":5}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(63,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',23,NULL,'{\"name\":\"Margherita\",\"description\":\"Domates sos, taze mozzarella, fesle\\u011fen, s\\u0131zma zeytinya\\u011f\\u0131.\",\"category_id\":5,\"price_minor\":25000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":10,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":23}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(64,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',24,NULL,'{\"name\":\"Kar\\u0131\\u015f\\u0131k Pizza\",\"description\":\"Sucuk, sosis, mantar, m\\u0131s\\u0131r, ye\\u015fil biber, zeytin, mozzarella.\",\"category_id\":5,\"price_minor\":32000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":true,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":20,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":24}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(65,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',25,NULL,'{\"name\":\"Pepperoni\",\"description\":\"Bol pepperoni, mozzarella, domates sos.\",\"category_id\":5,\"price_minor\":30000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":true,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":30,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":25}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(66,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',26,NULL,'{\"name\":\"Sucuklu Pizza\",\"description\":\"Kangal sucuk, ka\\u015far, mozzarella, domates sos.\",\"category_id\":5,\"price_minor\":28000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":40,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":26}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(67,1,NULL,NULL,'categories.created','App\\Modules\\Catalog\\Models\\Category',6,NULL,'{\"name\":\"Makarnalar\",\"slug\":\"makarnalar\",\"description\":\"Taze makarna \\u00e7e\\u015fitleri\",\"available_from\":null,\"available_until\":null,\"sort_order\":60,\"is_active\":true,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":6}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(68,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',27,NULL,'{\"name\":\"Fettuccine Alfredo\",\"description\":\"Krema, mantar, parmesan ve tavuk par\\u00e7alar\\u0131 ile.\",\"category_id\":6,\"price_minor\":29000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":true,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":10,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":27}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(69,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',28,NULL,'{\"name\":\"Spaghetti Bolonez\",\"description\":\"K\\u0131yma soslu klasik \\u0130talyan makarna. Parmesan ile servis.\",\"category_id\":6,\"price_minor\":26000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":20,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":28}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(70,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',29,NULL,'{\"name\":\"Penne Arrabbiata\",\"description\":\"Ac\\u0131l\\u0131 domates sos, sar\\u0131msak, fesle\\u011fen. Vegan se\\u00e7ene\\u011fi.\",\"category_id\":6,\"price_minor\":24000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":30,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":29}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(71,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',30,NULL,'{\"name\":\"Mantarl\\u0131 Makarna\",\"description\":\"Krema soslu kar\\u0131\\u015f\\u0131k mantar, kekik ve parmesan.\",\"category_id\":6,\"price_minor\":25000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":true,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":40,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":30}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(72,1,NULL,NULL,'categories.created','App\\Modules\\Catalog\\Models\\Category',7,NULL,'{\"name\":\"Salatalar\",\"slug\":\"salatalar\",\"description\":\"Taze ve sa\\u011fl\\u0131kl\\u0131 salatalar\",\"available_from\":null,\"available_until\":null,\"sort_order\":70,\"is_active\":true,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":7}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(73,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',31,NULL,'{\"name\":\"Sezar Salata\",\"description\":\"Marul, kruton, parmesan, tavuk ve Sezar sos.\",\"category_id\":7,\"price_minor\":22000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":10,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":31}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(74,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',32,NULL,'{\"name\":\"Akdeniz Salata\",\"description\":\"Roka, domates, salatal\\u0131k, zeytin, lor peyniri, nar ek\\u015fisi.\",\"category_id\":7,\"price_minor\":18000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":20,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":32}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(75,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',33,NULL,'{\"name\":\"Ton Bal\\u0131kl\\u0131 Salata\",\"description\":\"Ton bal\\u0131\\u011f\\u0131, m\\u0131s\\u0131r, havu\\u00e7, marul, limon sos.\",\"category_id\":7,\"price_minor\":26000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":true,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":30,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":33}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(76,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',34,NULL,'{\"name\":\"Avokadolu Tavuk Salata\",\"description\":\"Izgara tavuk, avokado, cherry domates, kinoa, ye\\u015fil sos.\",\"category_id\":7,\"price_minor\":28000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":true,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":40,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":34}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(77,1,NULL,NULL,'categories.created','App\\Modules\\Catalog\\Models\\Category',8,NULL,'{\"name\":\"Tostlar & Sandvi\\u00e7ler\",\"slug\":\"tostlar-sandvicler\",\"description\":\"S\\u0131cak tostlar ve sandvi\\u00e7ler\",\"available_from\":null,\"available_until\":null,\"sort_order\":80,\"is_active\":true,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":8}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(78,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',35,NULL,'{\"name\":\"Ka\\u015farl\\u0131 Tost\",\"description\":\"Bol ka\\u015farl\\u0131 klasik tost.\",\"category_id\":8,\"price_minor\":12000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":10,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":35}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(79,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',36,NULL,'{\"name\":\"Kar\\u0131\\u015f\\u0131k Tost\",\"description\":\"Ka\\u015far, sucuk, domates, ye\\u015fil biber.\",\"category_id\":8,\"price_minor\":16000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":true,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":20,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":36}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(80,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',37,NULL,'{\"name\":\"Club Sandwich\",\"description\":\"Tavuk, bacon, marul, domates, mayonez. Patates ile.\",\"category_id\":8,\"price_minor\":22000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":30,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":37}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(81,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',38,NULL,'{\"name\":\"Tavuklu Wrap\",\"description\":\"Izgara tavuk, marul, domates, ranch sos, lava\\u015f ekme\\u011fi.\",\"category_id\":8,\"price_minor\":20000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":true,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":40,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":38}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(82,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',39,NULL,'{\"name\":\"Kasap K\\u00f6fte Sandvi\\u00e7\",\"description\":\"El yap\\u0131m\\u0131 k\\u00f6fte, ka\\u015far, domates, tur\\u015fu, \\u00f6zel sos. Yan\\u0131nda patates.\",\"category_id\":8,\"price_minor\":26000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":true,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":50,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":39}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(83,1,NULL,NULL,'categories.created','App\\Modules\\Catalog\\Models\\Category',9,NULL,'{\"name\":\"Tatl\\u0131lar\",\"slug\":\"tatlilar\",\"description\":\"El yap\\u0131m\\u0131 tatl\\u0131lar\",\"available_from\":null,\"available_until\":null,\"sort_order\":90,\"is_active\":true,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":9}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(84,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',40,NULL,'{\"name\":\"San Sebastian Cheesecake\",\"description\":\"Ak\\u0131\\u015fkan i\\u00e7 dokusuyla; yan\\u0131nda Bel\\u00e7ika \\u00e7ikolatas\\u0131 sosu ile.\",\"category_id\":9,\"price_minor\":22000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":true,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":10,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":40}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(85,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',41,NULL,'{\"name\":\"\\u00c7ikolatal\\u0131 Sufle\",\"description\":\"S\\u0131cak ak\\u0131\\u015fkan \\u00e7ikolata; yan\\u0131nda vanilyal\\u0131 dondurma ile.\",\"category_id\":9,\"price_minor\":20000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":true,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":20,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":41}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(86,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',42,NULL,'{\"name\":\"Waffle\",\"description\":\"Taze waffle; \\u00e7ikolata sos, muz, dondurma ve f\\u0131nd\\u0131k ile.\",\"category_id\":9,\"price_minor\":18000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":true,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":30,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":42}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(87,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',43,NULL,'{\"name\":\"K\\u00fcnefe\",\"description\":\"Antep f\\u0131st\\u0131kl\\u0131 geleneksel k\\u00fcnefe. Dondurma ile servis.\",\"category_id\":9,\"price_minor\":25000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":40,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":43}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(88,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',44,NULL,'{\"name\":\"Tiramisu\",\"description\":\"Klasik \\u0130talyan tiramisu; mascarpone ve espresso ile.\",\"category_id\":9,\"price_minor\":21000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":50,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":44}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(89,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',45,NULL,'{\"name\":\"Magnolia\",\"description\":\"Muzlu magnolia; \\u00fcz\\u00fcm ve ceviz ile.\",\"category_id\":9,\"price_minor\":19000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":true,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":60,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":45}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(90,1,NULL,NULL,'categories.created','App\\Modules\\Catalog\\Models\\Category',10,NULL,'{\"name\":\"S\\u0131cak \\u0130\\u00e7ecekler\",\"slug\":\"sicak-icecekler\",\"description\":\"Kahve ve s\\u0131cak i\\u00e7ecekler\",\"available_from\":null,\"available_until\":null,\"sort_order\":100,\"is_active\":true,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":10}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(91,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',46,NULL,'{\"name\":\"T\\u00fcrk Kahvesi\",\"description\":\"Geleneksel lezzet, lokum ile servis.\",\"category_id\":10,\"price_minor\":8000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":10,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":46}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(92,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',47,NULL,'{\"name\":\"Espresso\",\"description\":\"\\u00c7ift shot espresso; yo\\u011fun ve aromatik.\",\"category_id\":10,\"price_minor\":9000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":20,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":47}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(93,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',48,NULL,'{\"name\":\"Americano\",\"description\":\"Espresso ve s\\u0131cak su. Hafif ve dengeli.\",\"category_id\":10,\"price_minor\":10000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":30,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":48}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(94,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',49,NULL,'{\"name\":\"Latte\",\"description\":\"Espresso ve buharda \\u0131s\\u0131t\\u0131lm\\u0131\\u015f s\\u00fct. Kremsi doku.\",\"category_id\":10,\"price_minor\":11000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":true,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":40,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":49}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(95,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',50,NULL,'{\"name\":\"Cappuccino\",\"description\":\"Espresso, s\\u00fct k\\u00f6p\\u00fc\\u011f\\u00fc ve kakao tozu ile.\",\"category_id\":10,\"price_minor\":11000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":50,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":50}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(96,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',51,NULL,'{\"name\":\"Mocha\",\"description\":\"Espresso, \\u00e7ikolata ve s\\u00fct. Krema ile.\",\"category_id\":10,\"price_minor\":13000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":60,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":51}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(97,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',52,NULL,'{\"name\":\"S\\u0131cak \\u00c7ikolata\",\"description\":\"Bel\\u00e7ika \\u00e7ikolatas\\u0131, s\\u00fct ve krema.\",\"category_id\":10,\"price_minor\":12000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":70,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":52}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(98,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',53,NULL,'{\"name\":\"Chai Latte\",\"description\":\"Baharatl\\u0131 chai ve buharda \\u0131s\\u0131t\\u0131lm\\u0131\\u015f s\\u00fct.\",\"category_id\":10,\"price_minor\":12000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":true,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":80,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:16.000000Z\",\"created_at\":\"2026-07-22T15:26:16.000000Z\",\"id\":53}','127.0.0.1','Symfony','2026-07-22 12:26:16'),
(99,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',54,NULL,'{\"name\":\"Filtre Kahve\",\"description\":\"G\\u00fcn\\u00fcn filtre kahvesi; zengin aroma.\",\"category_id\":10,\"price_minor\":8000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":90,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:17.000000Z\",\"created_at\":\"2026-07-22T15:26:17.000000Z\",\"id\":54}','127.0.0.1','Symfony','2026-07-22 12:26:17'),
(100,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',55,NULL,'{\"name\":\"\\u00c7ay (Bardak)\",\"description\":\"Rize \\u00e7ay\\u0131, demlik servis.\",\"category_id\":10,\"price_minor\":3000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":100,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:17.000000Z\",\"created_at\":\"2026-07-22T15:26:17.000000Z\",\"id\":55}','127.0.0.1','Symfony','2026-07-22 12:26:17'),
(101,1,NULL,NULL,'categories.created','App\\Modules\\Catalog\\Models\\Category',11,NULL,'{\"name\":\"So\\u011fuk \\u0130\\u00e7ecekler\",\"slug\":\"soguk-icecekler\",\"description\":\"Serinleten i\\u00e7ecekler\",\"available_from\":null,\"available_until\":null,\"sort_order\":110,\"is_active\":true,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:17.000000Z\",\"created_at\":\"2026-07-22T15:26:17.000000Z\",\"id\":11}','127.0.0.1','Symfony','2026-07-22 12:26:17'),
(102,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',56,NULL,'{\"name\":\"Ev Yap\\u0131m\\u0131 Limonata\",\"description\":\"Taze limon, nane ve \\u015feker ile.\",\"category_id\":11,\"price_minor\":10000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":true,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":10,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:17.000000Z\",\"created_at\":\"2026-07-22T15:26:17.000000Z\",\"id\":56}','127.0.0.1','Symfony','2026-07-22 12:26:17'),
(103,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',57,NULL,'{\"name\":\"Ice Americano\",\"description\":\"So\\u011fuk su ve buz \\u00fczerinde \\u00e7ift espresso.\",\"category_id\":11,\"price_minor\":12000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":20,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:17.000000Z\",\"created_at\":\"2026-07-22T15:26:17.000000Z\",\"id\":57}','127.0.0.1','Symfony','2026-07-22 12:26:17'),
(104,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',58,NULL,'{\"name\":\"Iced Latte\",\"description\":\"So\\u011fuk s\\u00fct ve buz \\u00fczerinde espresso.\",\"category_id\":11,\"price_minor\":13000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":true,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":30,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:17.000000Z\",\"created_at\":\"2026-07-22T15:26:17.000000Z\",\"id\":58}','127.0.0.1','Symfony','2026-07-22 12:26:17'),
(105,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',59,NULL,'{\"name\":\"Milkshake (\\u00c7ikolata)\",\"description\":\"Bel\\u00e7ika \\u00e7ikolatas\\u0131, s\\u00fct ve dondurma.\",\"category_id\":11,\"price_minor\":14000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":40,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:17.000000Z\",\"created_at\":\"2026-07-22T15:26:17.000000Z\",\"id\":59}','127.0.0.1','Symfony','2026-07-22 12:26:17'),
(106,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',60,NULL,'{\"name\":\"Mango Smoothie\",\"description\":\"Taze mango, muz ve portakal suyu.\",\"category_id\":11,\"price_minor\":15000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":50,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:17.000000Z\",\"created_at\":\"2026-07-22T15:26:17.000000Z\",\"id\":60}','127.0.0.1','Symfony','2026-07-22 12:26:17'),
(107,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',61,NULL,'{\"name\":\"Taze Portakal Suyu\",\"description\":\"S\\u0131kma taze portakal suyu.\",\"category_id\":11,\"price_minor\":10000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":60,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:17.000000Z\",\"created_at\":\"2026-07-22T15:26:17.000000Z\",\"id\":61}','127.0.0.1','Symfony','2026-07-22 12:26:17'),
(108,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',62,NULL,'{\"name\":\"Meyveli Soda\",\"description\":\"Limon, nar veya \\u015feftali aromal\\u0131 soda.\",\"category_id\":11,\"price_minor\":9000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":70,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:17.000000Z\",\"created_at\":\"2026-07-22T15:26:17.000000Z\",\"id\":62}','127.0.0.1','Symfony','2026-07-22 12:26:17'),
(109,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',63,NULL,'{\"name\":\"Mojito (Alkols\\u00fcz)\",\"description\":\"Nane, lime, \\u015feker ve soda.\",\"category_id\":11,\"price_minor\":11000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":true,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":80,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:17.000000Z\",\"created_at\":\"2026-07-22T15:26:17.000000Z\",\"id\":63}','127.0.0.1','Symfony','2026-07-22 12:26:17'),
(110,1,NULL,NULL,'categories.created','App\\Modules\\Catalog\\Models\\Category',12,NULL,'{\"name\":\"Nargile\",\"slug\":\"nargile\",\"description\":\"Premium nargile deneyimi\",\"available_from\":null,\"available_until\":null,\"sort_order\":120,\"is_active\":true,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:17.000000Z\",\"created_at\":\"2026-07-22T15:26:17.000000Z\",\"id\":12}','127.0.0.1','Symfony','2026-07-22 12:26:17'),
(111,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',64,NULL,'{\"name\":\"Klasik Nargile\",\"description\":\"Tek aroma, standart k\\u00f6z servisi. 60+ aroma se\\u00e7ene\\u011fi.\",\"category_id\":12,\"price_minor\":25000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":10,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:17.000000Z\",\"created_at\":\"2026-07-22T15:26:17.000000Z\",\"id\":64}','127.0.0.1','Symfony','2026-07-22 12:26:17'),
(112,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',65,NULL,'{\"name\":\"Premium Nargile\",\"description\":\"\\u00d6zel kar\\u0131\\u015f\\u0131m aroma, hindistan cevizi k\\u00f6z\\u00fc, buz aparat\\u0131 dahil.\",\"category_id\":12,\"price_minor\":35000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":true,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":20,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:17.000000Z\",\"created_at\":\"2026-07-22T15:26:17.000000Z\",\"id\":65}','127.0.0.1','Symfony','2026-07-22 12:26:17'),
(113,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',66,NULL,'{\"name\":\"VIP Nargile (\\u00d6zel Kar\\u0131\\u015f\\u0131m)\",\"description\":\"\\u015eefin \\u00f6zel aroma kar\\u0131\\u015f\\u0131m\\u0131, premium k\\u00f6z, meyve ba\\u015fl\\u0131\\u011f\\u0131 ve buz aparat\\u0131.\",\"category_id\":12,\"price_minor\":45000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":true,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":30,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:17.000000Z\",\"created_at\":\"2026-07-22T15:26:17.000000Z\",\"id\":66}','127.0.0.1','Symfony','2026-07-22 12:26:17'),
(114,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',67,NULL,'{\"name\":\"Meyve Ba\\u015fl\\u0131kl\\u0131 Nargile\",\"description\":\"Ananas, portakal veya karpuz ba\\u015fl\\u0131\\u011f\\u0131 ile nargile deneyimi.\",\"category_id\":12,\"price_minor\":40000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":false,\"is_chef_pick\":false,\"is_bestseller\":true,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":40,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:17.000000Z\",\"created_at\":\"2026-07-22T15:26:17.000000Z\",\"id\":67}','127.0.0.1','Symfony','2026-07-22 12:26:17'),
(115,1,NULL,NULL,'products.created','App\\Modules\\Catalog\\Models\\Product',68,NULL,'{\"name\":\"Buz Nargile\",\"description\":\"Buzlu nargile deneyimi; mentol aroma, buz aparat\\u0131.\",\"category_id\":12,\"price_minor\":38000,\"currency\":\"TRY\",\"tax_rate\":\"10.00\",\"prep_minutes\":15,\"unit\":\"porsiyon\",\"is_new\":true,\"is_chef_pick\":false,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"min_order_qty\":1,\"sort_order\":50,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:17.000000Z\",\"created_at\":\"2026-07-22T15:26:17.000000Z\",\"id\":68}','127.0.0.1','Symfony','2026-07-22 12:26:17'),
(116,1,NULL,NULL,'menus.created','App\\Modules\\Catalog\\Models\\Menu',1,NULL,'{\"name\":\"Kahvalt\\u0131 Men\\u00fcs\\u00fc\",\"description\":\"Sabah servisi\",\"days\":[1,2,3,4,5,6,7],\"start_time\":\"07:00\",\"end_time\":\"13:00\",\"channels\":null,\"sort_order\":10,\"is_active\":true,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:17.000000Z\",\"created_at\":\"2026-07-22T15:26:17.000000Z\",\"id\":1}','127.0.0.1','Symfony','2026-07-22 12:26:17'),
(117,1,NULL,NULL,'menus.created','App\\Modules\\Catalog\\Models\\Menu',2,NULL,'{\"name\":\"\\u00d6\\u011fle Men\\u00fcs\\u00fc\",\"description\":\"\\u00d6\\u011fle servisi\",\"days\":[1,2,3,4,5,6,7],\"start_time\":\"12:00\",\"end_time\":\"17:00\",\"channels\":null,\"sort_order\":20,\"is_active\":true,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:17.000000Z\",\"created_at\":\"2026-07-22T15:26:17.000000Z\",\"id\":2}','127.0.0.1','Symfony','2026-07-22 12:26:17'),
(118,1,NULL,NULL,'menus.created','App\\Modules\\Catalog\\Models\\Menu',3,NULL,'{\"name\":\"Ak\\u015fam Men\\u00fcs\\u00fc\",\"description\":\"Ak\\u015fam servisi\",\"days\":[1,2,3,4,5,6,7],\"start_time\":\"17:00\",\"end_time\":\"23:30\",\"channels\":null,\"sort_order\":30,\"is_active\":true,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:17.000000Z\",\"created_at\":\"2026-07-22T15:26:17.000000Z\",\"id\":3}','127.0.0.1','Symfony','2026-07-22 12:26:17'),
(119,1,NULL,NULL,'menus.created','App\\Modules\\Catalog\\Models\\Menu',4,NULL,'{\"name\":\"Hafta Sonu Tatl\\u0131 & Kahve\",\"description\":\"Hafta sonu ikindi servisi\",\"days\":[6,7],\"start_time\":\"14:00\",\"end_time\":\"19:00\",\"channels\":null,\"sort_order\":40,\"is_active\":true,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:26:17.000000Z\",\"created_at\":\"2026-07-22T15:26:17.000000Z\",\"id\":4}','127.0.0.1','Symfony','2026-07-22 12:26:17'),
(120,1,1,2,'auth.login','App\\Modules\\Identity\\Models\\User',2,NULL,NULL,'46.224.208.126','curl/7.61.1','2026-07-22 12:27:46'),
(121,1,1,2,'tables.created','App\\Modules\\Tables\\Models\\Table',1,NULL,'{\"name\":\"Teras 1\",\"number\":1,\"capacity\":4,\"shape\":\"square\",\"is_joinable\":true,\"branch_id\":1,\"area_id\":null,\"tenant_id\":1,\"qr_token\":\"5C5J5UAFDITI72TS4FDI55SFHQ\",\"updated_at\":\"2026-07-22T15:27:55.000000Z\",\"created_at\":\"2026-07-22T15:27:55.000000Z\",\"id\":1}','46.224.208.126','curl/7.61.1','2026-07-22 12:27:55'),
(122,1,1,2,'tables.created','App\\Modules\\Tables\\Models\\Table',2,NULL,'{\"name\":\"Teras 2\",\"number\":2,\"capacity\":4,\"shape\":\"square\",\"is_joinable\":true,\"branch_id\":1,\"area_id\":null,\"tenant_id\":1,\"qr_token\":\"L6Z2KCRQMQI5YNSLWYJUAKVJCY\",\"updated_at\":\"2026-07-22T15:27:55.000000Z\",\"created_at\":\"2026-07-22T15:27:55.000000Z\",\"id\":2}','46.224.208.126','curl/7.61.1','2026-07-22 12:27:55'),
(123,1,1,2,'tables.created','App\\Modules\\Tables\\Models\\Table',3,NULL,'{\"name\":\"Teras 3\",\"number\":3,\"capacity\":4,\"shape\":\"square\",\"is_joinable\":true,\"branch_id\":1,\"area_id\":null,\"tenant_id\":1,\"qr_token\":\"VCTEDUIHFNATIZHDEULG22DCBQ\",\"updated_at\":\"2026-07-22T15:27:55.000000Z\",\"created_at\":\"2026-07-22T15:27:55.000000Z\",\"id\":3}','46.224.208.126','curl/7.61.1','2026-07-22 12:27:55'),
(124,1,1,2,'tables.created','App\\Modules\\Tables\\Models\\Table',4,NULL,'{\"name\":\"Teras 4\",\"number\":4,\"capacity\":4,\"shape\":\"square\",\"is_joinable\":true,\"branch_id\":1,\"area_id\":null,\"tenant_id\":1,\"qr_token\":\"WCRDIJTYVSZHXAE5TCUWFC277E\",\"updated_at\":\"2026-07-22T15:27:55.000000Z\",\"created_at\":\"2026-07-22T15:27:55.000000Z\",\"id\":4}','46.224.208.126','curl/7.61.1','2026-07-22 12:27:55'),
(125,1,1,2,'tables.created','App\\Modules\\Tables\\Models\\Table',5,NULL,'{\"name\":\"Teras 5\",\"number\":5,\"capacity\":4,\"shape\":\"square\",\"is_joinable\":true,\"branch_id\":1,\"area_id\":null,\"tenant_id\":1,\"qr_token\":\"MORZ4NOWRJHUMREW7XR5QWEQGU\",\"updated_at\":\"2026-07-22T15:27:55.000000Z\",\"created_at\":\"2026-07-22T15:27:55.000000Z\",\"id\":5}','46.224.208.126','curl/7.61.1','2026-07-22 12:27:55'),
(126,1,1,2,'tables.updated','App\\Modules\\Tables\\Models\\Table',5,'{\"qr_token\":\"MORZ4NOWRJHUMREW7XR5QWEQGU\",\"previous_qr_token\":null,\"qr_rotated_at\":null}','{\"qr_token\":\"D3XO2MWRTGXUUKGUJOAEA5GZ4E\",\"previous_qr_token\":\"MORZ4NOWRJHUMREW7XR5QWEQGU\",\"qr_rotated_at\":\"2026-07-22 15:28:19\"}','46.224.208.126','curl/7.61.1','2026-07-22 12:28:19'),
(127,1,NULL,1,'products.created','App\\Modules\\Catalog\\Models\\Product',69,NULL,'{\"name\":\"F\\u0131st\\u0131kl\\u0131 Baklava (4 Dilim)\",\"description\":\"Antep f\\u0131st\\u0131kl\\u0131 el a\\u00e7mas\\u0131 baklava; kaymak e\\u015fli\\u011finde servis edilir.\",\"sku\":\"TTL-BKL-01\",\"barcode\":null,\"category_id\":9,\"price_minor\":24000,\"cost_minor\":9500,\"package_price_minor\":null,\"kiosk_price_minor\":null,\"qr_price_minor\":null,\"discounted_price_minor\":null,\"tax_rate\":\"10.00\",\"portion\":\"4 dilim\",\"unit\":\"porsiyon\",\"prep_minutes\":10,\"calories\":null,\"protein\":null,\"carbs\":null,\"fat\":null,\"spiciness\":0,\"is_new\":false,\"is_chef_pick\":true,\"is_bestseller\":false,\"is_active\":true,\"is_available\":true,\"available_from\":null,\"available_until\":null,\"station\":null,\"track_stock\":false,\"stock_quantity\":null,\"min_order_qty\":1,\"max_order_qty\":null,\"channels\":[\"qr\",\"kiosk\",\"package\",\"pos\"],\"sort_order\":110,\"tenant_id\":1,\"updated_at\":\"2026-07-22T15:29:40.000000Z\",\"created_at\":\"2026-07-22T15:29:40.000000Z\",\"id\":69}','46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.0.0 Safari/537.36','2026-07-22 12:29:40'),
(128,1,1,2,'auth.login','App\\Modules\\Identity\\Models\\User',2,NULL,NULL,'46.224.208.126','curl/7.61.1','2026-07-22 12:36:10'),
(129,1,1,2,'auth.login','App\\Modules\\Identity\\Models\\User',2,NULL,NULL,'46.224.208.126','curl/7.61.1','2026-07-22 13:11:59'),
(130,1,1,2,'orders.created','App\\Modules\\Orders\\Models\\Order',1,NULL,'{\"status\":\"placed\",\"channel\":\"table\",\"guest_count\":null,\"note\":null,\"customer_name\":null,\"customer_phone\":null,\"branch_id\":1,\"table_id\":1,\"opened_by_id\":2,\"placed_at\":\"2026-07-22T16:11:59.000000Z\",\"tenant_id\":1,\"updated_at\":\"2026-07-22T16:11:59.000000Z\",\"created_at\":\"2026-07-22T16:11:59.000000Z\",\"id\":1}','46.224.208.126','curl/7.61.1','2026-07-22 13:11:59'),
(131,1,1,2,'tables.updated','App\\Modules\\Tables\\Models\\Table',1,'{\"status\":\"available\"}','{\"status\":\"order_taken\"}','46.224.208.126','curl/7.61.1','2026-07-22 13:11:59'),
(132,1,1,2,'auth.login','App\\Modules\\Identity\\Models\\User',2,NULL,NULL,'46.224.208.126','curl/7.61.1','2026-07-22 13:12:25'),
(133,1,1,2,'orders.created','App\\Modules\\Orders\\Models\\Order',2,NULL,'{\"status\":\"placed\",\"channel\":\"table\",\"guest_count\":null,\"note\":null,\"customer_name\":null,\"customer_phone\":null,\"branch_id\":1,\"table_id\":2,\"opened_by_id\":2,\"placed_at\":\"2026-07-22T16:12:26.000000Z\",\"tenant_id\":1,\"updated_at\":\"2026-07-22T16:12:26.000000Z\",\"created_at\":\"2026-07-22T16:12:26.000000Z\",\"id\":2}','46.224.208.126','curl/7.61.1','2026-07-22 13:12:26'),
(134,1,1,2,'tables.updated','App\\Modules\\Tables\\Models\\Table',2,'{\"status\":\"available\"}','{\"status\":\"order_taken\"}','46.224.208.126','curl/7.61.1','2026-07-22 13:12:26'),
(135,1,1,2,'orders.updated','App\\Modules\\Orders\\Models\\Order',2,'{\"version\":0,\"total_minor\":0,\"items_total_minor\":0,\"vat_total_minor\":0}','{\"version\":1,\"total_minor\":32000,\"items_total_minor\":32000,\"vat_total_minor\":2909}','46.224.208.126','curl/7.61.1','2026-07-22 13:12:26'),
(136,1,1,2,'orders.cancelled','App\\Modules\\Orders\\Models\\Order',2,'{\"status\":\"placed\"}','{\"reason\":\"eszamanlilik kaniti - temizlik\",\"previous_total_minor\":32000,\"performed_by\":2}','46.224.208.126','curl/7.61.1','2026-07-22 13:12:26'),
(137,1,1,2,'orders.updated','App\\Modules\\Orders\\Models\\Order',2,'{\"status\":\"placed\",\"closed_at\":null,\"cancelled_at\":null,\"cancel_reason\":null,\"cancelled_by_id\":null}','{\"status\":\"cancelled\",\"closed_at\":\"2026-07-22 16:12:26\",\"cancelled_at\":\"2026-07-22 16:12:26\",\"cancel_reason\":\"eszamanlilik kaniti - temizlik\",\"cancelled_by_id\":2}','46.224.208.126','curl/7.61.1','2026-07-22 13:12:26'),
(138,1,1,2,'tables.updated','App\\Modules\\Tables\\Models\\Table',2,'{\"status\":\"order_taken\"}','{\"status\":\"available\"}','46.224.208.126','curl/7.61.1','2026-07-22 13:12:26'),
(139,1,1,2,'orders.updated','App\\Modules\\Orders\\Models\\Order',2,'{\"version\":1}','{\"version\":2}','46.224.208.126','curl/7.61.1','2026-07-22 13:12:26'),
(140,1,1,NULL,'orders.created','App\\Modules\\Orders\\Models\\Order',3,NULL,'{\"status\":\"pending_approval\",\"channel\":\"qr\",\"note\":null,\"customer_name\":null,\"tenant_id\":1,\"branch_id\":1,\"table_id\":1,\"public_token\":\"WEMDDCVPD7RMZOFIMTOMCFWA4A\",\"updated_at\":\"2026-07-22T16:14:48.000000Z\",\"created_at\":\"2026-07-22T16:14:48.000000Z\",\"id\":3}','88.235.200.157','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/150.0.7871.113 Mobile/15E148 Safari/604.1','2026-07-22 13:14:48'),
(141,1,1,NULL,'orders.updated','App\\Modules\\Orders\\Models\\Order',3,'[]','{\"items_total_minor\":16500,\"comp_total_minor\":0,\"vat_total_minor\":1500,\"discount_minor\":0,\"total_minor\":16500}','88.235.200.157','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/150.0.7871.113 Mobile/15E148 Safari/604.1','2026-07-22 13:14:48'),
(142,1,1,NULL,'orders.created','App\\Modules\\Orders\\Models\\Order',4,NULL,'{\"status\":\"pending_approval\",\"channel\":\"qr\",\"note\":null,\"customer_name\":\"Canl\\u0131 Kan\\u0131t\",\"tenant_id\":1,\"branch_id\":1,\"table_id\":1,\"public_token\":\"EQAY7ERTCDJ3SDLFMLCHMTNHXM\",\"updated_at\":\"2026-07-22T16:20:21.000000Z\",\"created_at\":\"2026-07-22T16:20:21.000000Z\",\"id\":4}','46.224.208.126','curl/7.61.1','2026-07-22 13:20:21'),
(143,1,1,NULL,'orders.updated','App\\Modules\\Orders\\Models\\Order',4,'[]','{\"items_total_minor\":32000,\"comp_total_minor\":0,\"vat_total_minor\":2909,\"discount_minor\":0,\"total_minor\":32000}','46.224.208.126','curl/7.61.1','2026-07-22 13:20:21'),
(144,1,1,2,'auth.login','App\\Modules\\Identity\\Models\\User',2,NULL,NULL,'46.224.208.126','curl/7.61.1','2026-07-22 13:20:44'),
(145,1,1,2,'orders.cancelled','App\\Modules\\Orders\\Models\\Order',4,'{\"status\":\"pending_approval\"}','{\"reason\":\"canl\\u0131 kan\\u0131t temizli\\u011fi\",\"previous_total_minor\":32000,\"performed_by\":2}','46.224.208.126','curl/7.61.1','2026-07-22 13:20:44'),
(146,1,1,2,'orders.updated','App\\Modules\\Orders\\Models\\Order',4,'{\"status\":\"pending_approval\",\"closed_at\":null,\"cancelled_at\":null,\"cancel_reason\":null,\"cancelled_by_id\":null}','{\"status\":\"cancelled\",\"closed_at\":\"2026-07-22 16:20:44\",\"cancelled_at\":\"2026-07-22 16:20:44\",\"cancel_reason\":\"canl\\u0131 kan\\u0131t temizli\\u011fi\",\"cancelled_by_id\":2}','46.224.208.126','curl/7.61.1','2026-07-22 13:20:44'),
(147,1,1,2,'orders.updated','App\\Modules\\Orders\\Models\\Order',4,'{\"version\":0}','{\"version\":1}','46.224.208.126','curl/7.61.1','2026-07-22 13:20:44'),
(148,1,1,2,'auth.login','App\\Modules\\Identity\\Models\\User',2,NULL,NULL,'46.224.208.126','curl/7.61.1','2026-07-22 13:21:03'),
(149,1,1,2,'orders.cancelled','App\\Modules\\Orders\\Models\\Order',1,'{\"status\":\"placed\"}','{\"reason\":\"bo\\u015f test adisyonu temizli\\u011fi\",\"previous_total_minor\":0,\"performed_by\":2}','46.224.208.126','curl/7.61.1','2026-07-22 13:21:03'),
(150,1,1,2,'orders.updated','App\\Modules\\Orders\\Models\\Order',1,'{\"status\":\"placed\",\"closed_at\":null,\"cancelled_at\":null,\"cancel_reason\":null,\"cancelled_by_id\":null}','{\"status\":\"cancelled\",\"closed_at\":\"2026-07-22 16:21:03\",\"cancelled_at\":\"2026-07-22 16:21:03\",\"cancel_reason\":\"bo\\u015f test adisyonu temizli\\u011fi\",\"cancelled_by_id\":2}','46.224.208.126','curl/7.61.1','2026-07-22 13:21:03'),
(151,1,1,2,'tables.updated','App\\Modules\\Tables\\Models\\Table',1,'{\"status\":\"order_taken\"}','{\"status\":\"awaiting_order\"}','46.224.208.126','curl/7.61.1','2026-07-22 13:21:03'),
(152,1,1,2,'orders.updated','App\\Modules\\Orders\\Models\\Order',1,'{\"version\":0}','{\"version\":1}','46.224.208.126','curl/7.61.1','2026-07-22 13:21:03'),
(153,1,1,2,'auth.login','App\\Modules\\Identity\\Models\\User',2,NULL,NULL,'46.224.208.126','curl/7.61.1','2026-07-22 13:21:16'),
(154,1,1,2,'auth.login','App\\Modules\\Identity\\Models\\User',2,NULL,NULL,'46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 13:22:10'),
(155,1,1,2,'auth.login','App\\Modules\\Identity\\Models\\User',2,NULL,NULL,'46.224.208.126','curl/7.61.1','2026-07-22 13:26:11'),
(156,1,1,2,'orders.updated','App\\Modules\\Orders\\Models\\Order',3,'{\"status\":\"pending_approval\",\"placed_at\":null}','{\"status\":\"placed\",\"placed_at\":\"2026-07-22 16:28:00\"}','88.235.200.157','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-22 13:28:00'),
(157,1,1,2,'tables.updated','App\\Modules\\Tables\\Models\\Table',1,'{\"status\":\"awaiting_order\"}','{\"status\":\"order_taken\"}','88.235.200.157','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-22 13:28:00'),
(158,1,1,2,'orders.updated','App\\Modules\\Orders\\Models\\Order',3,'{\"version\":0}','{\"version\":1}','88.235.200.157','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-22 13:28:00'),
(159,1,1,2,'orders.updated','App\\Modules\\Orders\\Models\\Order',3,'{\"version\":1,\"total_minor\":16500,\"items_total_minor\":16500,\"vat_total_minor\":1500}','{\"version\":2,\"total_minor\":101500,\"items_total_minor\":101500,\"vat_total_minor\":9227}','88.235.200.157','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-22 13:28:24'),
(160,1,1,2,'orders.updated','App\\Modules\\Orders\\Models\\Order',3,'{\"status\":\"placed\"}','{\"status\":\"bill_requested\"}','88.235.200.157','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-22 13:28:28'),
(161,1,1,2,'tables.updated','App\\Modules\\Tables\\Models\\Table',1,'{\"status\":\"order_taken\"}','{\"status\":\"bill_requested\"}','88.235.200.157','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-22 13:28:28'),
(162,1,1,2,'orders.updated','App\\Modules\\Orders\\Models\\Order',3,'{\"version\":2}','{\"version\":3}','88.235.200.157','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-22 13:28:28'),
(163,1,1,2,'orders.updated','App\\Modules\\Orders\\Models\\Order',3,'{\"version\":3,\"total_minor\":101500,\"items_total_minor\":101500,\"vat_total_minor\":9227}','{\"version\":4,\"total_minor\":85000,\"items_total_minor\":85000,\"vat_total_minor\":7727}','88.235.200.157','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-22 13:29:10'),
(164,1,1,2,'orders.updated','App\\Modules\\Orders\\Models\\Order',3,'{\"version\":4,\"total_minor\":85000,\"items_total_minor\":85000,\"vat_total_minor\":7727}','{\"version\":5,\"total_minor\":0,\"items_total_minor\":0,\"vat_total_minor\":0}','88.235.200.157','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-22 13:29:12'),
(165,1,1,2,'orders.cancelled','App\\Modules\\Orders\\Models\\Order',3,'{\"status\":\"bill_requested\"}','{\"reason\":\"test\",\"previous_total_minor\":0,\"performed_by\":2}','88.235.200.157','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-22 13:29:26'),
(166,1,1,2,'orders.updated','App\\Modules\\Orders\\Models\\Order',3,'{\"status\":\"bill_requested\",\"closed_at\":null,\"cancelled_at\":null,\"cancel_reason\":null,\"cancelled_by_id\":null}','{\"status\":\"cancelled\",\"closed_at\":\"2026-07-22 16:29:26\",\"cancelled_at\":\"2026-07-22 16:29:26\",\"cancel_reason\":\"test\",\"cancelled_by_id\":2}','88.235.200.157','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-22 13:29:26'),
(167,1,1,2,'tables.updated','App\\Modules\\Tables\\Models\\Table',1,'{\"status\":\"bill_requested\"}','{\"status\":\"available\"}','88.235.200.157','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-22 13:29:26'),
(168,1,1,2,'orders.updated','App\\Modules\\Orders\\Models\\Order',3,'{\"version\":5}','{\"version\":6}','88.235.200.157','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-22 13:29:26'),
(169,1,1,2,'auth.login','App\\Modules\\Identity\\Models\\User',2,NULL,NULL,'88.235.200.157','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/150.0.7871.113 Mobile/15E148 Safari/604.1','2026-07-22 13:31:17'),
(170,1,1,2,'orders.created','App\\Modules\\Orders\\Models\\Order',5,NULL,'{\"status\":\"placed\",\"channel\":\"table\",\"guest_count\":4,\"note\":null,\"customer_name\":null,\"customer_phone\":null,\"branch_id\":1,\"table_id\":1,\"opened_by_id\":2,\"placed_at\":\"2026-07-22T16:32:08.000000Z\",\"tenant_id\":1,\"updated_at\":\"2026-07-22T16:32:08.000000Z\",\"created_at\":\"2026-07-22T16:32:08.000000Z\",\"id\":5}','88.235.200.157','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/150.0.7871.113 Mobile/15E148 Safari/604.1','2026-07-22 13:32:08'),
(171,1,1,2,'tables.updated','App\\Modules\\Tables\\Models\\Table',1,'{\"status\":\"available\"}','{\"status\":\"order_taken\"}','88.235.200.157','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/150.0.7871.113 Mobile/15E148 Safari/604.1','2026-07-22 13:32:08'),
(172,1,NULL,NULL,'roles.created','App\\Modules\\Identity\\Models\\Role',5,NULL,'{\"name\":\"Mutfak\",\"slug\":\"mutfak\",\"description\":\"Mutfak rol\\u00fc\",\"tenant_id\":1,\"is_system\":false,\"updated_at\":\"2026-07-22T16:56:27.000000Z\",\"created_at\":\"2026-07-22T16:56:27.000000Z\",\"id\":5}','127.0.0.1','Symfony','2026-07-22 13:56:27'),
(173,1,NULL,NULL,'roles.created','App\\Modules\\Identity\\Models\\Role',6,NULL,'{\"name\":\"Komi\",\"slug\":\"komi\",\"description\":\"Komi rol\\u00fc\",\"tenant_id\":1,\"is_system\":false,\"updated_at\":\"2026-07-22T16:56:27.000000Z\",\"created_at\":\"2026-07-22T16:56:27.000000Z\",\"id\":6}','127.0.0.1','Symfony','2026-07-22 13:56:27'),
(174,1,1,2,'auth.login','App\\Modules\\Identity\\Models\\User',2,NULL,NULL,'46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 13:58:15'),
(175,1,1,2,'orders.created','App\\Modules\\Orders\\Models\\Order',6,NULL,'{\"status\":\"placed\",\"channel\":\"table\",\"guest_count\":2,\"note\":\"KDS kan\\u0131t sipari\\u015fi \\u2014 az ac\\u0131l\\u0131 olsun\",\"customer_name\":null,\"customer_phone\":null,\"branch_id\":1,\"table_id\":2,\"opened_by_id\":2,\"placed_at\":\"2026-07-22T16:58:16.000000Z\",\"tenant_id\":1,\"updated_at\":\"2026-07-22T16:58:16.000000Z\",\"created_at\":\"2026-07-22T16:58:16.000000Z\",\"id\":6}','46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 13:58:16'),
(176,1,1,2,'tables.updated','App\\Modules\\Tables\\Models\\Table',2,'{\"status\":\"available\"}','{\"status\":\"order_taken\"}','46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 13:58:16'),
(177,1,1,2,'orders.updated','App\\Modules\\Orders\\Models\\Order',6,'{\"version\":0,\"total_minor\":0,\"items_total_minor\":0,\"vat_total_minor\":0}','{\"version\":1,\"total_minor\":32000,\"items_total_minor\":32000,\"vat_total_minor\":2909}','46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 13:58:16'),
(178,1,1,2,'orders.updated','App\\Modules\\Orders\\Models\\Order',6,'{\"version\":1,\"total_minor\":32000,\"items_total_minor\":32000,\"vat_total_minor\":2909}','{\"version\":2,\"total_minor\":52000,\"items_total_minor\":52000,\"vat_total_minor\":4727}','46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 13:58:16'),
(179,1,1,2,'orders.updated','App\\Modules\\Orders\\Models\\Order',6,'{\"version\":2,\"total_minor\":52000,\"items_total_minor\":52000,\"vat_total_minor\":4727}','{\"version\":3,\"total_minor\":74000,\"items_total_minor\":74000,\"vat_total_minor\":6727}','46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 13:58:16'),
(180,1,1,2,'orders.updated','App\\Modules\\Orders\\Models\\Order',6,'{\"version\":3}','{\"version\":4}','46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 13:58:23'),
(181,1,1,2,'orders.updated','App\\Modules\\Orders\\Models\\Order',6,'{\"status\":\"placed\"}','{\"status\":\"preparing\"}','46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 13:58:24'),
(182,1,1,2,'tables.updated','App\\Modules\\Tables\\Models\\Table',2,'{\"status\":\"order_taken\"}','{\"status\":\"preparing\"}','46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 13:58:24'),
(183,1,1,2,'orders.updated','App\\Modules\\Orders\\Models\\Order',6,'{\"version\":4}','{\"version\":5}','46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 13:58:24'),
(184,1,1,2,'orders.updated','App\\Modules\\Orders\\Models\\Order',6,'{\"status\":\"preparing\"}','{\"status\":\"partially_ready\"}','46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 13:58:25'),
(185,1,1,2,'orders.updated','App\\Modules\\Orders\\Models\\Order',6,'{\"version\":5}','{\"version\":6}','46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 13:58:25'),
(186,1,1,2,'orders.updated','App\\Modules\\Orders\\Models\\Order',6,'{\"version\":6}','{\"version\":7}','46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 13:58:27'),
(187,1,1,2,'orders.updated','App\\Modules\\Orders\\Models\\Order',6,'{\"status\":\"partially_ready\"}','{\"status\":\"ready\"}','46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 13:58:27'),
(188,1,1,2,'tables.updated','App\\Modules\\Tables\\Models\\Table',2,'{\"status\":\"preparing\"}','{\"status\":\"awaiting_service\"}','46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 13:58:27'),
(189,1,1,2,'orders.updated','App\\Modules\\Orders\\Models\\Order',6,'{\"version\":7}','{\"version\":8}','46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 13:58:27'),
(190,1,1,2,'orders.updated','App\\Modules\\Orders\\Models\\Order',6,'{\"version\":8}','{\"version\":9}','46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 13:58:33'),
(191,1,1,2,'auth.login','App\\Modules\\Identity\\Models\\User',2,NULL,NULL,'46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 14:01:22'),
(192,1,1,2,'orders.created','App\\Modules\\Orders\\Models\\Order',7,NULL,'{\"status\":\"placed\",\"channel\":\"table\",\"guest_count\":4,\"note\":\"Do\\u011fum g\\u00fcn\\u00fc masas\\u0131 \\u2014 pastaya mum eklenecek\",\"customer_name\":null,\"customer_phone\":null,\"branch_id\":1,\"table_id\":3,\"opened_by_id\":2,\"placed_at\":\"2026-07-22T17:01:22.000000Z\",\"tenant_id\":1,\"updated_at\":\"2026-07-22T17:01:22.000000Z\",\"created_at\":\"2026-07-22T17:01:22.000000Z\",\"id\":7}','46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 14:01:22'),
(193,1,1,2,'tables.updated','App\\Modules\\Tables\\Models\\Table',3,'{\"status\":\"available\"}','{\"status\":\"order_taken\"}','46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 14:01:22'),
(194,1,1,2,'orders.updated','App\\Modules\\Orders\\Models\\Order',7,'{\"version\":0,\"total_minor\":0,\"items_total_minor\":0,\"vat_total_minor\":0}','{\"version\":1,\"total_minor\":32000,\"items_total_minor\":32000,\"vat_total_minor\":2909}','46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 14:01:22'),
(195,1,1,2,'orders.updated','App\\Modules\\Orders\\Models\\Order',7,'{\"version\":1,\"total_minor\":32000,\"items_total_minor\":32000,\"vat_total_minor\":2909}','{\"version\":2,\"total_minor\":57000,\"items_total_minor\":57000,\"vat_total_minor\":5182}','46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 14:01:23'),
(196,1,1,2,'orders.updated','App\\Modules\\Orders\\Models\\Order',7,'{\"version\":2,\"total_minor\":57000,\"items_total_minor\":57000,\"vat_total_minor\":5182}','{\"version\":3,\"total_minor\":65000,\"items_total_minor\":65000,\"vat_total_minor\":5909}','46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 14:01:23'),
(201,1,1,2,'auth.login','App\\Modules\\Identity\\Models\\User',2,NULL,NULL,'149.86.151.79','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-22 16:56:36'),
(202,1,1,2,'auth.login','App\\Modules\\Identity\\Models\\User',2,NULL,NULL,'46.224.208.126','curl/7.61.1','2026-07-22 16:57:25');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `branches`
--

DROP TABLE IF EXISTS `branches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `branches` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(32) DEFAULT NULL,
  `address` varchar(500) DEFAULT NULL,
  `phone` varchar(32) DEFAULT NULL,
  `timezone` varchar(64) NOT NULL DEFAULT 'Europe/Istanbul',
  `qr_token` char(26) DEFAULT NULL,
  `previous_qr_token` char(26) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `branches_tenant_id_code_unique` (`tenant_id`,`code`),
  UNIQUE KEY `branches_qr_token_unique` (`qr_token`),
  KEY `branches_tenant_id_is_active_index` (`tenant_id`,`is_active`),
  KEY `branches_previous_qr_token_index` (`previous_qr_token`),
  CONSTRAINT `branches_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branches`
--

LOCK TABLES `branches` WRITE;
/*!40000 ALTER TABLE `branches` DISABLE KEYS */;
INSERT INTO `branches` VALUES
(1,1,'Merkez Şube','MERKEZ',NULL,NULL,'Europe/Istanbul','MI4YRNSWUYSTQDM3SFBLM7UF7E',NULL,1,'2026-07-22 11:21:41','2026-07-22 12:30:35');
/*!40000 ALTER TABLE `branches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` bigint(20) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES
('qr-menu-cache-public-order:0ae54cdfcc73c4438849a7a76bea17f8d8e2c5be','i:2;',1784737281),
('qr-menu-cache-public-order:0ae54cdfcc73c4438849a7a76bea17f8d8e2c5be:timer','i:1784737281;',1784737281),
('qr-menu-cache-qr-scan:6e4d85369663cc5c038e7894646974fb8a2407e2','i:1;',1784750255),
('qr-menu-cache-qr-scan:6e4d85369663cc5c038e7894646974fb8a2407e2:timer','i:1784750255;',1784750255),
('qr-menu-cache-qr-scan:7ac3eae4e01f9f519b06e49408eab0b0a2f7237d','i:1;',1784739791),
('qr-menu-cache-qr-scan:7ac3eae4e01f9f519b06e49408eab0b0a2f7237d:timer','i:1784739791;',1784739791),
('qr-menu-cache-service-req:0ae54cdfcc73c4438849a7a76bea17f8d8e2c5be','i:2;',1784737281),
('qr-menu-cache-service-req:0ae54cdfcc73c4438849a7a76bea17f8d8e2c5be:timer','i:1784737281;',1784737281);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` bigint(20) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cash_movements`
--

DROP TABLE IF EXISTS `cash_movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cash_movements` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `branch_id` bigint(20) unsigned NOT NULL,
  `cash_session_id` bigint(20) unsigned NOT NULL,
  `type` varchar(20) NOT NULL,
  `direction` varchar(3) NOT NULL,
  `amount_minor` bigint(20) unsigned NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `payment_id` bigint(20) unsigned DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `reverses_id` bigint(20) unsigned DEFAULT NULL,
  `reversed_by_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `cash_movements_branch_id_foreign` (`branch_id`),
  KEY `cash_movements_cash_session_id_foreign` (`cash_session_id`),
  KEY `cash_movements_payment_id_foreign` (`payment_id`),
  KEY `cash_movements_user_id_foreign` (`user_id`),
  KEY `cash_movements_reverses_id_foreign` (`reverses_id`),
  KEY `cash_movements_reversed_by_id_foreign` (`reversed_by_id`),
  KEY `cash_movements_tenant_id_cash_session_id_index` (`tenant_id`,`cash_session_id`),
  CONSTRAINT `cash_movements_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cash_movements_cash_session_id_foreign` FOREIGN KEY (`cash_session_id`) REFERENCES `cash_sessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cash_movements_payment_id_foreign` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `cash_movements_reversed_by_id_foreign` FOREIGN KEY (`reversed_by_id`) REFERENCES `cash_movements` (`id`),
  CONSTRAINT `cash_movements_reverses_id_foreign` FOREIGN KEY (`reverses_id`) REFERENCES `cash_movements` (`id`),
  CONSTRAINT `cash_movements_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cash_movements_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cash_movements`
--

LOCK TABLES `cash_movements` WRITE;
/*!40000 ALTER TABLE `cash_movements` DISABLE KEYS */;
/*!40000 ALTER TABLE `cash_movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cash_registers`
--

DROP TABLE IF EXISTS `cash_registers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cash_registers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `branch_id` bigint(20) unsigned NOT NULL,
  `name` varchar(80) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cash_registers_tenant_id_branch_id_name_unique` (`tenant_id`,`branch_id`,`name`),
  KEY `cash_registers_branch_id_foreign` (`branch_id`),
  CONSTRAINT `cash_registers_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cash_registers_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cash_registers`
--

LOCK TABLES `cash_registers` WRITE;
/*!40000 ALTER TABLE `cash_registers` DISABLE KEYS */;
/*!40000 ALTER TABLE `cash_registers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cash_sessions`
--

DROP TABLE IF EXISTS `cash_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cash_sessions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `branch_id` bigint(20) unsigned NOT NULL,
  `cash_register_id` bigint(20) unsigned NOT NULL,
  `z_number` int(10) unsigned NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'open',
  `opening_float_minor` bigint(20) unsigned NOT NULL DEFAULT 0,
  `opened_by_id` bigint(20) unsigned DEFAULT NULL,
  `opened_at` timestamp NULL DEFAULT NULL,
  `closed_by_id` bigint(20) unsigned DEFAULT NULL,
  `closed_at` timestamp NULL DEFAULT NULL,
  `expected_cash_minor` bigint(20) unsigned DEFAULT NULL,
  `counted_cash_minor` bigint(20) unsigned DEFAULT NULL,
  `difference_minor` bigint(20) DEFAULT NULL,
  `closing_note` varchar(500) DEFAULT NULL,
  `summary` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`summary`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cash_sessions_cash_register_id_z_number_unique` (`cash_register_id`,`z_number`),
  KEY `cash_sessions_branch_id_foreign` (`branch_id`),
  KEY `cash_sessions_opened_by_id_foreign` (`opened_by_id`),
  KEY `cash_sessions_closed_by_id_foreign` (`closed_by_id`),
  KEY `cash_sessions_tenant_id_branch_id_status_index` (`tenant_id`,`branch_id`,`status`),
  KEY `cash_sessions_tenant_id_cash_register_id_status_index` (`tenant_id`,`cash_register_id`,`status`),
  CONSTRAINT `cash_sessions_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cash_sessions_cash_register_id_foreign` FOREIGN KEY (`cash_register_id`) REFERENCES `cash_registers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cash_sessions_closed_by_id_foreign` FOREIGN KEY (`closed_by_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `cash_sessions_opened_by_id_foreign` FOREIGN KEY (`opened_by_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `cash_sessions_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cash_sessions`
--

LOCK TABLES `cash_sessions` WRITE;
/*!40000 ALTER TABLE `cash_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `cash_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `branch_id` bigint(20) unsigned DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(150) NOT NULL,
  `slug` varchar(180) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `icon` varchar(60) DEFAULT NULL,
  `color` varchar(20) DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `available_from` time DEFAULT NULL,
  `available_until` time DEFAULT NULL,
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_tenant_id_slug_unique` (`tenant_id`,`slug`),
  KEY `categories_branch_id_foreign` (`branch_id`),
  KEY `categories_parent_id_foreign` (`parent_id`),
  KEY `categories_tenant_id_parent_id_sort_order_index` (`tenant_id`,`parent_id`,`sort_order`),
  KEY `categories_tenant_id_is_active_index` (`tenant_id`,`is_active`),
  CONSTRAINT `categories_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `categories_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `categories_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES
(1,1,NULL,NULL,'Kahvaltılar','kahvaltilar','Güne enerjik başlayın',NULL,NULL,NULL,'07:00:00','13:00:00',10,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(2,1,NULL,NULL,'Başlangıçlar','baslangiclar','Hafif ve lezzetli atıştırmalıklar',NULL,NULL,NULL,NULL,NULL,20,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(3,1,NULL,NULL,'Ana Yemekler','ana-yemekler','Doyurucu ana yemekler',NULL,NULL,NULL,NULL,NULL,30,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(4,1,NULL,NULL,'Burgerler','burgerler','El yapımı özel burgerler',NULL,NULL,NULL,NULL,NULL,40,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(5,1,NULL,NULL,'Pizzalar','pizzalar','İtalyan usulü pizzalar',NULL,NULL,NULL,NULL,NULL,50,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(6,1,NULL,NULL,'Makarnalar','makarnalar','Taze makarna çeşitleri',NULL,NULL,NULL,NULL,NULL,60,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(7,1,NULL,NULL,'Salatalar','salatalar','Taze ve sağlıklı salatalar',NULL,NULL,NULL,NULL,NULL,70,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(8,1,NULL,NULL,'Tostlar & Sandviçler','tostlar-sandvicler','Sıcak tostlar ve sandviçler',NULL,NULL,NULL,NULL,NULL,80,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(9,1,NULL,NULL,'Tatlılar','tatlilar','El yapımı tatlılar',NULL,NULL,NULL,NULL,NULL,90,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(10,1,NULL,NULL,'Sıcak İçecekler','sicak-icecekler','Kahve ve sıcak içecekler',NULL,NULL,NULL,NULL,NULL,100,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(11,1,NULL,NULL,'Soğuk İçecekler','soguk-icecekler','Serinleten içecekler',NULL,NULL,NULL,NULL,NULL,110,1,'2026-07-22 12:26:17','2026-07-22 12:26:17'),
(12,1,NULL,NULL,'Nargile','nargile','Premium nargile deneyimi',NULL,NULL,NULL,NULL,NULL,120,1,'2026-07-22 12:26:17','2026-07-22 12:26:17');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_menu`
--

DROP TABLE IF EXISTS `category_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `category_menu` (
  `menu_id` bigint(20) unsigned NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`menu_id`,`category_id`),
  KEY `category_menu_category_id_foreign` (`category_id`),
  CONSTRAINT `category_menu_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `category_menu_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_menu`
--

LOCK TABLES `category_menu` WRITE;
/*!40000 ALTER TABLE `category_menu` DISABLE KEYS */;
INSERT INTO `category_menu` VALUES
(1,1,10),
(1,10,20),
(1,11,30),
(2,2,10),
(2,3,20),
(2,4,30),
(2,5,40),
(2,6,50),
(2,7,60),
(2,8,70),
(2,10,90),
(2,11,80),
(3,2,10),
(3,3,20),
(3,4,30),
(3,5,40),
(3,6,50),
(3,7,60),
(3,9,70),
(3,10,90),
(3,11,100),
(3,12,80),
(4,9,10),
(4,10,20),
(4,11,30);
/*!40000 ALTER TABLE `category_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(32) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customers_tenant_id_phone_index` (`tenant_id`,`phone`),
  KEY `customers_tenant_id_email_index` (`tenant_id`,`email`),
  CONSTRAINT `customers_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` varchar(255) NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`),
  KEY `failed_jobs_connection_queue_failed_at_index` (`connection`,`queue`,`failed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` smallint(5) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kds_item_pickups`
--

DROP TABLE IF EXISTS `kds_item_pickups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `kds_item_pickups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `order_item_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `kds_item_pickups_order_item_id_unique` (`order_item_id`),
  KEY `kds_item_pickups_tenant_id_foreign` (`tenant_id`),
  KEY `kds_item_pickups_user_id_foreign` (`user_id`),
  CONSTRAINT `kds_item_pickups_order_item_id_foreign` FOREIGN KEY (`order_item_id`) REFERENCES `order_items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `kds_item_pickups_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `kds_item_pickups_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kds_item_pickups`
--

LOCK TABLES `kds_item_pickups` WRITE;
/*!40000 ALTER TABLE `kds_item_pickups` DISABLE KEYS */;
INSERT INTO `kds_item_pickups` VALUES
(1,1,5,2,'2026-07-22 13:58:31');
/*!40000 ALTER TABLE `kds_item_pickups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kds_stations`
--

DROP TABLE IF EXISTS `kds_stations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `kds_stations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `key` varchar(40) NOT NULL,
  `name` varchar(80) NOT NULL,
  `sort_order` smallint(5) unsigned NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `kds_stations_tenant_id_key_unique` (`tenant_id`,`key`),
  CONSTRAINT `kds_stations_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kds_stations`
--

LOCK TABLES `kds_stations` WRITE;
/*!40000 ALTER TABLE `kds_stations` DISABLE KEYS */;
/*!40000 ALTER TABLE `kds_stations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kds_user_stations`
--

DROP TABLE IF EXISTS `kds_user_stations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `kds_user_stations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `station_key` varchar(40) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `kds_user_stations_tenant_id_user_id_station_key_unique` (`tenant_id`,`user_id`,`station_key`),
  KEY `kds_user_stations_user_id_foreign` (`user_id`),
  CONSTRAINT `kds_user_stations_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `kds_user_stations_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kds_user_stations`
--

LOCK TABLES `kds_user_stations` WRITE;
/*!40000 ALTER TABLE `kds_user_stations` DISABLE KEYS */;
/*!40000 ALTER TABLE `kds_user_stations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mail_settings`
--

DROP TABLE IF EXISTS `mail_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mail_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned DEFAULT NULL,
  `mailer` varchar(20) NOT NULL DEFAULT 'smtp',
  `host` varchar(255) DEFAULT NULL,
  `port` int(10) unsigned DEFAULT NULL,
  `encryption` varchar(10) NOT NULL DEFAULT 'tls',
  `username` varchar(255) DEFAULT NULL,
  `password` text DEFAULT NULL,
  `from_name` varchar(120) DEFAULT NULL,
  `from_address` varchar(255) DEFAULT NULL,
  `reply_to` varchar(255) DEFAULT NULL,
  `timeout` smallint(5) unsigned NOT NULL DEFAULT 30,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mail_settings_tenant_id_unique` (`tenant_id`),
  CONSTRAINT `mail_settings_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mail_settings`
--

LOCK TABLES `mail_settings` WRITE;
/*!40000 ALTER TABLE `mail_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `mail_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menus`
--

DROP TABLE IF EXISTS `menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `menus` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `branch_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(150) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `days` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`days`)),
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `channels` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`channels`)),
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `menus_branch_id_foreign` (`branch_id`),
  KEY `menus_tenant_id_sort_order_index` (`tenant_id`,`sort_order`),
  CONSTRAINT `menus_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `menus_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menus`
--

LOCK TABLES `menus` WRITE;
/*!40000 ALTER TABLE `menus` DISABLE KEYS */;
INSERT INTO `menus` VALUES
(1,1,NULL,'Kahvaltı Menüsü','Sabah servisi','[1,2,3,4,5,6,7]','07:00:00','13:00:00',NULL,10,1,'2026-07-22 12:26:17','2026-07-22 12:26:17'),
(2,1,NULL,'Öğle Menüsü','Öğle servisi','[1,2,3,4,5,6,7]','12:00:00','17:00:00',NULL,20,1,'2026-07-22 12:26:17','2026-07-22 12:26:17'),
(3,1,NULL,'Akşam Menüsü','Akşam servisi','[1,2,3,4,5,6,7]','17:00:00','23:30:00',NULL,30,1,'2026-07-22 12:26:17','2026-07-22 12:26:17'),
(4,1,NULL,'Hafta Sonu Tatlı & Kahve','Hafta sonu ikindi servisi','[6,7]','14:00:00','19:00:00',NULL,40,1,'2026-07-22 12:26:17','2026-07-22 12:26:17');
/*!40000 ALTER TABLE `menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'0001_01_01_000000_create_users_table',1),
(2,'0001_01_01_000001_create_cache_table',1),
(3,'0001_01_01_000002_create_jobs_table',1),
(4,'2026_07_22_100000_create_tenants_and_branches_tables',2),
(5,'2026_07_22_100001_extend_users_for_identity',2),
(6,'2026_07_22_100002_create_roles_and_permissions_tables',2),
(7,'2026_07_22_100003_create_audit_logs_table',2),
(8,'2026_07_22_100004_create_core_domain_tables',2),
(9,'2026_07_22_120000_create_catalog_tables',3),
(10,'2026_07_22_150000_create_mail_settings_table',3),
(11,'2026_07_22_210000_create_venue_structure_tables',3),
(12,'2026_07_22_210001_extend_tables_and_branches_for_venue',3),
(13,'2026_07_22_230000_create_orders_module_tables',4),
(14,'2026_07_22_235000_create_service_requests_table',5),
(15,'2026_07_22_250000_create_kds_tables',6),
(16,'2026_07_22_250000_create_payments_module_tables',6);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `option_group_product`
--

DROP TABLE IF EXISTS `option_group_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `option_group_product` (
  `product_id` bigint(20) unsigned NOT NULL,
  `option_group_id` bigint(20) unsigned NOT NULL,
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`product_id`,`option_group_id`),
  KEY `option_group_product_option_group_id_foreign` (`option_group_id`),
  CONSTRAINT `option_group_product_option_group_id_foreign` FOREIGN KEY (`option_group_id`) REFERENCES `option_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `option_group_product_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `option_group_product`
--

LOCK TABLES `option_group_product` WRITE;
/*!40000 ALTER TABLE `option_group_product` DISABLE KEYS */;
INSERT INTO `option_group_product` VALUES
(1,1,10),
(1,2,20),
(2,1,10),
(2,2,20),
(3,1,10),
(3,2,20),
(4,1,10),
(4,2,20),
(5,1,10),
(5,2,20),
(6,1,10),
(6,2,20),
(7,1,10),
(7,2,20),
(8,1,10),
(8,2,20),
(9,1,10),
(9,2,20),
(10,1,10),
(10,2,20),
(11,1,10),
(11,2,20),
(12,1,10),
(12,2,20),
(13,1,10),
(13,2,20),
(14,1,10),
(14,2,20),
(15,1,10),
(15,2,20),
(16,1,10),
(16,2,20),
(17,1,10),
(17,2,20),
(18,1,10),
(18,2,20),
(19,1,10),
(19,2,20),
(20,1,10),
(20,2,20),
(21,1,10),
(21,2,20),
(22,1,10),
(22,2,20),
(23,1,10),
(23,2,20),
(24,1,10),
(24,2,20),
(25,1,10),
(25,2,20),
(26,1,10),
(26,2,20),
(27,2,10),
(28,2,10),
(29,2,10),
(30,2,10),
(31,2,10),
(32,2,10),
(33,2,10),
(34,2,10),
(35,1,10),
(35,2,20),
(36,1,10),
(36,2,20),
(37,1,10),
(37,2,20),
(38,1,10),
(38,2,20),
(39,1,10),
(39,2,20),
(40,7,10),
(41,7,10),
(42,7,10),
(43,7,10),
(44,7,10),
(45,7,10),
(46,3,10),
(46,4,20),
(47,3,10),
(47,4,20),
(48,3,10),
(48,4,20),
(49,3,10),
(49,4,20),
(50,3,10),
(50,4,20),
(51,3,10),
(51,4,20),
(52,3,10),
(52,4,20),
(53,3,10),
(53,4,20),
(54,3,10),
(54,4,20),
(55,3,10),
(55,4,20),
(56,3,10),
(56,4,20),
(57,3,10),
(57,4,20),
(58,3,10),
(58,4,20),
(59,3,10),
(59,4,20),
(60,3,10),
(60,4,20),
(61,3,10),
(61,4,20),
(62,3,10),
(62,4,20),
(63,3,10),
(63,4,20),
(64,5,10),
(64,6,20),
(65,5,10),
(65,6,20),
(66,5,10),
(66,6,20),
(67,5,10),
(67,6,20),
(68,5,10),
(68,6,20),
(69,7,10);
/*!40000 ALTER TABLE `option_group_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `option_groups`
--

DROP TABLE IF EXISTS `option_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `option_groups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `name` varchar(150) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `selection_type` varchar(10) NOT NULL DEFAULT 'multiple',
  `is_required` tinyint(1) NOT NULL DEFAULT 0,
  `min_select` smallint(5) unsigned NOT NULL DEFAULT 0,
  `max_select` smallint(5) unsigned DEFAULT NULL,
  `free_limit` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `option_groups_tenant_id_sort_order_index` (`tenant_id`,`sort_order`),
  CONSTRAINT `option_groups_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `option_groups`
--

LOCK TABLES `option_groups` WRITE;
/*!40000 ALTER TABLE `option_groups` DISABLE KEYS */;
INSERT INTO `option_groups` VALUES
(1,1,'Soslar','Yanında istediğiniz soslar (2 adede kadar ücretsiz olanlar mevcut).','multiple',0,0,NULL,2,10,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(2,1,'Ekstra Malzemeler','Ürününüze ekleyebileceğiniz ilave malzemeler.','multiple',0,0,NULL,0,20,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(3,1,'Süt Tercihi','Kahveniz için alternatif süt seçimi.','single',0,0,1,0,30,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(4,1,'Kahve Ekstraları','Kahvenizi zenginleştirin.','multiple',0,0,NULL,0,40,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(5,1,'Köz Seçimi','Nargileniz için köz tercihi (zorunlu).','single',1,1,1,1,50,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(6,1,'Nargile Ekstraları','Nargile deneyiminizi kişiselleştirin.','multiple',0,0,NULL,0,60,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(7,1,'Tatlı Ekstraları','Tatlınızın yanına ilaveler.','multiple',0,0,NULL,0,70,1,'2026-07-22 12:26:16','2026-07-22 12:26:16');
/*!40000 ALTER TABLE `option_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `options`
--

DROP TABLE IF EXISTS `options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `options` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `option_group_id` bigint(20) unsigned NOT NULL,
  `name` varchar(150) NOT NULL,
  `price_minor` bigint(20) unsigned NOT NULL DEFAULT 0,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `options_option_group_id_foreign` (`option_group_id`),
  KEY `options_tenant_id_option_group_id_sort_order_index` (`tenant_id`,`option_group_id`,`sort_order`),
  CONSTRAINT `options_option_group_id_foreign` FOREIGN KEY (`option_group_id`) REFERENCES `option_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `options_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `options`
--

LOCK TABLES `options` WRITE;
/*!40000 ALTER TABLE `options` DISABLE KEYS */;
INSERT INTO `options` VALUES
(1,1,1,'Ketçap',0,0,10,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(2,1,1,'Mayonez',0,0,20,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(3,1,1,'Hardal',0,0,30,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(4,1,1,'Ranch Sos',500,0,40,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(5,1,1,'BBQ Sos',500,0,50,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(6,1,1,'Acı Sos',300,0,60,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(7,1,2,'Ekstra Peynir',1500,0,10,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(8,1,2,'Ekstra Et (Köfte)',3000,0,20,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(9,1,2,'Mantar',1000,0,30,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(10,1,2,'Jalapeno',800,0,40,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(11,1,2,'Avokado',2000,0,50,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(12,1,2,'Patates (Yanında)',2500,0,60,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(13,1,3,'Badem Sütü',1200,0,10,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(14,1,3,'Yulaf Sütü',1200,0,20,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(15,1,3,'Hindistan Cevizi Sütü',1500,0,30,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(16,1,4,'Shot Espresso',1500,0,10,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(17,1,4,'Karamel Şurubu',1000,0,20,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(18,1,4,'Vanilya Şurubu',1000,0,30,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(19,1,4,'Çikolata Sosu',1000,0,40,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(20,1,4,'Ekstra Krema',800,0,50,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(21,1,5,'Hindistan Cevizi Közü',0,0,10,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(22,1,5,'Bambu Közü',0,0,20,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(23,1,6,'Buz Aparatı',1500,0,10,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(24,1,6,'Çift Aroma',2000,0,20,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(25,1,6,'Meyve Başlığı',3000,0,30,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(26,1,6,'Süt Dolgusu',1500,0,40,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(27,1,7,'Çikolata Sosu',1000,0,10,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(28,1,7,'Ekstra Dondurma',1200,0,20,1,'2026-07-22 12:26:16','2026-07-22 12:26:16'),
(29,1,7,'Fındık Parçası',800,0,30,1,'2026-07-22 12:26:16','2026-07-22 12:26:16');
/*!40000 ALTER TABLE `options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_events`
--

DROP TABLE IF EXISTS `order_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `branch_id` bigint(20) unsigned DEFAULT NULL,
  `order_id` bigint(20) unsigned NOT NULL,
  `order_item_id` bigint(20) unsigned DEFAULT NULL,
  `type` varchar(40) NOT NULL,
  `from_status` varchar(20) DEFAULT NULL,
  `to_status` varchar(20) DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`payload`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `order_events_branch_id_foreign` (`branch_id`),
  KEY `order_events_order_id_foreign` (`order_id`),
  KEY `order_events_order_item_id_foreign` (`order_item_id`),
  KEY `order_events_user_id_foreign` (`user_id`),
  KEY `order_events_tenant_id_order_id_id_index` (`tenant_id`,`order_id`,`id`),
  KEY `order_events_kds_cursor_idx` (`tenant_id`,`branch_id`,`id`),
  CONSTRAINT `order_events_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `order_events_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_events_order_item_id_foreign` FOREIGN KEY (`order_item_id`) REFERENCES `order_items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_events_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_events_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_events`
--

LOCK TABLES `order_events` WRITE;
/*!40000 ALTER TABLE `order_events` DISABLE KEYS */;
INSERT INTO `order_events` VALUES
(1,1,1,1,NULL,'opened',NULL,'placed',2,'{\"channel\":\"table\"}','2026-07-22 13:11:59'),
(2,1,1,2,NULL,'opened',NULL,'placed',2,'{\"channel\":\"table\"}','2026-07-22 13:12:26'),
(3,1,1,2,1,'item_added',NULL,NULL,2,'{\"name\":\"Classic Cheeseburger\",\"qty\":1,\"unit_price_minor\":32000,\"options_price_minor\":0,\"line_total_minor\":32000}','2026-07-22 13:12:26'),
(4,1,1,2,NULL,'cancelled','placed','cancelled',2,'{\"reason\":\"eszamanlilik kaniti - temizlik\",\"previous_total_minor\":32000,\"performed_by\":2}','2026-07-22 13:12:26'),
(5,1,1,3,NULL,'opened',NULL,'pending_approval',NULL,'{\"channel\":\"qr\",\"source\":\"public\"}','2026-07-22 13:14:48'),
(6,1,1,4,NULL,'opened',NULL,'pending_approval',NULL,'{\"channel\":\"qr\",\"source\":\"public\"}','2026-07-22 13:20:21'),
(7,1,1,4,NULL,'cancelled','pending_approval','cancelled',2,'{\"reason\":\"canl\\u0131 kan\\u0131t temizli\\u011fi\",\"previous_total_minor\":32000,\"performed_by\":2}','2026-07-22 13:20:44'),
(8,1,1,1,NULL,'cancelled','placed','cancelled',2,'{\"reason\":\"bo\\u015f test adisyonu temizli\\u011fi\",\"previous_total_minor\":0,\"performed_by\":2}','2026-07-22 13:21:03'),
(9,1,1,3,NULL,'status_changed','pending_approval','placed',2,NULL,'2026-07-22 13:28:00'),
(11,1,1,3,NULL,'status_changed','placed','bill_requested',2,NULL,'2026-07-22 13:28:28'),
(12,1,1,3,NULL,'item_removed',NULL,NULL,2,'{\"name\":\"Sigara B\\u00f6re\\u011fi (4 Adet)\",\"qty\":1,\"line_total_minor\":16500}','2026-07-22 13:29:10'),
(13,1,1,3,NULL,'item_removed',NULL,NULL,2,'{\"name\":\"Serpme Kahvalt\\u0131 (2 Ki\\u015filik)\",\"qty\":1,\"line_total_minor\":85000}','2026-07-22 13:29:12'),
(14,1,1,3,NULL,'cancelled','bill_requested','cancelled',2,'{\"reason\":\"test\",\"previous_total_minor\":0,\"performed_by\":2}','2026-07-22 13:29:26'),
(15,1,1,5,NULL,'opened',NULL,'placed',2,'{\"channel\":\"table\"}','2026-07-22 13:32:08'),
(16,1,1,6,NULL,'opened',NULL,'placed',2,'{\"channel\":\"table\"}','2026-07-22 13:58:16'),
(17,1,1,6,5,'item_added',NULL,NULL,2,'{\"name\":\"Classic Cheeseburger\",\"qty\":1,\"unit_price_minor\":32000,\"options_price_minor\":0,\"line_total_minor\":32000}','2026-07-22 13:58:16'),
(18,1,1,6,6,'item_added',NULL,NULL,2,'{\"name\":\"Ev Yap\\u0131m\\u0131 Limonata\",\"qty\":2,\"unit_price_minor\":10000,\"options_price_minor\":0,\"line_total_minor\":20000}','2026-07-22 13:58:16'),
(19,1,1,6,7,'item_added',NULL,NULL,2,'{\"name\":\"San Sebastian Cheesecake\",\"qty\":1,\"unit_price_minor\":22000,\"options_price_minor\":0,\"line_total_minor\":22000}','2026-07-22 13:58:16'),
(20,1,1,6,5,'item_status_changed','placed','accepted',2,'{\"name\":\"Classic Cheeseburger\"}','2026-07-22 13:58:23'),
(21,1,1,6,5,'item_status_changed','accepted','preparing',2,'{\"name\":\"Classic Cheeseburger\"}','2026-07-22 13:58:24'),
(22,1,1,6,NULL,'status_derived','placed','preparing',2,NULL,'2026-07-22 13:58:24'),
(23,1,1,6,5,'item_status_changed','preparing','ready',2,'{\"name\":\"Classic Cheeseburger\"}','2026-07-22 13:58:25'),
(24,1,1,6,NULL,'status_derived','preparing','partially_ready',2,NULL,'2026-07-22 13:58:25'),
(25,1,1,6,6,'item_status_changed','placed','ready',2,'{\"name\":\"Ev Yap\\u0131m\\u0131 Limonata\"}','2026-07-22 13:58:27'),
(26,1,1,6,7,'item_status_changed','placed','ready',2,'{\"name\":\"San Sebastian Cheesecake\"}','2026-07-22 13:58:27'),
(27,1,1,6,NULL,'status_derived','partially_ready','ready',2,NULL,'2026-07-22 13:58:27'),
(28,1,1,6,5,'kds_picked_up',NULL,NULL,2,'{\"name\":\"Classic Cheeseburger\"}','2026-07-22 13:58:31'),
(29,1,1,6,5,'item_status_changed','ready','served',2,'{\"name\":\"Classic Cheeseburger\"}','2026-07-22 13:58:33'),
(30,1,1,7,NULL,'opened',NULL,'placed',2,'{\"channel\":\"table\"}','2026-07-22 14:01:22'),
(31,1,1,7,8,'item_added',NULL,NULL,2,'{\"name\":\"Classic Cheeseburger\",\"qty\":1,\"unit_price_minor\":32000,\"options_price_minor\":0,\"line_total_minor\":32000}','2026-07-22 14:01:22'),
(32,1,1,7,9,'item_added',NULL,NULL,2,'{\"name\":\"Margherita\",\"qty\":1,\"unit_price_minor\":25000,\"options_price_minor\":0,\"line_total_minor\":25000}','2026-07-22 14:01:23'),
(33,1,1,7,10,'item_added',NULL,NULL,2,'{\"name\":\"T\\u00fcrk Kahvesi\",\"qty\":1,\"unit_price_minor\":8000,\"options_price_minor\":0,\"line_total_minor\":8000}','2026-07-22 14:01:23');
/*!40000 ALTER TABLE `order_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_idempotency_keys`
--

DROP TABLE IF EXISTS `order_idempotency_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_idempotency_keys` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `key` varchar(80) NOT NULL,
  `endpoint` varchar(60) NOT NULL,
  `order_id` bigint(20) unsigned DEFAULT NULL,
  `response` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`response`)),
  `status_code` smallint(5) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_idempotency_keys_tenant_id_key_unique` (`tenant_id`,`key`),
  KEY `order_idempotency_keys_order_id_foreign` (`order_id`),
  CONSTRAINT `order_idempotency_keys_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_idempotency_keys_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_idempotency_keys`
--

LOCK TABLES `order_idempotency_keys` WRITE;
/*!40000 ALTER TABLE `order_idempotency_keys` DISABLE KEYS */;
INSERT INTO `order_idempotency_keys` VALUES
(1,1,'proof-1784736746','orders.items.add',2,'{\"order\":{\"id\":2,\"branch_id\":1,\"table_id\":2,\"table_name\":\"Teras 2\",\"channel\":\"table\",\"channel_label\":\"Masa\",\"channel_icon\":\"utensils\",\"channel_variant\":\"info\",\"status\":\"placed\",\"status_label\":\"Sipari\\u015f al\\u0131nd\\u0131\",\"status_icon\":\"orders\",\"status_variant\":\"info\",\"is_open\":true,\"version\":1,\"guest_count\":null,\"note\":null,\"customer_name\":null,\"customer_phone\":null,\"items_count\":1,\"items_total_minor\":32000,\"discount_minor\":0,\"discount_percent\":null,\"discount_reason\":null,\"comp_total_minor\":0,\"vat_total_minor\":2909,\"total_minor\":32000,\"paid_minor\":0,\"remaining_minor\":32000,\"total_display\":\"320,00\",\"remaining_display\":\"320,00\",\"opened_by\":\"Demo Kullan\\u0131c\\u0131\",\"placed_at\":\"2026-07-22T16:12:26+00:00\",\"created_at\":\"2026-07-22T16:12:26+00:00\",\"closed_at\":null,\"items\":[{\"id\":1,\"product_id\":17,\"variant_id\":null,\"status\":\"placed\",\"status_label\":\"Al\\u0131nd\\u0131\",\"status_icon\":\"orders\",\"status_variant\":\"info\",\"is_active\":true,\"qty\":1,\"name\":\"Classic Cheeseburger\",\"variant_name\":null,\"unit_price_minor\":32000,\"options_price_minor\":0,\"tax_rate\":10,\"station\":null,\"discount_minor\":0,\"is_comp\":false,\"comp_reason\":null,\"line_total_minor\":32000,\"line_total_display\":\"320,00\",\"note\":null,\"cancel_reason\":null,\"options\":[]}],\"events\":[{\"id\":3,\"type\":\"item_added\",\"from_status\":null,\"to_status\":null,\"user\":\"Demo Kullan\\u0131c\\u0131\",\"payload\":{\"name\":\"Classic Cheeseburger\",\"qty\":1,\"unit_price_minor\":32000,\"options_price_minor\":0,\"line_total_minor\":32000},\"created_at\":\"2026-07-22T16:12:26+00:00\"},{\"id\":2,\"type\":\"opened\",\"from_status\":null,\"to_status\":\"placed\",\"user\":\"Demo Kullan\\u0131c\\u0131\",\"payload\":{\"channel\":\"table\"},\"created_at\":\"2026-07-22T16:12:26+00:00\"}]}}',201,'2026-07-22 13:12:26','2026-07-22 13:12:26'),
(3,1,'c41b934f-294d-47ef-8f08-45c10d34890e','public.orders.store',NULL,'{\"order\":{\"public_token\":\"WEMDDCVPD7RMZOFIMTOMCFWA4A\",\"status\":\"pending_approval\",\"status_label\":\"Onay bekliyor\",\"total_minor\":16500,\"total_display\":\"165,00\",\"items\":[{\"name\":\"Sigara B\\u00f6re\\u011fi (4 Adet)\",\"qty\":1,\"status\":\"placed\",\"status_label\":\"Al\\u0131nd\\u0131\",\"line_total_minor\":16500,\"options\":[\"Ekstra Et (K\\u00f6fte)\",\"Ekstra Peynir\"]}],\"created_at\":\"2026-07-22T16:14:48+00:00\"}}',201,'2026-07-22 13:14:48','2026-07-22 13:14:48'),
(4,1,'pub-proof-1784737220','public.orders.store',NULL,'{\"order\":{\"public_token\":\"EQAY7ERTCDJ3SDLFMLCHMTNHXM\",\"status\":\"pending_approval\",\"status_label\":\"Onay bekliyor\",\"total_minor\":32000,\"total_display\":\"320,00\",\"items\":[{\"name\":\"Classic Cheeseburger\",\"qty\":1,\"status\":\"placed\",\"status_label\":\"Al\\u0131nd\\u0131\",\"line_total_minor\":32000,\"options\":[]}],\"created_at\":\"2026-07-22T16:20:21+00:00\"}}',201,'2026-07-22 13:20:21','2026-07-22 13:20:21'),
(6,1,'71f0c11d-a0f3-4c39-ae6a-401ea3c4e3b4','orders.items.add',3,'{\"order\":{\"id\":3,\"branch_id\":1,\"table_id\":1,\"table_name\":\"Teras 1\",\"channel\":\"qr\",\"channel_label\":\"QR\",\"channel_icon\":\"qr-code\",\"channel_variant\":\"success\",\"status\":\"placed\",\"status_label\":\"Sipari\\u015f al\\u0131nd\\u0131\",\"status_icon\":\"orders\",\"status_variant\":\"info\",\"is_open\":true,\"version\":2,\"guest_count\":null,\"note\":null,\"customer_name\":null,\"customer_phone\":null,\"items_count\":2,\"items_total_minor\":101500,\"discount_minor\":0,\"discount_percent\":null,\"discount_reason\":null,\"comp_total_minor\":0,\"vat_total_minor\":9227,\"total_minor\":101500,\"paid_minor\":0,\"remaining_minor\":101500,\"total_display\":\"1.015,00\",\"remaining_display\":\"1.015,00\",\"opened_by\":null,\"placed_at\":\"2026-07-22T16:28:00+00:00\",\"created_at\":\"2026-07-22T16:14:48+00:00\",\"closed_at\":null,\"items\":[{\"id\":2,\"product_id\":6,\"variant_id\":null,\"status\":\"placed\",\"status_label\":\"Al\\u0131nd\\u0131\",\"status_icon\":\"orders\",\"status_variant\":\"info\",\"is_active\":true,\"qty\":1,\"name\":\"Sigara B\\u00f6re\\u011fi (4 Adet)\",\"variant_name\":null,\"unit_price_minor\":12000,\"options_price_minor\":4500,\"tax_rate\":10,\"station\":null,\"discount_minor\":0,\"is_comp\":false,\"comp_reason\":null,\"line_total_minor\":16500,\"line_total_display\":\"165,00\",\"note\":null,\"cancel_reason\":null,\"options\":[{\"id\":1,\"group_name\":\"Ekstra Malzemeler\",\"option_name\":\"Ekstra Et (K\\u00f6fte)\",\"price_minor\":3000},{\"id\":2,\"group_name\":\"Ekstra Malzemeler\",\"option_name\":\"Ekstra Peynir\",\"price_minor\":1500}]},{\"id\":4,\"product_id\":1,\"variant_id\":null,\"status\":\"placed\",\"status_label\":\"Al\\u0131nd\\u0131\",\"status_icon\":\"orders\",\"status_variant\":\"info\",\"is_active\":true,\"qty\":1,\"name\":\"Serpme Kahvalt\\u0131 (2 Ki\\u015filik)\",\"variant_name\":null,\"unit_price_minor\":85000,\"options_price_minor\":0,\"tax_rate\":10,\"station\":null,\"discount_minor\":0,\"is_comp\":false,\"comp_reason\":null,\"line_total_minor\":85000,\"line_total_display\":\"850,00\",\"note\":null,\"cancel_reason\":null,\"options\":[{\"id\":3,\"group_name\":\"Soslar\",\"option_name\":\"Ket\\u00e7ap\",\"price_minor\":0}]}],\"events\":[{\"id\":10,\"type\":\"item_added\",\"from_status\":null,\"to_status\":null,\"user\":\"Demo Kullan\\u0131c\\u0131\",\"payload\":{\"name\":\"Serpme Kahvalt\\u0131 (2 Ki\\u015filik)\",\"qty\":1,\"unit_price_minor\":85000,\"options_price_minor\":0,\"line_total_minor\":85000},\"created_at\":\"2026-07-22T16:28:24+00:00\"},{\"id\":9,\"type\":\"status_changed\",\"from_status\":\"pending_approval\",\"to_status\":\"placed\",\"user\":\"Demo Kullan\\u0131c\\u0131\",\"payload\":null,\"created_at\":\"2026-07-22T16:28:00+00:00\"},{\"id\":5,\"type\":\"opened\",\"from_status\":null,\"to_status\":\"pending_approval\",\"user\":null,\"payload\":{\"channel\":\"qr\",\"source\":\"public\"},\"created_at\":\"2026-07-22T16:14:48+00:00\"}]}}',201,'2026-07-22 13:28:24','2026-07-22 13:28:24');
/*!40000 ALTER TABLE `order_idempotency_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_item_options`
--

DROP TABLE IF EXISTS `order_item_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_item_options` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `order_item_id` bigint(20) unsigned NOT NULL,
  `option_id` bigint(20) unsigned DEFAULT NULL,
  `group_name` varchar(150) NOT NULL,
  `option_name` varchar(150) NOT NULL,
  `price_minor` bigint(20) unsigned NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_item_options_order_item_id_foreign` (`order_item_id`),
  KEY `order_item_options_option_id_foreign` (`option_id`),
  KEY `order_item_options_tenant_id_order_item_id_index` (`tenant_id`,`order_item_id`),
  CONSTRAINT `order_item_options_option_id_foreign` FOREIGN KEY (`option_id`) REFERENCES `options` (`id`) ON DELETE SET NULL,
  CONSTRAINT `order_item_options_order_item_id_foreign` FOREIGN KEY (`order_item_id`) REFERENCES `order_items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_item_options_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_item_options`
--

LOCK TABLES `order_item_options` WRITE;
/*!40000 ALTER TABLE `order_item_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_item_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned DEFAULT NULL,
  `variant_id` bigint(20) unsigned DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'placed',
  `qty` smallint(5) unsigned NOT NULL,
  `name` varchar(200) NOT NULL,
  `variant_name` varchar(100) DEFAULT NULL,
  `unit_price_minor` bigint(20) unsigned NOT NULL,
  `options_price_minor` bigint(20) unsigned NOT NULL DEFAULT 0,
  `tax_rate` decimal(5,2) NOT NULL DEFAULT 0.00,
  `station` varchar(40) DEFAULT NULL,
  `discount_minor` bigint(20) unsigned NOT NULL DEFAULT 0,
  `discount_reason` varchar(255) DEFAULT NULL,
  `is_comp` tinyint(1) NOT NULL DEFAULT 0,
  `comp_reason` varchar(255) DEFAULT NULL,
  `comp_by_id` bigint(20) unsigned DEFAULT NULL,
  `line_total_minor` bigint(20) unsigned NOT NULL DEFAULT 0,
  `vat_minor` bigint(20) unsigned NOT NULL DEFAULT 0,
  `note` varchar(255) DEFAULT NULL,
  `added_by_id` bigint(20) unsigned DEFAULT NULL,
  `cancelled_at` timestamp NULL DEFAULT NULL,
  `cancel_reason` varchar(255) DEFAULT NULL,
  `cancelled_by_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_items_order_id_foreign` (`order_id`),
  KEY `order_items_product_id_foreign` (`product_id`),
  KEY `order_items_variant_id_foreign` (`variant_id`),
  KEY `order_items_comp_by_id_foreign` (`comp_by_id`),
  KEY `order_items_added_by_id_foreign` (`added_by_id`),
  KEY `order_items_cancelled_by_id_foreign` (`cancelled_by_id`),
  KEY `order_items_tenant_id_order_id_index` (`tenant_id`,`order_id`),
  KEY `order_items_tenant_id_status_index` (`tenant_id`,`status`),
  CONSTRAINT `order_items_added_by_id_foreign` FOREIGN KEY (`added_by_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `order_items_cancelled_by_id_foreign` FOREIGN KEY (`cancelled_by_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `order_items_comp_by_id_foreign` FOREIGN KEY (`comp_by_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `order_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL,
  CONSTRAINT `order_items_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_items_variant_id_foreign` FOREIGN KEY (`variant_id`) REFERENCES `product_variants` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
INSERT INTO `order_items` VALUES
(1,1,2,17,NULL,'placed',1,'Classic Cheeseburger',NULL,32000,0,10.00,NULL,0,NULL,0,NULL,NULL,32000,2909,NULL,2,NULL,NULL,NULL,'2026-07-22 13:12:26','2026-07-22 13:12:26'),
(3,1,4,17,NULL,'placed',1,'Classic Cheeseburger',NULL,32000,0,10.00,NULL,0,NULL,0,NULL,NULL,32000,2909,NULL,NULL,NULL,NULL,NULL,'2026-07-22 13:20:21','2026-07-22 13:20:21'),
(5,1,6,17,NULL,'served',1,'Classic Cheeseburger',NULL,32000,0,10.00,'grill',0,NULL,0,NULL,NULL,32000,2909,'İyi pişmiş',2,NULL,NULL,NULL,'2026-07-22 13:58:16','2026-07-22 13:58:33'),
(6,1,6,56,NULL,'ready',2,'Ev Yapımı Limonata',NULL,10000,0,10.00,'bar',0,NULL,0,NULL,NULL,20000,1818,NULL,2,NULL,NULL,NULL,'2026-07-22 13:58:16','2026-07-22 13:58:27'),
(7,1,6,40,NULL,'ready',1,'San Sebastian Cheesecake',NULL,22000,0,10.00,'dessert',0,NULL,0,NULL,NULL,22000,2000,NULL,2,NULL,NULL,NULL,'2026-07-22 13:58:16','2026-07-22 13:58:27'),
(8,1,7,17,NULL,'placed',1,'Classic Cheeseburger',NULL,32000,0,10.00,'grill',0,NULL,0,NULL,NULL,32000,2909,NULL,2,NULL,NULL,NULL,'2026-07-22 14:01:22','2026-07-22 14:01:22'),
(9,1,7,23,NULL,'placed',1,'Margherita',NULL,25000,0,10.00,'oven',0,NULL,0,NULL,NULL,25000,2273,NULL,2,NULL,NULL,NULL,'2026-07-22 14:01:23','2026-07-22 14:01:23'),
(10,1,7,46,NULL,'placed',1,'Türk Kahvesi',NULL,8000,0,10.00,'coffee',0,NULL,0,NULL,NULL,8000,727,NULL,2,NULL,NULL,NULL,'2026-07-22 14:01:23','2026-07-22 14:01:23');
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `branch_id` bigint(20) unsigned NOT NULL,
  `table_id` bigint(20) unsigned DEFAULT NULL,
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `channel` varchar(10) NOT NULL DEFAULT 'table',
  `public_token` char(26) DEFAULT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'open',
  `version` int(10) unsigned NOT NULL DEFAULT 0,
  `total_minor` bigint(20) unsigned NOT NULL DEFAULT 0,
  `items_total_minor` bigint(20) unsigned NOT NULL DEFAULT 0,
  `discount_minor` bigint(20) unsigned NOT NULL DEFAULT 0,
  `discount_percent` decimal(5,2) DEFAULT NULL,
  `discount_reason` varchar(255) DEFAULT NULL,
  `discount_by_id` bigint(20) unsigned DEFAULT NULL,
  `discount_approved_by_id` bigint(20) unsigned DEFAULT NULL,
  `comp_total_minor` bigint(20) unsigned NOT NULL DEFAULT 0,
  `vat_total_minor` bigint(20) unsigned NOT NULL DEFAULT 0,
  `service_charge_minor` bigint(20) unsigned NOT NULL DEFAULT 0,
  `service_charge_percent` decimal(5,2) DEFAULT NULL,
  `service_charge_reason` varchar(255) DEFAULT NULL,
  `rounding_minor` bigint(20) NOT NULL DEFAULT 0,
  `paid_minor` bigint(20) unsigned NOT NULL DEFAULT 0,
  `refunded_minor` bigint(20) unsigned NOT NULL DEFAULT 0,
  `guest_count` smallint(5) unsigned DEFAULT NULL,
  `note` varchar(500) DEFAULT NULL,
  `customer_name` varchar(120) DEFAULT NULL,
  `customer_phone` varchar(32) DEFAULT NULL,
  `opened_by_id` bigint(20) unsigned DEFAULT NULL,
  `placed_at` timestamp NULL DEFAULT NULL,
  `closed_at` timestamp NULL DEFAULT NULL,
  `cancelled_at` timestamp NULL DEFAULT NULL,
  `cancel_reason` varchar(255) DEFAULT NULL,
  `cancelled_by_id` bigint(20) unsigned DEFAULT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `orders_public_token_unique` (`public_token`),
  KEY `orders_branch_id_foreign` (`branch_id`),
  KEY `orders_table_id_foreign` (`table_id`),
  KEY `orders_customer_id_foreign` (`customer_id`),
  KEY `orders_tenant_id_branch_id_status_index` (`tenant_id`,`branch_id`,`status`),
  KEY `orders_tenant_id_created_at_index` (`tenant_id`,`created_at`),
  KEY `orders_discount_by_id_foreign` (`discount_by_id`),
  KEY `orders_discount_approved_by_id_foreign` (`discount_approved_by_id`),
  KEY `orders_opened_by_id_foreign` (`opened_by_id`),
  KEY `orders_cancelled_by_id_foreign` (`cancelled_by_id`),
  KEY `orders_tenant_id_table_id_status_index` (`tenant_id`,`table_id`,`status`),
  KEY `orders_tenant_id_channel_status_index` (`tenant_id`,`channel`,`status`),
  CONSTRAINT `orders_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `orders_cancelled_by_id_foreign` FOREIGN KEY (`cancelled_by_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_discount_approved_by_id_foreign` FOREIGN KEY (`discount_approved_by_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_discount_by_id_foreign` FOREIGN KEY (`discount_by_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_opened_by_id_foreign` FOREIGN KEY (`opened_by_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_table_id_foreign` FOREIGN KEY (`table_id`) REFERENCES `tables` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES
(1,1,1,1,NULL,'table',NULL,'cancelled',1,0,0,0,NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,0,0,0,NULL,NULL,NULL,NULL,2,'2026-07-22 13:11:59','2026-07-22 13:21:03','2026-07-22 13:21:03','boş test adisyonu temizliği',2,'TRY','2026-07-22 13:11:59','2026-07-22 13:21:03'),
(2,1,1,2,NULL,'table',NULL,'cancelled',2,32000,32000,0,NULL,NULL,NULL,NULL,0,2909,0,NULL,NULL,0,0,0,NULL,NULL,NULL,NULL,2,'2026-07-22 13:12:26','2026-07-22 13:12:26','2026-07-22 13:12:26','eszamanlilik kaniti - temizlik',2,'TRY','2026-07-22 13:12:26','2026-07-22 13:12:26'),
(3,1,1,1,NULL,'qr','WEMDDCVPD7RMZOFIMTOMCFWA4A','cancelled',6,0,0,0,NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,0,0,0,NULL,NULL,NULL,NULL,NULL,'2026-07-22 13:28:00','2026-07-22 13:29:26','2026-07-22 13:29:26','test',2,'TRY','2026-07-22 13:14:48','2026-07-22 13:29:26'),
(4,1,1,1,NULL,'qr','EQAY7ERTCDJ3SDLFMLCHMTNHXM','cancelled',1,32000,32000,0,NULL,NULL,NULL,NULL,0,2909,0,NULL,NULL,0,0,0,NULL,NULL,'Canlı Kanıt',NULL,NULL,NULL,'2026-07-22 13:20:44','2026-07-22 13:20:44','canlı kanıt temizliği',2,'TRY','2026-07-22 13:20:21','2026-07-22 13:20:44'),
(5,1,1,1,NULL,'table',NULL,'placed',0,0,0,0,NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,0,0,0,4,NULL,NULL,NULL,2,'2026-07-22 13:32:08',NULL,NULL,NULL,NULL,'TRY','2026-07-22 13:32:08','2026-07-22 13:32:08'),
(6,1,1,2,NULL,'table',NULL,'ready',9,74000,74000,0,NULL,NULL,NULL,NULL,0,6727,0,NULL,NULL,0,0,0,2,'KDS kanıt siparişi — az acılı olsun',NULL,NULL,2,'2026-07-22 13:58:16',NULL,NULL,NULL,NULL,'TRY','2026-07-22 13:58:16','2026-07-22 13:58:33'),
(7,1,1,3,NULL,'table',NULL,'placed',3,65000,65000,0,NULL,NULL,NULL,NULL,0,5909,0,NULL,NULL,0,0,0,4,'Doğum günü masası — pastaya mum eklenecek',NULL,NULL,2,'2026-07-22 14:01:22',NULL,NULL,NULL,NULL,'TRY','2026-07-22 14:01:22','2026-07-22 14:01:23');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `branch_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL,
  `reference` char(26) NOT NULL,
  `kind` varchar(10) NOT NULL DEFAULT 'payment',
  `refund_of_id` bigint(20) unsigned DEFAULT NULL,
  `method` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `amount_minor` bigint(20) unsigned NOT NULL,
  `tip_minor` bigint(20) unsigned NOT NULL DEFAULT 0,
  `tendered_minor` bigint(20) unsigned DEFAULT NULL,
  `change_minor` bigint(20) unsigned NOT NULL DEFAULT 0,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `provider` varchar(30) DEFAULT NULL,
  `provider_txn_id` varchar(100) DEFAULT NULL,
  `terminal_id` varchar(60) DEFAULT NULL,
  `cash_session_id` bigint(20) unsigned DEFAULT NULL,
  `cashier_id` bigint(20) unsigned DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `suspect` tinyint(1) NOT NULL DEFAULT 0,
  `suspect_reason` varchar(255) DEFAULT NULL,
  `meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`meta`)),
  `paid_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payments_reference_unique` (`reference`),
  UNIQUE KEY `payments_provider_provider_txn_id_unique` (`provider`,`provider_txn_id`),
  KEY `payments_branch_id_foreign` (`branch_id`),
  KEY `payments_order_id_foreign` (`order_id`),
  KEY `payments_refund_of_id_foreign` (`refund_of_id`),
  KEY `payments_cash_session_id_foreign` (`cash_session_id`),
  KEY `payments_cashier_id_foreign` (`cashier_id`),
  KEY `payments_tenant_id_order_id_index` (`tenant_id`,`order_id`),
  KEY `payments_tenant_id_branch_id_status_index` (`tenant_id`,`branch_id`,`status`),
  KEY `payments_tenant_id_cash_session_id_index` (`tenant_id`,`cash_session_id`),
  CONSTRAINT `payments_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`),
  CONSTRAINT `payments_cash_session_id_foreign` FOREIGN KEY (`cash_session_id`) REFERENCES `cash_sessions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `payments_cashier_id_foreign` FOREIGN KEY (`cashier_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `payments_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  CONSTRAINT `payments_refund_of_id_foreign` FOREIGN KEY (`refund_of_id`) REFERENCES `payments` (`id`),
  CONSTRAINT `payments_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission_role`
--

DROP TABLE IF EXISTS `permission_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `permission_role` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permission_role_permission_id_role_id_unique` (`permission_id`,`role_id`),
  KEY `permission_role_role_id_foreign` (`role_id`),
  CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission_role`
--

LOCK TABLES `permission_role` WRITE;
/*!40000 ALTER TABLE `permission_role` DISABLE KEYS */;
INSERT INTO `permission_role` VALUES
(10,1,1),
(47,1,2),
(74,1,3),
(7,2,1),
(44,2,2),
(9,3,1),
(46,3,2),
(8,4,1),
(45,4,2),
(6,5,1),
(43,5,2),
(23,6,1),
(59,6,2),
(78,6,3),
(82,6,4),
(18,7,1),
(54,7,2),
(76,7,3),
(22,8,1),
(58,8,2),
(77,8,3),
(19,9,1),
(55,9,2),
(16,10,1),
(52,10,2),
(21,11,1),
(57,11,2),
(20,12,1),
(56,12,2),
(17,13,1),
(53,13,2),
(25,14,1),
(61,14,2),
(83,14,4),
(24,15,1),
(60,15,2),
(5,16,1),
(42,16,2),
(81,16,4),
(4,17,1),
(41,17,2),
(80,17,4),
(36,18,1),
(72,18,2),
(79,18,3),
(33,19,1),
(69,19,2),
(35,20,1),
(71,20,2),
(34,21,1),
(70,21,2),
(14,22,1),
(51,22,2),
(75,22,3),
(11,23,1),
(48,23,2),
(13,24,1),
(50,24,2),
(12,25,1),
(49,25,2),
(32,26,1),
(68,26,2),
(31,27,1),
(67,27,2),
(26,28,1),
(62,28,2),
(30,29,1),
(66,29,2),
(29,30,1),
(65,30,2),
(28,31,1),
(64,31,2),
(27,32,1),
(63,32,2),
(3,33,1),
(40,33,2),
(2,34,1),
(39,34,2),
(37,35,1),
(73,35,2),
(15,36,1),
(1,37,1),
(38,37,2),
(85,38,1),
(86,38,2),
(84,39,1),
(89,40,1),
(92,40,2),
(93,40,5),
(87,41,1),
(90,41,2),
(94,41,6),
(88,42,1),
(91,42,2);
/*!40000 ALTER TABLE `permission_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(50) NOT NULL,
  `action` varchar(50) NOT NULL,
  `key` varchar(101) NOT NULL,
  `label` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_key_unique` (`key`),
  KEY `permissions_module_index` (`module`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES
(1,'catalog','view','catalog.view','Görüntüle','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(2,'catalog','create','catalog.create','Oluştur','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(3,'catalog','update','catalog.update','Güncelle','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(4,'catalog','delete','catalog.delete','Sil','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(5,'catalog','change_price','catalog.change_price','Fiyat değiştir','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(6,'orders','view','orders.view','Görüntüle','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(7,'orders','create','orders.create','Oluştur','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(8,'orders','update','orders.update','Güncelle','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(9,'orders','delete','orders.delete','Sil','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(10,'orders','cancel','orders.cancel','İptal','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(11,'orders','refund','orders.refund','İade','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(12,'orders','discount','orders.discount','İndirim','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(13,'orders','comp','orders.comp','İkram','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(14,'payments','take','payments.take','Ödeme al','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(15,'payments','refund','payments.refund','İade','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(16,'cash','view','cash.view','Görüntüle','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(17,'cash','close','cash.close','Kasa kapat','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(18,'tables','view','tables.view','Görüntüle','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(19,'tables','create','tables.create','Oluştur','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(20,'tables','update','tables.update','Güncelle','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(21,'tables','delete','tables.delete','Sil','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(22,'customers','view','customers.view','Görüntüle','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(23,'customers','create','customers.create','Oluştur','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(24,'customers','update','customers.update','Güncelle','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(25,'customers','delete','customers.delete','Sil','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(26,'stock','view','stock.view','Görüntüle','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(27,'stock','adjust','stock.adjust','Stok düzelt','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(28,'reports','view','reports.view','Görüntüle','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(29,'staff','view','staff.view','Görüntüle','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(30,'staff','manage','staff.manage','Yönet','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(31,'roles','view','roles.view','Görüntüle','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(32,'roles','manage','roles.manage','Yönet','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(33,'branches','view','branches.view','Görüntüle','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(34,'branches','manage','branches.manage','Yönet','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(35,'theme','manage','theme.manage','Yönet','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(36,'integrations','manage','integrations.manage','Yönet','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(37,'audit','view','audit.view','Görüntüle','2026-07-22 11:21:41','2026-07-22 11:21:41'),
(38,'settings','view','settings.view','Görüntüle','2026-07-22 12:22:21','2026-07-22 12:22:21'),
(39,'settings','manage','settings.manage','Yönet','2026-07-22 12:22:21','2026-07-22 12:22:21'),
(40,'kds','view','kds.view','Görüntüle','2026-07-22 13:56:26','2026-07-22 13:56:26'),
(41,'kds','deliver','kds.deliver','Teslim / servis (komi)','2026-07-22 13:56:26','2026-07-22 13:56:26'),
(42,'kds','manage','kds.manage','Yönet','2026-07-22 13:56:26','2026-07-22 13:56:26');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_images`
--

DROP TABLE IF EXISTS `product_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_images` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `path` varchar(255) NOT NULL,
  `original_name` varchar(150) DEFAULT NULL,
  `mime` varchar(100) NOT NULL,
  `size` int(10) unsigned NOT NULL,
  `is_primary` tinyint(1) NOT NULL DEFAULT 0,
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_images_product_id_foreign` (`product_id`),
  KEY `product_images_tenant_id_product_id_sort_order_index` (`tenant_id`,`product_id`,`sort_order`),
  CONSTRAINT `product_images_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_images_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_images`
--

LOCK TABLES `product_images` WRITE;
/*!40000 ALTER TABLE `product_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_variants`
--

DROP TABLE IF EXISTS `product_variants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_variants` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `price_minor` bigint(20) unsigned NOT NULL DEFAULT 0,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_variants_product_id_foreign` (`product_id`),
  KEY `product_variants_tenant_id_product_id_sort_order_index` (`tenant_id`,`product_id`,`sort_order`),
  CONSTRAINT `product_variants_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_variants_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_variants`
--

LOCK TABLES `product_variants` WRITE;
/*!40000 ALTER TABLE `product_variants` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_variants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `branch_id` bigint(20) unsigned DEFAULT NULL,
  `category_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `sku` varchar(64) DEFAULT NULL,
  `barcode` varchar(64) DEFAULT NULL,
  `price_minor` bigint(20) unsigned NOT NULL DEFAULT 0,
  `cost_minor` bigint(20) unsigned DEFAULT NULL,
  `package_price_minor` bigint(20) unsigned DEFAULT NULL,
  `kiosk_price_minor` bigint(20) unsigned DEFAULT NULL,
  `qr_price_minor` bigint(20) unsigned DEFAULT NULL,
  `discounted_price_minor` bigint(20) unsigned DEFAULT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TRY',
  `tax_rate` decimal(5,2) NOT NULL DEFAULT 10.00,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `portion` varchar(100) DEFAULT NULL,
  `unit` varchar(30) DEFAULT NULL,
  `prep_minutes` smallint(5) unsigned DEFAULT NULL,
  `calories` smallint(5) unsigned DEFAULT NULL,
  `protein` decimal(6,2) DEFAULT NULL,
  `carbs` decimal(6,2) DEFAULT NULL,
  `fat` decimal(6,2) DEFAULT NULL,
  `spiciness` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `is_new` tinyint(1) NOT NULL DEFAULT 0,
  `is_chef_pick` tinyint(1) NOT NULL DEFAULT 0,
  `is_bestseller` tinyint(1) NOT NULL DEFAULT 0,
  `is_available` tinyint(1) NOT NULL DEFAULT 1,
  `channels` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`channels`)),
  `available_from` time DEFAULT NULL,
  `available_until` time DEFAULT NULL,
  `station` varchar(40) DEFAULT NULL,
  `track_stock` tinyint(1) NOT NULL DEFAULT 0,
  `stock_quantity` int(11) DEFAULT NULL,
  `min_order_qty` smallint(5) unsigned NOT NULL DEFAULT 1,
  `max_order_qty` smallint(5) unsigned DEFAULT NULL,
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_tenant_id_sku_unique` (`tenant_id`,`sku`),
  KEY `products_branch_id_foreign` (`branch_id`),
  KEY `products_tenant_id_branch_id_is_active_index` (`tenant_id`,`branch_id`,`is_active`),
  KEY `products_category_id_foreign` (`category_id`),
  KEY `products_tenant_id_category_id_sort_order_index` (`tenant_id`,`category_id`,`sort_order`),
  CONSTRAINT `products_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `products_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES
(1,1,NULL,1,'Serpme Kahvaltı (2 Kişilik)','Ezine peyniri, eski kaşar, bal-kaymak, tereyağı, zeytin, domates, salatalık, yumurta ve sıcak ekmek sepeti.',NULL,NULL,85000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,1,1,NULL,NULL,NULL,'kitchen',0,NULL,1,NULL,10),
(2,1,NULL,1,'Hızlı Kahvaltı Tabağı','Haşlanmış yumurta, beyaz peynir, kaşar, domates, salatalık, zeytin, bal, tereyağı.',NULL,NULL,32000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,NULL,NULL,'kitchen',0,NULL,1,NULL,20),
(3,1,NULL,1,'Menemen','Geleneksel menemen; taze domates, biber ve yumurta. Yanında ekmek ile.',NULL,NULL,18000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,NULL,NULL,'kitchen',0,NULL,1,NULL,30),
(4,1,NULL,1,'Sucuklu Yumurta','Kangal sucuk ve çiftlik yumurtası. Yanında taze ekmek.',NULL,NULL,20000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,1,1,NULL,NULL,NULL,'kitchen',0,NULL,1,NULL,40),
(5,1,NULL,1,'Pancake Kulesi','4 katlı pancake; mevsim meyveleri, çikolata ve akçaağaç şurubu ile.',NULL,NULL,24000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,1,1,NULL,NULL,NULL,'kitchen',0,NULL,1,NULL,50),
(6,1,NULL,2,'Sigara Böreği (4 Adet)','El açması yufka, beyaz peynir ve maydanoz dolgulu. Ceviz sos ile.',NULL,NULL,12000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,NULL,NULL,'cold_kitchen',0,NULL,1,NULL,10),
(7,1,NULL,2,'Humus Tabağı','Nohut püresi, tahin, zeytinyağı, sumak ve pita ekmeği.',NULL,NULL,10000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,NULL,NULL,'cold_kitchen',0,NULL,1,NULL,20),
(8,1,NULL,2,'Çıtır Tavuk (8 Adet)','Mısır gevrekli kaplamayla çıtırlaştırılmış tavuk parçaları. Ranch sos ile.',NULL,NULL,16000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,1,1,NULL,NULL,NULL,'cold_kitchen',0,NULL,1,NULL,30),
(9,1,NULL,2,'Patates Kızartması','Özel kesim patates, deniz tuzu ve biberiye. Ketçap ile.',NULL,NULL,9000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,NULL,NULL,'cold_kitchen',0,NULL,1,NULL,40),
(10,1,NULL,2,'Soğan Halkası','Çıtır kaplamayla kızartılmış taze soğan halkaları. BBQ sos ile.',NULL,NULL,11000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,NULL,NULL,'cold_kitchen',0,NULL,1,NULL,50),
(11,1,NULL,2,'Mozzarella Stick (6 Adet)','Çıtır kaplamayla kızartılmış mozzarella çubuğu. Marinara sos ile.',NULL,NULL,14000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,1,0,0,1,NULL,NULL,NULL,'cold_kitchen',0,NULL,1,NULL,60),
(12,1,NULL,3,'Izgara Köfte','Kasap köfte; pilav, ızgara domates, biber ve patates kızartması ile.',NULL,NULL,38000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,1,0,1,NULL,NULL,NULL,'grill',0,NULL,1,NULL,10),
(13,1,NULL,3,'Bonfile Lokum','200 gr dana bonfile; tereyağlı patates püresi ve sote sebzeler ile.',NULL,NULL,65000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,1,0,1,NULL,NULL,NULL,'grill',0,NULL,1,NULL,20),
(14,1,NULL,3,'Tavuk Şiş','Marine edilmiş tavuk şiş; bulgur pilavı ve yeşil salata ile.',NULL,NULL,32000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,NULL,NULL,'grill',0,NULL,1,NULL,30),
(15,1,NULL,3,'Piliç Pirzola','Izgara piliç but; fırın patates ve mevsim salata ile.',NULL,NULL,35000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,1,1,NULL,NULL,NULL,'grill',0,NULL,1,NULL,40),
(16,1,NULL,3,'Karışık Izgara','Köfte, tavuk şiş, pirzola, Adana kebap. Pilav ve salata ile.',NULL,NULL,75000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,1,1,NULL,NULL,NULL,'grill',0,NULL,1,NULL,50),
(17,1,NULL,4,'Classic Cheeseburger','160 gr dana burger köftesi, cheddar peyniri, karamelize soğan, turşu, özel sos.',NULL,NULL,32000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,1,1,NULL,NULL,NULL,'grill',0,NULL,1,NULL,10),
(18,1,NULL,4,'Mushroom Burger','160 gr köfte, sote mantar, İsviçre peyniri, trüf mayonez.',NULL,NULL,34000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,NULL,NULL,'grill',0,NULL,1,NULL,20),
(19,1,NULL,4,'BBQ Bacon Burger','160 gr köfte, çıtır bacon, cheddar, BBQ sos, soğan halkası.',NULL,NULL,38000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,1,1,NULL,NULL,NULL,'grill',0,NULL,1,NULL,30),
(20,1,NULL,4,'Chicken Burger','Çıtır tavuk file, marul, domates, ranch sos.',NULL,NULL,29000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,NULL,NULL,'grill',0,NULL,1,NULL,40),
(21,1,NULL,4,'Double Smash Burger','2×120 gr smash köfte, double cheddar, karamelize soğan, özel smash sos.',NULL,NULL,42000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,1,0,1,NULL,NULL,NULL,'grill',0,NULL,1,NULL,50),
(22,1,NULL,4,'Vegan Burger','Mercimek ve sebze köftesi, vegan peynir, avokado, özel vegan sos.',NULL,NULL,35000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,NULL,NULL,'grill',0,NULL,1,NULL,60),
(23,1,NULL,5,'Margherita','Domates sos, taze mozzarella, fesleğen, sızma zeytinyağı.',NULL,NULL,25000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,NULL,NULL,'oven',0,NULL,1,NULL,10),
(24,1,NULL,5,'Karışık Pizza','Sucuk, sosis, mantar, mısır, yeşil biber, zeytin, mozzarella.',NULL,NULL,32000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,1,1,NULL,NULL,NULL,'oven',0,NULL,1,NULL,20),
(25,1,NULL,5,'Pepperoni','Bol pepperoni, mozzarella, domates sos.',NULL,NULL,30000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,1,1,NULL,NULL,NULL,'oven',0,NULL,1,NULL,30),
(26,1,NULL,5,'Sucuklu Pizza','Kangal sucuk, kaşar, mozzarella, domates sos.',NULL,NULL,28000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,NULL,NULL,'oven',0,NULL,1,NULL,40),
(27,1,NULL,6,'Fettuccine Alfredo','Krema, mantar, parmesan ve tavuk parçaları ile.',NULL,NULL,29000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,1,1,NULL,NULL,NULL,'kitchen',0,NULL,1,NULL,10),
(28,1,NULL,6,'Spaghetti Bolonez','Kıyma soslu klasik İtalyan makarna. Parmesan ile servis.',NULL,NULL,26000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,NULL,NULL,'kitchen',0,NULL,1,NULL,20),
(29,1,NULL,6,'Penne Arrabbiata','Acılı domates sos, sarımsak, fesleğen. Vegan seçeneği.',NULL,NULL,24000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,NULL,NULL,'kitchen',0,NULL,1,NULL,30),
(30,1,NULL,6,'Mantarlı Makarna','Krema soslu karışık mantar, kekik ve parmesan.',NULL,NULL,25000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,1,0,0,1,NULL,NULL,NULL,'kitchen',0,NULL,1,NULL,40),
(31,1,NULL,7,'Sezar Salata','Marul, kruton, parmesan, tavuk ve Sezar sos.',NULL,NULL,22000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,NULL,NULL,'cold_kitchen',0,NULL,1,NULL,10),
(32,1,NULL,7,'Akdeniz Salata','Roka, domates, salatalık, zeytin, lor peyniri, nar ekşisi.',NULL,NULL,18000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,NULL,NULL,'cold_kitchen',0,NULL,1,NULL,20),
(33,1,NULL,7,'Ton Balıklı Salata','Ton balığı, mısır, havuç, marul, limon sos.',NULL,NULL,26000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,1,1,NULL,NULL,NULL,'cold_kitchen',0,NULL,1,NULL,30),
(34,1,NULL,7,'Avokadolu Tavuk Salata','Izgara tavuk, avokado, cherry domates, kinoa, yeşil sos.',NULL,NULL,28000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,1,0,1,NULL,NULL,NULL,'cold_kitchen',0,NULL,1,NULL,40),
(35,1,NULL,8,'Kaşarlı Tost','Bol kaşarlı klasik tost.',NULL,NULL,12000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,NULL,NULL,'kitchen',0,NULL,1,NULL,10),
(36,1,NULL,8,'Karışık Tost','Kaşar, sucuk, domates, yeşil biber.',NULL,NULL,16000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,1,1,NULL,NULL,NULL,'kitchen',0,NULL,1,NULL,20),
(37,1,NULL,8,'Club Sandwich','Tavuk, bacon, marul, domates, mayonez. Patates ile.',NULL,NULL,22000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,NULL,NULL,'kitchen',0,NULL,1,NULL,30),
(38,1,NULL,8,'Tavuklu Wrap','Izgara tavuk, marul, domates, ranch sos, lavaş ekmeği.',NULL,NULL,20000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,1,0,0,1,NULL,NULL,NULL,'kitchen',0,NULL,1,NULL,40),
(39,1,NULL,8,'Kasap Köfte Sandviç','El yapımı köfte, kaşar, domates, turşu, özel sos. Yanında patates.',NULL,NULL,26000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,1,1,NULL,NULL,NULL,'kitchen',0,NULL,1,NULL,50),
(40,1,NULL,9,'San Sebastian Cheesecake','Akışkan iç dokusuyla; yanında Belçika çikolatası sosu ile.',NULL,NULL,22000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,1,1,NULL,NULL,NULL,'dessert',0,NULL,1,NULL,10),
(41,1,NULL,9,'Çikolatalı Sufle','Sıcak akışkan çikolata; yanında vanilyalı dondurma ile.',NULL,NULL,20000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,1,0,1,NULL,NULL,NULL,'dessert',0,NULL,1,NULL,20),
(42,1,NULL,9,'Waffle','Taze waffle; çikolata sos, muz, dondurma ve fındık ile.',NULL,NULL,18000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,1,1,NULL,NULL,NULL,'dessert',0,NULL,1,NULL,30),
(43,1,NULL,9,'Künefe','Antep fıstıklı geleneksel künefe. Dondurma ile servis.',NULL,NULL,25000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,NULL,NULL,'dessert',0,NULL,1,NULL,40),
(44,1,NULL,9,'Tiramisu','Klasik İtalyan tiramisu; mascarpone ve espresso ile.',NULL,NULL,21000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,NULL,NULL,'dessert',0,NULL,1,NULL,50),
(45,1,NULL,9,'Magnolia','Muzlu magnolia; üzüm ve ceviz ile.',NULL,NULL,19000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,1,0,0,1,NULL,NULL,NULL,'dessert',0,NULL,1,NULL,60),
(46,1,NULL,10,'Türk Kahvesi','Geleneksel lezzet, lokum ile servis.',NULL,NULL,8000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,NULL,NULL,'coffee',0,NULL,1,NULL,10),
(47,1,NULL,10,'Espresso','Çift shot espresso; yoğun ve aromatik.',NULL,NULL,9000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,NULL,NULL,'coffee',0,NULL,1,NULL,20),
(48,1,NULL,10,'Americano','Espresso ve sıcak su. Hafif ve dengeli.',NULL,NULL,10000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,NULL,NULL,'coffee',0,NULL,1,NULL,30),
(49,1,NULL,10,'Latte','Espresso ve buharda ısıtılmış süt. Kremsi doku.',NULL,NULL,11000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,1,1,NULL,NULL,NULL,'coffee',0,NULL,1,NULL,40),
(50,1,NULL,10,'Cappuccino','Espresso, süt köpüğü ve kakao tozu ile.',NULL,NULL,11000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,NULL,NULL,'coffee',0,NULL,1,NULL,50),
(51,1,NULL,10,'Mocha','Espresso, çikolata ve süt. Krema ile.',NULL,NULL,13000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,NULL,NULL,'coffee',0,NULL,1,NULL,60),
(52,1,NULL,10,'Sıcak Çikolata','Belçika çikolatası, süt ve krema.',NULL,NULL,12000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,NULL,NULL,'coffee',0,NULL,1,NULL,70),
(53,1,NULL,10,'Chai Latte','Baharatlı chai ve buharda ısıtılmış süt.',NULL,NULL,12000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:16','2026-07-22 12:26:16',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,1,0,0,1,NULL,NULL,NULL,'coffee',0,NULL,1,NULL,80),
(54,1,NULL,10,'Filtre Kahve','Günün filtre kahvesi; zengin aroma.',NULL,NULL,8000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:17','2026-07-22 12:26:17',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,NULL,NULL,'coffee',0,NULL,1,NULL,90),
(55,1,NULL,10,'Çay (Bardak)','Rize çayı, demlik servis.',NULL,NULL,3000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:17','2026-07-22 12:26:17',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,NULL,NULL,'coffee',0,NULL,1,NULL,100),
(56,1,NULL,11,'Ev Yapımı Limonata','Taze limon, nane ve şeker ile.',NULL,NULL,10000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:17','2026-07-22 12:26:17',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,1,1,NULL,NULL,NULL,'bar',0,NULL,1,NULL,10),
(57,1,NULL,11,'Ice Americano','Soğuk su ve buz üzerinde çift espresso.',NULL,NULL,12000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:17','2026-07-22 12:26:17',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,NULL,NULL,'bar',0,NULL,1,NULL,20),
(58,1,NULL,11,'Iced Latte','Soğuk süt ve buz üzerinde espresso.',NULL,NULL,13000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:17','2026-07-22 12:26:17',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,1,1,NULL,NULL,NULL,'bar',0,NULL,1,NULL,30),
(59,1,NULL,11,'Milkshake (Çikolata)','Belçika çikolatası, süt ve dondurma.',NULL,NULL,14000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:17','2026-07-22 12:26:17',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,NULL,NULL,'bar',0,NULL,1,NULL,40),
(60,1,NULL,11,'Mango Smoothie','Taze mango, muz ve portakal suyu.',NULL,NULL,15000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:17','2026-07-22 12:26:17',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,NULL,NULL,'bar',0,NULL,1,NULL,50),
(61,1,NULL,11,'Taze Portakal Suyu','Sıkma taze portakal suyu.',NULL,NULL,10000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:17','2026-07-22 12:26:17',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,NULL,NULL,'bar',0,NULL,1,NULL,60),
(62,1,NULL,11,'Meyveli Soda','Limon, nar veya şeftali aromalı soda.',NULL,NULL,9000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:17','2026-07-22 12:26:17',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,NULL,NULL,'bar',0,NULL,1,NULL,70),
(63,1,NULL,11,'Mojito (Alkolsüz)','Nane, lime, şeker ve soda.',NULL,NULL,11000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:17','2026-07-22 12:26:17',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,1,0,0,1,NULL,NULL,NULL,'bar',0,NULL,1,NULL,80),
(64,1,NULL,12,'Klasik Nargile','Tek aroma, standart köz servisi. 60+ aroma seçeneği.',NULL,NULL,25000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:17','2026-07-22 12:26:17',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,0,1,NULL,NULL,NULL,'hookah',0,NULL,1,NULL,10),
(65,1,NULL,12,'Premium Nargile','Özel karışım aroma, hindistan cevizi közü, buz aparatı dahil.',NULL,NULL,35000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:17','2026-07-22 12:26:17',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,1,1,NULL,NULL,NULL,'hookah',0,NULL,1,NULL,20),
(66,1,NULL,12,'VIP Nargile (Özel Karışım)','Şefin özel aroma karışımı, premium köz, meyve başlığı ve buz aparatı.',NULL,NULL,45000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:17','2026-07-22 12:26:17',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,1,0,1,NULL,NULL,NULL,'hookah',0,NULL,1,NULL,30),
(67,1,NULL,12,'Meyve Başlıklı Nargile','Ananas, portakal veya karpuz başlığı ile nargile deneyimi.',NULL,NULL,40000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:17','2026-07-22 12:26:17',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,0,0,1,1,NULL,NULL,NULL,'hookah',0,NULL,1,NULL,40),
(68,1,NULL,12,'Buz Nargile','Buzlu nargile deneyimi; mentol aroma, buz aparatı.',NULL,NULL,38000,NULL,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:26:17','2026-07-22 12:26:17',NULL,'porsiyon',15,NULL,NULL,NULL,NULL,0,1,0,0,1,NULL,NULL,NULL,'hookah',0,NULL,1,NULL,50),
(69,1,NULL,9,'Fıstıklı Baklava (4 Dilim)','Antep fıstıklı el açması baklava; kaymak eşliğinde servis edilir.','TTL-BKL-01',NULL,24000,9500,NULL,NULL,NULL,NULL,'TRY',10.00,1,'2026-07-22 12:29:40','2026-07-22 12:29:40','4 dilim','porsiyon',10,NULL,NULL,NULL,NULL,0,0,1,0,1,'[\"qr\",\"kiosk\",\"package\",\"pos\"]',NULL,NULL,'dessert',0,NULL,1,NULL,110);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qr_scans`
--

DROP TABLE IF EXISTS `qr_scans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `qr_scans` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned DEFAULT NULL,
  `table_id` bigint(20) unsigned DEFAULT NULL,
  `token` char(26) NOT NULL,
  `result` varchar(20) NOT NULL,
  `ip_hash` char(64) NOT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `qr_scans_token_index` (`token`),
  KEY `qr_scans_ip_hash_result_created_at_index` (`ip_hash`,`result`,`created_at`),
  KEY `qr_scans_tenant_id_created_at_index` (`tenant_id`,`created_at`),
  CONSTRAINT `qr_scans_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qr_scans`
--

LOCK TABLES `qr_scans` WRITE;
/*!40000 ALTER TABLE `qr_scans` DISABLE KEYS */;
INSERT INTO `qr_scans` VALUES
(1,NULL,NULL,'AAAAAAAAAAAAAAAAAAAAAAAAAA','invalid','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','curl/7.61.1','2026-07-22 12:27:30'),
(2,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','curl/7.61.1','2026-07-22 12:28:07'),
(3,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','curl/7.61.1','2026-07-22 12:28:07'),
(4,1,5,'MORZ4NOWRJHUMREW7XR5QWEQGU','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','curl/7.61.1','2026-07-22 12:28:19'),
(5,1,5,'MORZ4NOWRJHUMREW7XR5QWEQGU','revoked','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','curl/7.61.1','2026-07-22 12:28:19'),
(6,1,5,'D3XO2MWRTGXUUKGUJOAEA5GZ4E','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','curl/7.61.1','2026-07-22 12:28:20'),
(7,1,5,'D3XO2MWRTGXUUKGUJOAEA5GZ4E','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','curl/7.61.1','2026-07-22 12:28:20'),
(8,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','curl/7.61.1','2026-07-22 12:34:24'),
(9,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','curl/7.61.1','2026-07-22 12:34:24'),
(10,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','curl/7.61.1','2026-07-22 12:42:29'),
(11,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','curl/7.61.1','2026-07-22 12:42:29'),
(12,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','curl/7.61.1','2026-07-22 12:44:19'),
(13,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c96ee2cc2de6f72cd26f71fe8d223f83c13398b3a6774370f3fc8d15717a785','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/150.0.7871.113 Mobile/15E148 Safari/604.1','2026-07-22 12:47:00'),
(14,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c96ee2cc2de6f72cd26f71fe8d223f83c13398b3a6774370f3fc8d15717a785','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/150.0.7871.113 Mobile/15E148 Safari/604.1','2026-07-22 12:53:26'),
(15,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c96ee2cc2de6f72cd26f71fe8d223f83c13398b3a6774370f3fc8d15717a785','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/150.0.7871.113 Mobile/15E148 Safari/604.1','2026-07-22 12:53:33'),
(16,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','curl/7.61.1','2026-07-22 12:55:09'),
(17,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','curl/7.61.1','2026-07-22 12:55:20'),
(18,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','curl/7.61.1','2026-07-22 12:55:20'),
(19,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 12:56:28'),
(20,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 12:57:19'),
(21,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 12:58:27'),
(22,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 12:59:16'),
(23,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 12:59:59'),
(24,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c96ee2cc2de6f72cd26f71fe8d223f83c13398b3a6774370f3fc8d15717a785','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/150.0.7871.113 Mobile/15E148 Safari/604.1','2026-07-22 13:00:14'),
(25,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 13:00:52'),
(26,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 13:00:56'),
(27,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 13:01:19'),
(28,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 13:01:46'),
(29,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 13:01:50'),
(30,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c96ee2cc2de6f72cd26f71fe8d223f83c13398b3a6774370f3fc8d15717a785','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/150.0.7871.113 Mobile/15E148 Safari/604.1','2026-07-22 13:02:11'),
(31,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','curl/7.61.1','2026-07-22 13:02:25'),
(32,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','curl/7.61.1','2026-07-22 13:02:25'),
(33,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c96ee2cc2de6f72cd26f71fe8d223f83c13398b3a6774370f3fc8d15717a785','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/150.0.7871.113 Mobile/15E148 Safari/604.1','2026-07-22 13:02:38'),
(34,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 13:05:42'),
(35,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 13:05:46'),
(36,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-22 13:05:48'),
(37,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','curl/7.61.1','2026-07-22 13:06:09'),
(38,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c96ee2cc2de6f72cd26f71fe8d223f83c13398b3a6774370f3fc8d15717a785','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/150.0.7871.113 Mobile/15E148 Safari/604.1','2026-07-22 13:06:22'),
(39,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','curl/7.61.1','2026-07-22 13:06:50'),
(40,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c96ee2cc2de6f72cd26f71fe8d223f83c13398b3a6774370f3fc8d15717a785','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/150.0.7871.113 Mobile/15E148 Safari/604.1','2026-07-22 13:07:22'),
(41,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','curl/7.61.1','2026-07-22 13:07:54'),
(42,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','curl/7.61.1','2026-07-22 13:08:18'),
(43,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c96ee2cc2de6f72cd26f71fe8d223f83c13398b3a6774370f3fc8d15717a785','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/150.0.7871.113 Mobile/15E148 Safari/604.1','2026-07-22 13:08:31'),
(44,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','curl/7.61.1','2026-07-22 13:08:36'),
(45,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c96ee2cc2de6f72cd26f71fe8d223f83c13398b3a6774370f3fc8d15717a785','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/150.0.7871.113 Mobile/15E148 Safari/604.1','2026-07-22 13:08:37'),
(46,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c96ee2cc2de6f72cd26f71fe8d223f83c13398b3a6774370f3fc8d15717a785','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/150.0.7871.113 Mobile/15E148 Safari/604.1','2026-07-22 13:08:41'),
(47,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c96ee2cc2de6f72cd26f71fe8d223f83c13398b3a6774370f3fc8d15717a785','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/150.0.7871.113 Mobile/15E148 Safari/604.1','2026-07-22 13:08:42'),
(48,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','curl/7.61.1','2026-07-22 13:09:11'),
(49,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','curl/7.61.1','2026-07-22 13:10:39'),
(50,NULL,NULL,'AAAAAAAA','invalid','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','curl/7.61.1','2026-07-22 13:10:39'),
(51,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c96ee2cc2de6f72cd26f71fe8d223f83c13398b3a6774370f3fc8d15717a785','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/150.0.7871.113 Mobile/15E148 Safari/604.1','2026-07-22 13:11:15'),
(52,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c96ee2cc2de6f72cd26f71fe8d223f83c13398b3a6774370f3fc8d15717a785','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/150.0.7871.113 Mobile/15E148 Safari/604.1','2026-07-22 13:11:21'),
(53,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','curl/7.61.1','2026-07-22 13:12:31'),
(54,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','curl/7.61.1','2026-07-22 13:12:31'),
(55,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c96ee2cc2de6f72cd26f71fe8d223f83c13398b3a6774370f3fc8d15717a785','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/150.0.7871.113 Mobile/15E148 Safari/604.1','2026-07-22 13:14:31'),
(56,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c96ee2cc2de6f72cd26f71fe8d223f83c13398b3a6774370f3fc8d15717a785','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/150.0.7871.113 Mobile/15E148 Safari/604.1','2026-07-22 13:14:48'),
(57,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','curl/7.61.1','2026-07-22 13:20:21'),
(58,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','curl/7.61.1','2026-07-22 13:20:21'),
(59,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','curl/7.61.1','2026-07-22 13:20:21'),
(60,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','curl/7.61.1','2026-07-22 13:20:21'),
(61,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','curl/7.61.1','2026-07-22 13:20:21'),
(62,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c96ee2cc2de6f72cd26f71fe8d223f83c13398b3a6774370f3fc8d15717a785','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/150.0.7871.113 Mobile/15E148 Safari/604.1','2026-07-22 13:22:15'),
(63,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c96ee2cc2de6f72cd26f71fe8d223f83c13398b3a6774370f3fc8d15717a785','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/150.0.7871.113 Mobile/15E148 Safari/604.1','2026-07-22 13:25:52'),
(64,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c96ee2cc2de6f72cd26f71fe8d223f83c13398b3a6774370f3fc8d15717a785','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/150.0.7871.113 Mobile/15E148 Safari/604.1','2026-07-22 13:25:59'),
(65,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','curl/7.61.1','2026-07-22 13:26:12'),
(66,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c96ee2cc2de6f72cd26f71fe8d223f83c13398b3a6774370f3fc8d15717a785','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/150.0.7871.113 Mobile/15E148 Safari/604.1','2026-07-22 13:26:20'),
(67,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c96ee2cc2de6f72cd26f71fe8d223f83c13398b3a6774370f3fc8d15717a785','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/150.0.7871.113 Mobile/15E148 Safari/604.1','2026-07-22 14:02:11'),
(68,1,1,'5C5J5UAFDITI72TS4FDI55SFHQ','ok','9c5941f7a0febafd51260b1f0d68fce6296d9156ed6340b39874d96898e9d178','curl/7.61.1','2026-07-22 16:56:35');
/*!40000 ALTER TABLE `qr_scans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_user`
--

DROP TABLE IF EXISTS `role_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_user_role_id_user_id_unique` (`role_id`,`user_id`),
  KEY `role_user_user_id_foreign` (`user_id`),
  CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_user`
--

LOCK TABLES `role_user` WRITE;
/*!40000 ALTER TABLE `role_user` DISABLE KEYS */;
INSERT INTO `role_user` VALUES
(1,1,1,'2026-07-22 11:21:41','2026-07-22 11:21:41'),
(2,1,2,NULL,NULL);
/*!40000 ALTER TABLE `role_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `slug` varchar(120) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `is_system` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_tenant_id_slug_unique` (`tenant_id`,`slug`),
  KEY `roles_tenant_id_is_system_index` (`tenant_id`,`is_system`),
  CONSTRAINT `roles_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES
(1,1,'Sahip','sahip','Sahip rolü',1,'2026-07-22 11:21:41','2026-07-22 11:21:41'),
(2,1,'Müdür','mudur','Müdür rolü',0,'2026-07-22 11:21:41','2026-07-22 11:21:41'),
(3,1,'Garson','garson','Garson rolü',0,'2026-07-22 11:21:41','2026-07-22 11:21:41'),
(4,1,'Kasiyer','kasiyer','Kasiyer rolü',0,'2026-07-22 11:21:41','2026-07-22 11:21:41'),
(5,1,'Mutfak','mutfak','Mutfak rolü',0,'2026-07-22 13:56:27','2026-07-22 13:56:27'),
(6,1,'Komi','komi','Komi rolü',0,'2026-07-22 13:56:27','2026-07-22 13:56:27');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_requests`
--

DROP TABLE IF EXISTS `service_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_requests` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `branch_id` bigint(20) unsigned NOT NULL,
  `table_id` bigint(20) unsigned NOT NULL,
  `kind` varchar(10) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'open',
  `handled_by_id` bigint(20) unsigned DEFAULT NULL,
  `handled_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `service_requests_branch_id_foreign` (`branch_id`),
  KEY `service_requests_table_id_foreign` (`table_id`),
  KEY `service_requests_handled_by_id_foreign` (`handled_by_id`),
  KEY `service_requests_tenant_id_branch_id_status_index` (`tenant_id`,`branch_id`,`status`),
  KEY `service_requests_tenant_id_table_id_kind_status_index` (`tenant_id`,`table_id`,`kind`,`status`),
  CONSTRAINT `service_requests_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `service_requests_handled_by_id_foreign` FOREIGN KEY (`handled_by_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `service_requests_table_id_foreign` FOREIGN KEY (`table_id`) REFERENCES `tables` (`id`) ON DELETE CASCADE,
  CONSTRAINT `service_requests_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_requests`
--

LOCK TABLES `service_requests` WRITE;
/*!40000 ALTER TABLE `service_requests` DISABLE KEYS */;
INSERT INTO `service_requests` VALUES
(1,1,1,1,'waiter','done',2,'2026-07-22 13:20:44','2026-07-22 13:20:21','2026-07-22 13:20:44');
/*!40000 ALTER TABLE `service_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES
('0brl3OpzDfzZCnzKv2W6DCbHuKFU39IhVOkukwGy',NULL,'127.0.0.1','Symfony','eyJfdG9rZW4iOiJXWlB4c1hDM3c0M1RWNVZrR0VrbDV4VHgwa0dXcVRXQzNnTVpZNTljIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9wYXJvbGEtc2lmaXJsYSIsInJvdXRlIjoicGFzc3dvcmQucmVxdWVzdCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1784739652),
('11xc1kkBikJ5gv41M1mTfb3gSVSG5KuJJsieSjnj',NULL,'85.137.57.233','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJrcUZKM24yS1dBa0pHS1NLdVZ0dDZwc0JxeUExYzI0alp4alg4NUZ0IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1784734963),
('2NcnlapMNNpaa3Zxx4w4KfhsWEWmmcULDlPXmTgU',2,'46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','eyJfdG9rZW4iOiJ2VUZ4aWp5Y3pYZUVnRG5Dbko1QmFkRGZCNDVhcjBmVzZkMjdSYWRhIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9wYW5lbCIsInJvdXRlIjoicGFuZWwuZGFzaGJvYXJkIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfSwibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiOjJ9',1784733127),
('2x7AynB7L11OzlybDWcvvyC0CtIEQ2IoLNww2Pth',2,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJqSHR1UGtpNGJ4UHlSMkJwSjBQdFVqS1FnYTlPR3dicWk0ejV5cEJlIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9wYW5lbFwvYXlhcmxhclwvZS1wb3N0YSIsInJvdXRlIjoicGFuZWwuc2V0dGluZ3MubWFpbCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX0sImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjoyfQ==',1784734571),
('3f3FuRcaKXQpNRXcp1wApxtM8ujeb5YTifttw7U2',2,'46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','eyJfdG9rZW4iOiJvYmJYend0SDVHYVQ5dzFUbGJDZ2lkbXFHMXRtOHZTNVlKSjFLY1NSIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9wYW5lbCIsInJvdXRlIjoicGFuZWwuZGFzaGJvYXJkIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfSwibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiOjJ9',1784733129),
('3sCcDRNeVEReBBKaieAW5HROov7PsHWZYbzcwWAK',NULL,'32.185.185.112','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJXdjFjMVlzVDNNOXdrNVdPYzRaSWJET1JlV0lXRVpuMEVDd0RNVzBvIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cL3FybWVudS5ib2dhaG9zdGRldmVsb3Blci5jb20udHJcL2dpcmlzIiwicm91dGUiOiJsb2dpbiJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1784734006),
('3Y40O2X2K7ijrPIScwq6puusOaocSq327q7Ii0kT',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiIxSlpTcmpLVlQyeVNTUEJIdmhxMkF0YVdiaGk0NVFPa2FFdm9uRlMwIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC90YXNhcmltXC9tZW51Iiwicm91dGUiOiJkZXNpZ24ubWVudSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1784733199),
('47OShyCVDoHEzepmrF34r00YNuM0HjBKBvi6owPW',2,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJTOG91UjBFeHZ6ZzdZR3Q2N3JveldKUWxUTVFCeTQ5OVNsWDAzT0x3IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9hcGlcL3YxXC9vcmRlcnNcL2NhdGFsb2c/YnJhbmNoX2lkPTEiLCJyb3V0ZSI6Im9yZGVycy5jYXRhbG9nIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfSwibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiOjJ9',1784736719),
('4E08ytV2cXl1o7FVjMjYFlgYYbrNhXK2DQljJBNI',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiI3OWZLV3E5M0NFakZHQzg2YzZFNzhwdEJWVExWZWd2eExGQ3ZHNU1iIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784734396),
('4rGmMS0ezSsJ90gw7yUJSrf1p8fVs81ARnWHjIdG',NULL,'127.0.0.1','Symfony','eyJfdG9rZW4iOiJmYW9zbzd0eEp4djNBdWxHNmt2alFBdThtcURydDNqODZLclJKblVrIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpc1wvcGluIiwicm91dGUiOiJsb2dpbi5waW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784738054),
('50i9Wkslj2wKqGnXQDbnegCOnbNRB6b08HmYFHjx',NULL,'127.0.0.1','Symfony','eyJfdG9rZW4iOiI2TktrS05YVUhKVVV1VkxaNllUMGlETktKM2Qzbk1DRmZFWW15emF2IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9wYXJvbGEtc2lmaXJsYSIsInJvdXRlIjoicGFzc3dvcmQucmVxdWVzdCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1784739407),
('6Aqas97tCzveniPcc698owuD6ZxCM9WLVmK2RX2s',NULL,'54.247.57.72','Mozilla/5.0 (X11; Linux x86_64; rv:83.0) Gecko/20100101 Firefox/83.0','eyJfdG9rZW4iOiJ0cUtSNDZCbWFJTk14N3E1S0pVMUZwN2RERXdoSXlwbFpITG5RSTJQIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784737096),
('6Jtwb7ZZrPT04mzYme3xXfTy91Pbom6dCw6tuTND',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJ3YklJTlZtMk9Hdlg2MGdaaUdrOE1BWmYyM3o1MktsT2U2U3VtRG9VIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1784739649),
('6SDJMcedCNGc6tEdUiKezrSxrv0N7nyhJX3BDFCM',2,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJaZGxLdUJTaEJLbUo1cHBPbjJCblloYjZ3YlAwaTIxWGlCWmh5RWdzIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9wYW5lbFwvc3ViZWxlciIsInJvdXRlIjoicGFuZWwudmVudWUuYnJhbmNoZXMifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119LCJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI6Mn0=',1784734109),
('7A21ymkSeKM0H6q0rWKe7a156LQFgxyXFdsb3AsK',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJwaUFkdDF6eEdhVmM2MEg5ZEQwN3hPUmlVVTZlUFQ4aXlXM2RIRUpSIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784737415),
('7TSUWnAGM71mMTcEZ4nHSqH2W6E6ZSynvOZC3T6m',2,'149.86.151.79','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJkRUNPNUhXb00xRU0xa1A1c1Q1MlgxblJ6ZFRrWFBXNGNkUHlBVG5sIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9wYW5lbCIsInJvdXRlIjoicGFuZWwuZGFzaGJvYXJkIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfSwibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiOjJ9',1784750242),
('872tpDD8hN3SKRBk1LwWAXmtRq5r5GsFIBN6vmNI',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJmMzdOSlhxWVV0bER2SVg0UExWRTFkczBjdXlJY0JjakxvZmVVOVpTIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1784733199),
('8r2KRjT9zpRbv822GLJKnc4VhdCYlYpdzG6FYMvL',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJIMkhmRjBaVVF6Q0o2aXFOUjdOWEtaUWFYNDdzNXlVaGF6SXltSFE5IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784739987),
('8z7SczYkZvGPvv01J6XnWwzG8q8XqVlIGVwjLb03',NULL,'23.27.145.170','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJ2NVFVelhQNlVyRnMyZTJFVGNqMFdPNFhYUTV2NnpJUnNkRUh1OTkwIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784739850),
('9coJwa7iy8fgCUh3TdqCmjpgxcugIO0vtBTaNcID',NULL,'127.0.0.1','Symfony','eyJfdG9rZW4iOiJITEZuMkg4TFJDQ2g5TUFXZUNuRFJyd0lzN0o0WTJFUFd6Y3NnRDd4IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1784738054),
('9JIdk31JR3JKQAm0UY4AefxonWOPSed6kgzMPTyq',NULL,'127.0.0.1','Symfony','eyJfdG9rZW4iOiIyWGpvcVBYVlZJT1FLaUJOOGtDZUFPeHA0U2FPam1DbjBqWlZwcmpYIiwidXJsIjp7ImludGVuZGVkIjoiaHR0cHM6XC9cL3FybWVudS5ib2dhaG9zdGRldmVsb3Blci5jb20udHJcL3BhbmVsIn0sIl9wcmV2aW91cyI6eyJ1cmwiOiJodHRwczpcL1wvcXJtZW51LmJvZ2Fob3N0ZGV2ZWxvcGVyLmNvbS50clwvcGFuZWwiLCJyb3V0ZSI6InBhbmVsLmRhc2hib2FyZCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1784739636),
('9MLGo2nYXk4CYrGFwRURb7mtPQKO0fQ6faGw4RCh',NULL,'127.0.0.1','Symfony','eyJfdG9rZW4iOiI2eXNwS1VpSHVnenlJdVo5RVFMRVdBd1dEV0FFaXdhcG9RUG9mQ1plIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1784739407),
('9oV0bRC0p1AWThwoqzHVoMV9aNM9ActaW1MbRoM1',2,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJoeVNkMGVNczk4bTJrU3V1Uzk5OEVseU5idmhicDNXRWMwMG1ndmxTIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9hcGlcL3YxXC9vcmRlcnNcL2JvYXJkIiwicm91dGUiOiJvcmRlcnMuYm9hcmQifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119LCJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI6Mn0=',1784737244),
('9wtZJMVyhtz2jVwF824UFQODrCd2iu00h7Fr5jov',NULL,'127.0.0.1','Symfony','eyJfdG9rZW4iOiJmNnlwRFJWU21jWlpkU3dlR1pMaVdwdU4wOEd2VzVqTG9TRWhaQkR4IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784739652),
('aaX1XQlFYttL74t0UAaIOZmGakZtCOj9yvQv3rcj',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJhQzBsak9lNW5xTTNEWXBsNmFQU3R5NW9ySmN1YUNMdGNUN0piV0tKIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1784732926),
('AIdIyCz77Unx78JuUP1H8HLhywfbHFYXJC90HhwU',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJPM0lYMlBucjNYeGRBa0VWNldUNmJKVXh3a01PRzNYTzdHT2l0Vmx6IiwidXJsIjp7ImludGVuZGVkIjoiaHR0cHM6XC9cL3FybWVudS5ib2dhaG9zdGRldmVsb3Blci5jb20udHJcL3BhbmVsIn0sIl9wcmV2aW91cyI6eyJ1cmwiOiJodHRwczpcL1wvcXJtZW51LmJvZ2Fob3N0ZGV2ZWxvcGVyLmNvbS50clwvcGFuZWwiLCJyb3V0ZSI6InBhbmVsLmRhc2hib2FyZCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1784750195),
('AN3NpeTHjyxKpmusuwDc4aeSkU63aR0AZVfHTIEG',2,'88.235.200.157','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/150.0.7871.113 Mobile/15E148 Safari/604.1','eyJfdG9rZW4iOiJNM3ZBN3FyWDNCQ1BQcHhtd3VKTkg5OXZwYzRoVGVZOGFjaEdCbzdzIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9wYW5lbFwvbWVudSIsInJvdXRlIjoicGFuZWwuY2F0YWxvZy5wcm9kdWN0cyJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX0sImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjoyfQ==',1784739685),
('aPZ9sC6nW8pbqVVazOzBLZkgjOxrKTTXWDTNrVbs',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJOMTRMQW5pellYNzE2dFpkYXRGVEcyM3pIRW9vMDRJVHdhS1RPRGQyIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784734387),
('b0IZRLrO2rg2pkYf1jE6wAQx6uoDNazdLjf8vTtV',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJmUlpRc0FyNVdheDg4UlE5ZlBJOUxpZFJWckZhUjNnam1jakhiUXpSIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784739649),
('b9f10wBolyBwtmjGI49Xc6TkoCsBc4NXnrBEqYkZ',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiIwZEJaQmpMVEM4RGY5NHpGQUpzdG9NU3lkTGtTd0tJR0d3d2dZQmJTIiwidXJsIjp7ImludGVuZGVkIjoiaHR0cHM6XC9cL3FybWVudS5ib2dhaG9zdGRldmVsb3Blci5jb20udHJcL3BhbmVsXC9heWFybGFyXC9lLXBvc3RhIn0sIl9wcmV2aW91cyI6eyJ1cmwiOiJodHRwczpcL1wvcXJtZW51LmJvZ2Fob3N0ZGV2ZWxvcGVyLmNvbS50clwvcGFuZWxcL2F5YXJsYXJcL2UtcG9zdGEiLCJyb3V0ZSI6InBhbmVsLnNldHRpbmdzLm1haWwifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784733988),
('BB9bvhxd107frYZTvVP4ZwJbq6PHkP3eXUKTJv0z',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJXT0YzWHNrcWVoc1pYQmQ3OFZVemtmbk4yVFI5ZXRubmhnY0xUUnAzIiwidXJsIjp7ImludGVuZGVkIjoiaHR0cHM6XC9cL3FybWVudS5ib2dhaG9zdGRldmVsb3Blci5jb20udHJcL3BhbmVsXC9tYXNhbGFyIn0sIl9wcmV2aW91cyI6eyJ1cmwiOiJodHRwczpcL1wvcXJtZW51LmJvZ2Fob3N0ZGV2ZWxvcGVyLmNvbS50clwvcGFuZWxcL21hc2FsYXIiLCJyb3V0ZSI6InBhbmVsLnZlbnVlLnRhYmxlcyJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1784734050),
('beAsyNrfNAYrGVoROQ6551zQpi964ii1J5ucN0kp',NULL,'34.222.245.89','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.7871.128 Safari/537.36','eyJfdG9rZW4iOiJESWU1TUhhTzhjWHNrQ0NiR0JBRUtjMUVJU0E5bW5lUmpuem1uQnVqIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784736171),
('BHPDJsdf9JZCBRmVnGs3ihVEV0UisHmUfUNg5eU0',2,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJzRG9mdWJZY0U2OWp0bTRVMG1RU3IxMW43TzRmUER6a3F0SGlBMVVMIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9hcGlcL3YxXC9zZXR0aW5nc1wvbWFpbCIsInJvdXRlIjoic2V0dGluZ3MubWFpbC5zaG93In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfSwibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiOjJ9',1784734073),
('bI2DAUpATrid9hK0jDfzJRitNnmt1CemeObmZr0V',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJLY3Uxd0w0UVJpa2RvOUkxMTlBZEU4dXMxcU4zYkJoemJRWGM0YTFLIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784738221),
('BoIPrhyeg69p5zoptOkIcs5c294aHYSqjGv4845V',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJLSU9GRGtlOXZxajdUTWZjeXFoOGx6SE1UcDVTN2Y4NlZ1SlFBVTBhIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC90YXNhcmltXC9tZW51Iiwicm91dGUiOiJkZXNpZ24ubWVudSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1784733276),
('c07V8Plq03oTLTXg9H0gDLcTbIqIBlw9RrGVX1FZ',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiI0dHhTeTRxM2ZNSU9ud1NySkQ1SGFtQTNVZTVtZGQ2R3pQV2ZhZ2dwIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1784739643),
('CbYDJLZPy4oJPv3PZskfCcuFnqX06arhTClcjLly',2,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJvdXFXdjRmODBrc211OUhYWGlNMlB5YU90MWVoaEtaVU1wbm5DZFNzIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9wYW5lbFwvYXlhcmxhclwvZS1wb3N0YSIsInJvdXRlIjoicGFuZWwuc2V0dGluZ3MubWFpbCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX0sImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjoyfQ==',1784750246),
('cOhm8QKVaeh86sT85SJSIGeE0lf94GrtM1PXQU6M',NULL,'127.0.0.1','Symfony','eyJfdG9rZW4iOiJQWUExb2ZDckFWN0h4Z1puYlpSZG1zdzN5RGxJR2NMWnFCNGgwYXRNIiwidXJsIjp7ImludGVuZGVkIjoiaHR0cHM6XC9cL3FybWVudS5ib2dhaG9zdGRldmVsb3Blci5jb20udHJcL3BhbmVsIn0sIl9wcmV2aW91cyI6eyJ1cmwiOiJodHRwczpcL1wvcXJtZW51LmJvZ2Fob3N0ZGV2ZWxvcGVyLmNvbS50clwvcGFuZWwiLCJyb3V0ZSI6InBhbmVsLmRhc2hib2FyZCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1784739407),
('CrOPZSkJEJxE1vHVbJYlnyWgMqJhhyvoY7wyu4wS',NULL,'46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','eyJfdG9rZW4iOiJWc2lvRWRJcGRhZWEzWUJTSHdLYUpsRE9yTXM1N0dLdzkyaXhaRnFMIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC90YXNhcmltXC9tZW51Iiwicm91dGUiOiJkZXNpZ24ubWVudSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1784733131),
('d2WoeUrT9UgudgByV6av8T7iBncyg9Scg6bRbLbH',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJITVRwUFhoZVFueVVQc0VNWVdnbHJlbWVwa2Y1b0FKM3VKZ3dsUDBVIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784739394),
('DopQF6tZKLYCblYcseAmWYxHTrm4I7AMNRJImYQF',NULL,'127.0.0.1','Symfony','eyJfdG9rZW4iOiJBaVphcm9jM25PejNUZkZWNnJscTRkeEROREZBOEJDN0s5dHBRVlkyIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1784739636),
('eeQ6L9BPApK3jrFZt60Wgfg035LOGfPUqYPs7sIZ',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJZOG81c2JEQlRsNGxqQ3h3SVN6a0JPY1RtazVLYVFOSnlnN2hlT3FWIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784733199),
('EgfBrg1gIherIZbu98tKBvlrw8G64pVMSmLTu0sq',NULL,'54.247.57.72','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJNMm8xU2E3SDEyRUpRWlFZckc3WjVKVjlkdDJvRlFkTFhzbTJiSmVGIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784737096),
('el0krb1dE6tvkmczv3orXo281MbUyHsqhyy494og',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJHV2dwakRodE9tdEJUNVNXU3pibldoRHhjUEYwTm5JQU1ucTNRSmJHIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784733276),
('ESHvNXWJpt1yqu1BJn91CNRTsiG4vopSkaEeVmOa',NULL,'32.185.185.112','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1','eyJfdG9rZW4iOiJtYnVvM096Sm9WbmRwMFZKVGdSSUhrZ2txdjlDTURod3libDBCbU1MIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cL3FybWVudS5ib2dhaG9zdGRldmVsb3Blci5jb20udHIiLCJyb3V0ZSI6ImhvbWUifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784734006),
('eyzAxqwK17SS4zcdAVL2OIHYOybOvjj3EidHNheY',NULL,'127.0.0.1','Symfony','eyJfdG9rZW4iOiJzNmp0SWhHQzdnNmkxOE10eXd0RHNrUkJtM0pnVWZuVTc4dHlVcWx5IiwidXJsIjp7ImludGVuZGVkIjoiaHR0cHM6XC9cL3FybWVudS5ib2dhaG9zdGRldmVsb3Blci5jb20udHJcL3BhbmVsIn0sIl9wcmV2aW91cyI6eyJ1cmwiOiJodHRwczpcL1wvcXJtZW51LmJvZ2Fob3N0ZGV2ZWxvcGVyLmNvbS50clwvcGFuZWwiLCJyb3V0ZSI6InBhbmVsLmRhc2hib2FyZCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1784739652),
('fAdNuHudjSrV1EINGvCwyahKFUofAgicHV7VQgB4',NULL,'127.0.0.1','Symfony','eyJfdG9rZW4iOiJQNkRDRG1JN3NHZEF2aXJLUG8wVmJXeDJDMUZzSnF3dU1GYmZjalFKIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9wYXJvbGEtc2lmaXJsYSIsInJvdXRlIjoicGFzc3dvcmQucmVxdWVzdCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1784736542),
('fAuCiUrTBZLih1NSMEv7ujoTloyoGsM8BrgphhKD',NULL,'127.0.0.1','Symfony','eyJfdG9rZW4iOiJCNmhkWnRSdjA5S3M5S0l1OFZnUGRteHFGZjRoSTFxNE82NFBQRElnIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9wYXJvbGEtc2lmaXJsYSIsInJvdXRlIjoicGFzc3dvcmQucmVxdWVzdCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1784735038),
('G7w7EKs535m4DumDTQRIsdwbmAIq24TqO0MgH7UK',NULL,'45.153.159.41','Mozilla/5.0 (X11; Linux i686; rv:109.0) Gecko/20100101 Firefox/120.0','eyJfdG9rZW4iOiJzM0pYSEFqRm5XSjNhN0tHbjdiZEd6Z0ZPNEhMMmh3M1FMT3ZkcHpoIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784737447),
('gl7FDIIaJR7uw4Th3rr1i3lnnma2Fd302syIpmpT',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiI4V3dMcU9xTk92RlFXOXU0dGs5QkRUMWZBemNIeGVzUFA3M3ZNb0V0IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1784733769),
('GosdqJPuA8dzP1cwAQkNfA2Q95OtTI7CUXnsqX3D',2,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJhZXVsQUJjNmZObnkzamZQRElVRnNLbmY0b0piTkg4dGFyT3Z1QlJ6IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9wYW5lbFwvc2lwYXJpc2xlclwvMiIsInJvdXRlIjoicGFuZWwub3JkZXJzLmRldGFpbCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX0sImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjoyfQ==',1784737276),
('GsGc900mCnXnqQ9MyAfm5uvSqKAL29JuMtv8hl3m',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJnR3RkM2RYYUp1WEw2SWNBSER4TlhMbzM2QWg0Ykk5RlYwaExYWG1OIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1784733988),
('H0QOSOQatwrdNqb2EDrfo7oPFx5r3wo1jeCfLWHV',2,'46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','eyJfdG9rZW4iOiIzZ3Z5ZHZDbFJTRmFWUGhCSndjd3E2WU5EelFkcWREM0ROUnFIbk1GIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9hcGlcL3YxXC9rZHNcL3VwZGF0ZXM/YnJhbmNoX2lkPTEmY3Vyc29yPTMzIiwicm91dGUiOiJrZHMudXBkYXRlcyJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX0sImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjoyfQ==',1784739687),
('h8rBWabUp34di30gxbEID99Uxtkiq7L6zUBBCauH',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJSZ3ZMck00ejE2eUluUnpCUHIwajhFcXBudlAwOTZSQ01rT0lEdm9MIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784739649),
('hXKmHiNjlQvxUkibAw0YlgRjGgUcYDVTUeuRImTS',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJSenQ4WmNCZVhNUnp0NUFIOERPZlN3UkFvOGg2bWNzVG1JQUhSNW1OIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1784734050),
('J2p0I4vyxzX0Q5ckyIKsVwsj1A0in31i5Ai1toqt',1,'46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJPcXlseVBiZ2puVGNFQXFrcmVBSFZQYnFpOVJwb0p1cnFHcklNdXZqIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119LCJfcHJldmlvdXMiOnsidXJsIjoiaHR0cHM6XC9cL3FybWVudS5ib2dhaG9zdGRldmVsb3Blci5jb20udHJcL3BhbmVsXC9tZW51XC91cnVubGVyXC82OSIsInJvdXRlIjoicGFuZWwuY2F0YWxvZy5wcm9kdWN0cy5lZGl0In0sImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjoxfQ==',1784734293),
('JePXUhzyQTnL3SCj9QxaImJN1IkitGNbd6emFciW',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiI2ZXVQWjJhNmFnbG5keGloaFREd3I2VjNHeHR6V1JGeENkeTRzaXVRIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784737193),
('JGIBvcWDuvbQ4IxPNfMueukCbMsmHeO1QjOcuaAP',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJxZEU2MEN3Z0dCbmhkb1Z1Sk5aV2kzd2hKNXNxSnJ0emFyeXNCdGRlIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1784733276),
('jgwRrWTU1z4wytQhkjXoIndjEylwm4nMQG81obGm',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJsSXZYcmpJbzN3MFU4ODl2ZVk2Z0hva0M5T1o2bjF2NFRSamdXV0szIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784750195),
('K1CnZKDY29R3Z4VIluIBeBo7n1rD1lQ8ot9EPElh',NULL,'127.0.0.1','Symfony','eyJfdG9rZW4iOiJQdjFWNzhWc3J0b2ljck1HeUU2ZEZQWjNtdFd4QnlJUEc1U3daM0t0IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784738054),
('KDxJhmgwDKFwYhIVHHQpkr8b4dzqeT0rDUNXmech',NULL,'127.0.0.1','Symfony','eyJfdG9rZW4iOiJxNXJGNDZJdkx4V2NEM3NGdjBIamF1WkRhMERKTjhoTzNxUlRjWHVIIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784736542),
('knaS5zPZW6i5TnqrAVkToUd3L2MsR6RMNKwUvbHs',NULL,'127.0.0.1','Symfony','eyJfdG9rZW4iOiJYcEV3UThHWHpOaEl0Rzl1Ylh0eGVwWDZWOFRVbnRlNUtNQ1d6R0ZJIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784739407),
('l4YvH4Rh0mlqkDQmzvEpfrTr8vt4oZOLG1Zd6CKE',NULL,'127.0.0.1','Symfony','eyJfdG9rZW4iOiJqdlpqWWE0MnRoYUpvYXBobXFlOGhTRlBsWnNjMjV0MWw3Q0xkNDkzIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpc1wvcGluIiwicm91dGUiOiJsb2dpbi5waW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784735038),
('l60BKxrUF1CWWfDvQkc7erEWOlcG2kvEqoPEybHh',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJob1NUeDFhc0NYVllsdXE4UnFRRVdVRUVZR1lFTWF2T2VIcGhTTmZxIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784734050),
('M1Pj5Z26kQdXsBZX3nQ5ZNIYcuimYivAnH11NuSa',NULL,'127.0.0.1','Symfony','eyJfdG9rZW4iOiIzdDJ1VGdZWGREY25hV204aVlEbG96RnF1RDVjbUxHVDdTbU5GdE5VIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784739636),
('mCl0rPpRt5P7zzUxD7Yae7mlmIz0F6kvtb2BkpAA',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJFMXp6UW5SUzFKUHRha0VlcTZRMXVLT256ZXhIZUh1Y0NHZklzTE83IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784734073),
('MhIKuH6svZ7t0XJ23EgvUqrkQL1KXPZDZbvEOLl0',NULL,'127.0.0.1','Symfony','eyJfdG9rZW4iOiI3TzRmRzZKZmpoTlYzdklUallmaW9IUmJJSEQzaTVaU002N29Zck8zIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9wYXJvbGEtc2lmaXJsYSIsInJvdXRlIjoicGFzc3dvcmQucmVxdWVzdCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1784738054),
('mxvHwh95G4jISbwL2U3rs7w4cAI0T5Cg8F321Pd8',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiIwOEh4eW1wQkljM2Vlck04bHdqS0dnNWU3SXJUU3hDdWRkR2tzRFNsIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1784732915),
('MY5x8PGMeu23KLZ0vWh6uuXQ7n29U6W4vsdOWHSP',NULL,'155.254.38.253','SpillBot/1.0 (+https://spill.sh/about; opt-out: https://spill.sh/remove)','eyJfdG9rZW4iOiJMYzBXNGVmS0NmUFV0ZHY4SkFKZkJGUzZCUzY2YldZb3ZMZ0RjelVrIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784736742),
('NGcCUDLLeLtN4ZJ43GAOjoVkksJpMXSrbWNcKsCs',NULL,'34.222.245.89','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1','eyJfdG9rZW4iOiJFQVZBUlNzRlVpeGpkNFdCbXVuYkxjRks0alJPaXhaajBXQ29WcXJxIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784736178),
('NgULACQWl0gFnYe0cW6nIAIqQpdRJTDEacV4Nh7I',2,'46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','eyJfdG9rZW4iOiJ1SmtKSjJxTGtMVkFFalVpb0ZmWkRhMDRmaDR1NjNQRng2N1pJSmhTIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9wYW5lbFwva29taSIsInJvdXRlIjoicGFuZWwua2RzLnJ1bm5lciJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX0sImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjoyfQ==',1784739513),
('NSbkOvvmaW7sQNn7UP6tvCtTeNFKWGqLr0PY6Bql',NULL,'127.0.0.1','Symfony','eyJfdG9rZW4iOiIwd1JIbHluQkk1bzBFNnlmZ0NyTjFJM25lSHpWck5ESEQxS0cyUkRDIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1784739652),
('O7ZdONCx2C2NBz1NHX303Y2K6qfkwXQlqMmt0UhF',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJ4V2ZscFNVT1VHRzczRVNlN2RsNHpMUjN5SU83c0JIOFV6ajJvWFpZIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784733988),
('o8ytBA2QtsJDXrvjXB4nXTIig4IqzwLwJgEi3mbt',2,'46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','eyJfdG9rZW4iOiJTcHdlMGlOZlhKT201NnRaQ2hsdWlxWk9DVDNhZ0gwT0ZmR21uaGt4IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9wYW5lbFwvc2lwYXJpc2xlclwvMiIsInJvdXRlIjoicGFuZWwub3JkZXJzLmRldGFpbCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX0sImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjoyfQ==',1784737333),
('oVS0lGLK3SZqFkIdOZxo5MLrkpzfnkb99N49sRXK',NULL,'127.0.0.1','Symfony','eyJfdG9rZW4iOiJHWHRydzdLOHdJSTNNTVpYT3hidXpHV0RZMllXVXNHQVcyM3p3R1BqIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpc1wvcGluIiwicm91dGUiOiJsb2dpbi5waW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784739636),
('P1ESq2JCuySGr2tzVPBpWSyLaH70m6M3JmcBiIlj',NULL,'155.254.38.253','SpillBot/1.0 (+https://spill.sh/about; opt-out: https://spill.sh/remove)','eyJfdG9rZW4iOiJ3Zjd3ZUhiUm1ZSEVHTHdPNzZYYktjalVUdzJla2pZNm81b3ZWTEptIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1784736742),
('pnLNj5ynYUqRqWIlKcrvWhMLyM1CcJHzQZF8gpdd',2,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJKWUpESktkTXhRdEY2MVE1U3ladDEzT2kyYURoUlI4NnNKTkVZcE1lIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119LCJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI6Mn0=',1784737263),
('pwQds1AGYKAzn2KnZQi71709KTpC5tpXRoAJIuW7',NULL,'127.0.0.1','Symfony','eyJfdG9rZW4iOiJrcWZrUU1CZm1LRW94eXFBZUNJdDdVUExxalJLeUxOZEFvQXR1am9aIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpc1wvcGluIiwicm91dGUiOiJsb2dpbi5waW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784739407),
('qE3LgzfLImigMkBMmgCs912LxVtiwcLJGiH6dWNM',2,'46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','eyJfdG9rZW4iOiJYeG9oN0MxeXIzMVU3RTVWQ05nY3FQMmx4Q3hSWHdGUDFKYVM2MWZsIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9wYW5lbCIsInJvdXRlIjoicGFuZWwuZGFzaGJvYXJkIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfSwibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiOjJ9',1784733121),
('qISG8pysjLHVciyRTcb9ymowEBIPknE4L6OMgQsR',NULL,'127.0.0.1','Symfony','eyJfdG9rZW4iOiI4eFJGcWhweTVPU3RMOWFWeXpHWE0zR1lkZ1g0VXYyMlMwZlMyQVptIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1784736542),
('qvhEKWJWFvLfAYOJcFZFUum4WCC5uIUOeqad6U91',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiIxQ2xKZ08wSEZNcFVFeXBLajBaZmRYUlh6c1FTQ2RjRHplTlZBMmtqIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784732926),
('R6HoN6WzWloDska75VRmmgYhDlhZfvzOYgeuKi1b',2,'88.235.200.157','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJUUnowY1N0c3dxUFgyMGlkRElsRWR5a1Y5aEhqaUVER3VZbTZkSE5xIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9wYW5lbCIsInJvdXRlIjoicGFuZWwuZGFzaGJvYXJkIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfSwibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiOjJ9',1784739984),
('rRX1Ti8hte2ljDxBGsRNzRreXI2C5g5Sjtg3ys2H',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJhQTF5WjJyWWM1OUpQbDJvN0oxdDlUcTdGMVZsTFo1M1F5VGZRNHdJIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784734282),
('RsXUxUUE52ktFh4QQEjuRDG6xRrUhjgvvRe3tvlu',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJkQ2xVZVBURkhwNkh5Sk9pUUhiNlZxQkRxcmNVa082ZzZtRVI2dnVoIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784732926),
('sAhr0c1E50bT3WJjE0eNoE074vvNDm8IVrNESFc4',NULL,'127.0.0.1','Symfony','eyJfdG9rZW4iOiJtckM0Q0JoUjFLaHNHV2VmWW9lbUhhaHBZck9jcUlDZEJMYk1OcGlPIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpc1wvcGluIiwicm91dGUiOiJsb2dpbi5waW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784736542),
('SrFFWNRJfvIc7KnSPWkF6KUU5KFWvQDdZVjOqydv',NULL,'32.185.185.112','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1','eyJfdG9rZW4iOiJoT1BVdmV2SVpaMnlZcWFoOEJ6dm5PV0VvbEFiZ2Q3Uk1zOEJpbmdxIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cL3FybWVudS5ib2dhaG9zdGRldmVsb3Blci5jb20udHJcL2dpcmlzIiwicm91dGUiOiJsb2dpbiJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1784734006),
('SuVoMYvclIgNyMSSXRJoRr4YUrtzXBWTKb9dtD8d',NULL,'127.0.0.1','Symfony','eyJfdG9rZW4iOiIzaENIaVJaUjUxbk00cWkwVDZ2Qm5JN3Y0eVBOVHc2UTlSN2NONGNaIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpc1wvcGluIiwicm91dGUiOiJsb2dpbi5waW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784739652),
('sWj6pa2b7nr1sjkje3F1xEVqHVbP5YiatzgotOPv',NULL,'88.235.200.157','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJsNlZrTlh2SWxGZWtFRU0yV3RNQXk5YzVicWI0djgybTdTbWZRcWxRIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784734202),
('sYsoLiVmLExAPWtqCFjPWreiUzoamwfJVWKOjwo8',2,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJwUFBzaWZ5d1ZNck9sOEFhSnFLaTZrSE5XeUJteGNxUHBHZXN2TnFOIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9hcGlcL3YxXC9vcmRlcnNcLzIiLCJyb3V0ZSI6Im9yZGVycy5zaG93In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfSwibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiOjJ9',1784736746),
('t9f2BlWHvREQzRVV4YAdtd3TcC2LVOjsihov3LRq',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJvM0JXU2cwdTNNYmNMbk81V0RqMFRvdTdiZUtraVRGQnNyODFhdWg4IiwidXJsIjp7ImludGVuZGVkIjoiaHR0cHM6XC9cL3FybWVudS5ib2dhaG9zdGRldmVsb3Blci5jb20udHJcL3BhbmVsXC9tdXRmYWsifSwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9wYW5lbFwvbXV0ZmFrIiwicm91dGUiOiJwYW5lbC5rZHMua2l0Y2hlbiJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1784739394),
('Tbf8K3UKnZrKurjSMLAXVy7AIYrKQ7p4vOWnvnvi',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiI3MEoxbGdFZnNuUTBISmpibnk3aHdMdHVWS0JESElxSjBsSGc1bGFxIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784733988),
('TsfdKpqxokRv2qv2YWQzO9uz5DQEtVstfWpo4dHs',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJ6cUduZE0wMXJDMUdQenhheFFLd2pXWm0zZlhMQTVXRGpxd29ZbElEIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784736693),
('uBY6dJmO3Z6geKcveqfehIqPNgbd53p1CAaJv4wt',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJJenlZbzZyU2xxZXV3MTdHZ080UXpKcU9ucDVOMHBwRDQwUzRPVE9HIiwidXJsIjp7ImludGVuZGVkIjoiaHR0cHM6XC9cL3FybWVudS5ib2dhaG9zdGRldmVsb3Blci5jb20udHJcL3BhbmVsXC9heWFybGFyXC9lLXBvc3RhIn0sIl9wcmV2aW91cyI6eyJ1cmwiOiJodHRwczpcL1wvcXJtZW51LmJvZ2Fob3N0ZGV2ZWxvcGVyLmNvbS50clwvcGFuZWxcL2F5YXJsYXJcL2UtcG9zdGEiLCJyb3V0ZSI6InBhbmVsLnNldHRpbmdzLm1haWwifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784733769),
('UONv5baB1454oX2o2dYBkl9abJltRaRCIuH6IsIv',NULL,'127.0.0.1','Symfony','eyJfdG9rZW4iOiJiWnNWOE9pYXhKMWEwQjNjc295cWQwWTU4c2JnWVJXbEthT2NJelp5IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1784735038),
('UvkSynCUIBlSO6uto0FNRRnGK7I3xlXyCzY9hX2D',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJHSEVxQ3RiQlZCelNGQjN5TUpxV0V0YXZnTzhtV2theXphYkZJSWhMIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784734311),
('VWy9IKzt1FbElRk5BGNc3ik3tQgOQ0X1iiA4GBOt',2,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJJMWxDcWFaU3pRc0tBVmNSZWw4SnoxRFZ5SDk3ZlJBeUpZTWV3MTl1IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9wYW5lbFwvYXlhcmxhclwvZS1wb3N0YSIsInJvdXRlIjoicGFuZWwuc2V0dGluZ3MubWFpbCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX0sImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjoyfQ==',1784737572),
('Vzg2vAJqaxsHOR3wrCVL8emglylN4A1bK99MTchg',NULL,'127.0.0.1','Symfony','eyJfdG9rZW4iOiJnTWFvaVhSdERMVEFJUVFKRVo3RkpRalN1TGJMUzAzeW5jZUplUkdrIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9wYXJvbGEtc2lmaXJsYSIsInJvdXRlIjoicGFzc3dvcmQucmVxdWVzdCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1784739636),
('WhEML7nQt7M9W8zUmZ5ge3NlnM0YRyplur0q7ZUM',NULL,'127.0.0.1','Symfony','eyJfdG9rZW4iOiJxQ2FDSDB5ZGUwNjhIemcwSUVDZHpYOXNTWHZRQjUzck52MDdjZXZyIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784735038),
('WnFJRV86LhB6KL4Xtgred65xh24WptptGTHNV6ZZ',NULL,'32.185.185.112','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','eyJfdG9rZW4iOiI4QXI3VnVadW9OSHliVnRnTnBwYlk2RlptMTRrWFVXdHNGTVpwbng4IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cL3FybWVudS5ib2dhaG9zdGRldmVsb3Blci5jb20udHIiLCJyb3V0ZSI6ImhvbWUifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784734006),
('XhEaauPsS715QhtbqmA2FpqThpbslD8Wn30q1Jxa',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiIyOXpOMG9kYmJGM2dnS1A3YnR3Ynk5MkczM2tHUXNXeXBPanprY2NrIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784733988),
('Xyt8WqPYzIWO44Zdev4PET4uYzidTGbKBMT3zf6v',NULL,'127.0.0.1','Symfony','eyJfdG9rZW4iOiIwekUxVUZ0Z2lxMUtweThGaG5QMU5RaEpFTFdtcDFzUEpvQ25aRkFqIiwidXJsIjp7ImludGVuZGVkIjoiaHR0cHM6XC9cL3FybWVudS5ib2dhaG9zdGRldmVsb3Blci5jb20udHJcL3BhbmVsIn0sIl9wcmV2aW91cyI6eyJ1cmwiOiJodHRwczpcL1wvcXJtZW51LmJvZ2Fob3N0ZGV2ZWxvcGVyLmNvbS50clwvcGFuZWwiLCJyb3V0ZSI6InBhbmVsLmRhc2hib2FyZCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1784736542),
('Y9Bs78Q4naGtw4qdmvl8zs03H7zYVbHKqdMpN2bo',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJoT09CaXpUejN0MWwwYkZEdkJsSkswZ0d4Ykl5TjNXNFRGM3lSc2k2IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1784732926),
('YKsZdxq8JRbBiZkL8Cf45mpI1c2bpNXoecrSC5zU',NULL,'127.0.0.1','Symfony','eyJfdG9rZW4iOiI1bmVBM1IzbEg0eHpmMjZSZ3R6WGJmV2sxc0dqdVB6Yzg3TG51QnMwIiwidXJsIjp7ImludGVuZGVkIjoiaHR0cHM6XC9cL3FybWVudS5ib2dhaG9zdGRldmVsb3Blci5jb20udHJcL3BhbmVsIn0sIl9wcmV2aW91cyI6eyJ1cmwiOiJodHRwczpcL1wvcXJtZW51LmJvZ2Fob3N0ZGV2ZWxvcGVyLmNvbS50clwvcGFuZWwiLCJyb3V0ZSI6InBhbmVsLmRhc2hib2FyZCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1784738054),
('YkZATwKnDNmKiMCZYEXsaDUzUmFTOpEvYFAG6iun',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJTRVhROGh6TDkyNGczY2RhMXJRMG84WHpsdnJvREFoOGVIeldKc1NlIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1784736693),
('YoVDCsmQE5zmKPW3ScKVQWL1SzTV0nYfF85LMoJY',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJNeXR3aTM3UGNDWE83V2lnQ0dDNFdYTXNTbDVESHlSbW1UckQzQkR1IiwidXJsIjp7ImludGVuZGVkIjoiaHR0cHM6XC9cL3FybWVudS5ib2dhaG9zdGRldmVsb3Blci5jb20udHJcL3BhbmVsXC9tZW51In0sIl9wcmV2aW91cyI6eyJ1cmwiOiJodHRwczpcL1wvcXJtZW51LmJvZ2Fob3N0ZGV2ZWxvcGVyLmNvbS50clwvcGFuZWxcL21lbnUiLCJyb3V0ZSI6InBhbmVsLmNhdGFsb2cucHJvZHVjdHMifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784733988),
('zI3VLQmCP6gUcewFfsx6I0VG7etD6hQ3QsjzYAn3',2,'46.224.208.126','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','eyJfdG9rZW4iOiJMbTAydGlacmZMNVBTbW1JZmRJRTVKOFNrYXdLNDJHYTNiVHE4TmZxIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9wYW5lbCIsInJvdXRlIjoicGFuZWwuZGFzaGJvYXJkIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfSwibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiOjJ9',1784733124),
('Zyp79Up5qlEOx9NRoJlvhlDeHVRlnzn3S36JHYwX',NULL,'127.0.0.1','Symfony','eyJfdG9rZW4iOiJLaklNaXQwcmRHNVoyeldzTHJBR2hxQWY4SzQxc2dMTFpNRnN3dFVLIiwidXJsIjp7ImludGVuZGVkIjoiaHR0cHM6XC9cL3FybWVudS5ib2dhaG9zdGRldmVsb3Blci5jb20udHJcL3BhbmVsIn0sIl9wcmV2aW91cyI6eyJ1cmwiOiJodHRwczpcL1wvcXJtZW51LmJvZ2Fob3N0ZGV2ZWxvcGVyLmNvbS50clwvcGFuZWwiLCJyb3V0ZSI6InBhbmVsLmRhc2hib2FyZCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1784735038),
('zz6brs3mUCX9Iu2nCZNlop5qxSe0ZZt4jBDrEdwM',NULL,'54.247.57.72','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.152 Safari/537.36','eyJfdG9rZW4iOiJtTm1TSkJpelFiRHhMekFXUUROOXZjN0pEVVlJd0F0Y2tVNlNudWZCIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784737096),
('zzrGXwhhFz9xUwUl314ARmT9i4CqnsCBjLPYINbI',NULL,'46.224.208.126','curl/7.61.1','eyJfdG9rZW4iOiJ0NVZVcVhJMjlBMzFRUTZlUmpmTmpQeDFkV3d4TmJpc0xFNzREUnJNIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC9xcm1lbnUuYm9nYWhvc3RkZXZlbG9wZXIuY29tLnRyXC9naXJpcyIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1784733988);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tables`
--

DROP TABLE IF EXISTS `tables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tables` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `branch_id` bigint(20) unsigned NOT NULL,
  `area_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `number` int(10) unsigned DEFAULT NULL,
  `capacity` tinyint(3) unsigned NOT NULL DEFAULT 4,
  `shape` varchar(20) NOT NULL DEFAULT 'square',
  `status` varchar(30) NOT NULL DEFAULT 'available',
  `is_joinable` tinyint(1) NOT NULL DEFAULT 1,
  `notes` varchar(255) DEFAULT NULL,
  `qr_token` char(26) NOT NULL,
  `previous_qr_token` char(26) DEFAULT NULL,
  `qr_rotated_at` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tables_tenant_id_branch_id_name_unique` (`tenant_id`,`branch_id`,`name`),
  UNIQUE KEY `tables_qr_token_unique` (`qr_token`),
  UNIQUE KEY `tables_tenant_id_branch_id_number_unique` (`tenant_id`,`branch_id`,`number`),
  KEY `tables_branch_id_foreign` (`branch_id`),
  KEY `tables_tenant_id_branch_id_is_active_index` (`tenant_id`,`branch_id`,`is_active`),
  KEY `tables_area_id_foreign` (`area_id`),
  KEY `tables_tenant_id_branch_id_status_index` (`tenant_id`,`branch_id`,`status`),
  KEY `tables_previous_qr_token_index` (`previous_qr_token`),
  CONSTRAINT `tables_area_id_foreign` FOREIGN KEY (`area_id`) REFERENCES `venue_areas` (`id`) ON DELETE SET NULL,
  CONSTRAINT `tables_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tables_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tables`
--

LOCK TABLES `tables` WRITE;
/*!40000 ALTER TABLE `tables` DISABLE KEYS */;
INSERT INTO `tables` VALUES
(1,1,1,NULL,'Teras 1',1,4,'square','order_taken',1,NULL,'5C5J5UAFDITI72TS4FDI55SFHQ',NULL,NULL,1,'2026-07-22 12:27:55','2026-07-22 13:32:08'),
(2,1,1,NULL,'Teras 2',2,4,'square','awaiting_service',1,NULL,'L6Z2KCRQMQI5YNSLWYJUAKVJCY',NULL,NULL,1,'2026-07-22 12:27:55','2026-07-22 13:58:27'),
(3,1,1,NULL,'Teras 3',3,4,'square','order_taken',1,NULL,'VCTEDUIHFNATIZHDEULG22DCBQ',NULL,NULL,1,'2026-07-22 12:27:55','2026-07-22 14:01:22'),
(4,1,1,NULL,'Teras 4',4,4,'square','available',1,NULL,'WCRDIJTYVSZHXAE5TCUWFC277E',NULL,NULL,1,'2026-07-22 12:27:55','2026-07-22 12:27:55'),
(5,1,1,NULL,'Teras 5',5,4,'square','available',1,NULL,'D3XO2MWRTGXUUKGUJOAEA5GZ4E','MORZ4NOWRJHUMREW7XR5QWEQGU','2026-07-22 12:28:19',1,'2026-07-22 12:27:55','2026-07-22 12:28:19');
/*!40000 ALTER TABLE `tables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenants`
--

DROP TABLE IF EXISTS `tenants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenants` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `domain` varchar(255) DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'active',
  `settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`settings`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tenants_slug_unique` (`slug`),
  UNIQUE KEY `tenants_domain_unique` (`domain`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenants`
--

LOCK TABLES `tenants` WRITE;
/*!40000 ALTER TABLE `tenants` DISABLE KEYS */;
INSERT INTO `tenants` VALUES
(1,'Demo İşletme','demo',NULL,'active',NULL,'2026-07-22 11:21:41','2026-07-22 11:21:41');
/*!40000 ALTER TABLE `tenants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned DEFAULT NULL,
  `branch_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(32) DEFAULT NULL,
  `staff_code` varchar(32) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `position` varchar(100) DEFAULT NULL,
  `hired_at` date DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `locale` varchar(10) NOT NULL DEFAULT 'tr',
  `theme` varchar(20) NOT NULL DEFAULT 'system',
  `last_login_at` timestamp NULL DEFAULT NULL,
  `last_login_ip` varchar(45) DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `pin_hash` varchar(255) DEFAULT NULL,
  `failed_pin_attempts` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `pin_locked_until` timestamp NULL DEFAULT NULL,
  `two_factor_secret` text DEFAULT NULL,
  `two_factor_recovery_codes` text DEFAULT NULL,
  `two_factor_confirmed_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_tenant_id_email_unique` (`tenant_id`,`email`),
  UNIQUE KEY `users_tenant_id_staff_code_unique` (`tenant_id`,`staff_code`),
  KEY `users_tenant_id_branch_id_index` (`tenant_id`,`branch_id`),
  KEY `users_tenant_id_is_active_index` (`tenant_id`,`is_active`),
  KEY `users_email_index` (`email`),
  KEY `users_branch_id_foreign` (`branch_id`),
  CONSTRAINT `users_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `users_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,1,1,'Demo Sahip','Demo','Sahip','sahip@demo.qrmenu.local',NULL,'SAHIP01',NULL,'İşletme Sahibi',NULL,1,'tr','system','2026-07-22 11:58:33','46.224.208.126','2026-07-22 11:21:41','$2y$12$SluJuAfBjmmKmGhk4BbGMeuZdseIbQV1MSUajzqLBGpdJvTCrbdee','$2y$12$IsARfiZ0JLnUhHLV8kcQSea3dWN.nCtw6hHzsXDndnIoeaNrcuKjy',0,NULL,NULL,NULL,NULL,NULL,'2026-07-22 11:21:41','2026-07-22 11:58:33'),
(2,1,1,'Demo Kullanıcı','Demo','Kullanıcı','demo@demo.com',NULL,NULL,NULL,NULL,NULL,1,'tr','light','2026-07-22 16:57:25','46.224.208.126','2026-07-22 11:49:47','$2y$12$/vAoRPKsWGLHa6qhGWA48.1vAuaIZHK/BJu6QygRiy6AdR70AG3ta',NULL,0,NULL,NULL,NULL,NULL,NULL,'2026-07-22 11:49:47','2026-07-22 16:57:25');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `venue_areas`
--

DROP TABLE IF EXISTS `venue_areas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `venue_areas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `branch_id` bigint(20) unsigned NOT NULL,
  `floor_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'indoor',
  `sort_order` smallint(5) unsigned NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `venue_areas_tenant_id_branch_id_name_unique` (`tenant_id`,`branch_id`,`name`),
  KEY `venue_areas_branch_id_foreign` (`branch_id`),
  KEY `venue_areas_floor_id_foreign` (`floor_id`),
  KEY `venue_areas_tenant_id_branch_id_is_active_sort_order_index` (`tenant_id`,`branch_id`,`is_active`,`sort_order`),
  CONSTRAINT `venue_areas_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `venue_areas_floor_id_foreign` FOREIGN KEY (`floor_id`) REFERENCES `venue_floors` (`id`) ON DELETE SET NULL,
  CONSTRAINT `venue_areas_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `venue_areas`
--

LOCK TABLES `venue_areas` WRITE;
/*!40000 ALTER TABLE `venue_areas` DISABLE KEYS */;
/*!40000 ALTER TABLE `venue_areas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `venue_floors`
--

DROP TABLE IF EXISTS `venue_floors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `venue_floors` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `branch_id` bigint(20) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `sort_order` smallint(5) unsigned NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `venue_floors_tenant_id_branch_id_name_unique` (`tenant_id`,`branch_id`,`name`),
  KEY `venue_floors_branch_id_foreign` (`branch_id`),
  KEY `venue_floors_tenant_id_branch_id_sort_order_index` (`tenant_id`,`branch_id`,`sort_order`),
  CONSTRAINT `venue_floors_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `venue_floors_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `venue_floors`
--

LOCK TABLES `venue_floors` WRITE;
/*!40000 ALTER TABLE `venue_floors` DISABLE KEYS */;
/*!40000 ALTER TABLE `venue_floors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `venue_qr_settings`
--

DROP TABLE IF EXISTS `venue_qr_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `venue_qr_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) unsigned NOT NULL,
  `header_text` varchar(100) DEFAULT NULL,
  `description` varchar(160) DEFAULT NULL,
  `color` char(7) NOT NULL DEFAULT '#111111',
  `bg_color` char(7) NOT NULL DEFAULT '#FFFFFF',
  `frame` varchar(20) NOT NULL DEFAULT 'simple',
  `logo_path` varchar(255) DEFAULT NULL,
  `show_table_no` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `venue_qr_settings_tenant_id_unique` (`tenant_id`),
  CONSTRAINT `venue_qr_settings_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `venue_qr_settings`
--

LOCK TABLES `venue_qr_settings` WRITE;
/*!40000 ALTER TABLE `venue_qr_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `venue_qr_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'qrmenu_app'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-22 22:58:23
